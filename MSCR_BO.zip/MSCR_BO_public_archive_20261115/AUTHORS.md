# MSCR-BO authors

Jiahao Zhao; Shilin Liu; Yabin Li; Yifang Wu; Yuxin Zheng; Tizheng Jia; Liying Zhang; Mingyang Pan; Qinwen Wei.

Hebei Province Technology Innovation Center for Aerospace Composite Structural Design and Manufacturing, North China Institute of Aerospace Engineering, Langfang, Hebei 065000, China.

Corresponding author: Qinwen Wei (weiqinwen@nciae.edu.cn).
