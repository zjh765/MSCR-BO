# Data dictionary and provenance

## Objective conventions

All reported IGD and GD values are minimized; fixed-reference HV is maximized; Spacing is minimized. Feasibility requires every recorded constraint to be at most zero. Archive size counts feasible nondominated points after true evaluation. A blank Spacing cell indicates that the archive did not support that statistic. The composite assigns that problem-metric a contribution of zero without redistributing its weight.

`data/raw/.../round_12.csv` and `data/initial/*.csv` have no header. Columns are `[design variables X, objectives F in minimization direction, constraints G]`. The final trace contains all 114 true evaluations in order: the first 18 rows are round 0, and each following block of eight rows is the next selected batch. `reconstruct_rounds.py` restores any intermediate cumulative file by taking the first `18 + 8 × round` rows. All 12 intermediate source files were checked as exact prefixes before compacting. No synthetic proposals are counted as true evaluations.

`data/egbo/.../train_data.csv` also has no header. Columns are `[X, negative objectives, G]` because the author optimizer stores objectives in maximization direction. Negate only the objective block when comparing with MSCR-BO. The paired-design check is implemented in `verify_archive.py`. Each adjacent `metadata.json` supplies `n_var`, `n_obj`, fixed acquisition reference, candidate count, and device; local `source_file` paths were removed during packaging while `source_sha256` was retained.

## Derived tables

- `canonical_terminal_results.csv`: `experiment`, `case`, `test_id`, `seed`, `method_id`, `variant_label`, `quota_diffusion_walk_acquisition`, `true_evaluations`, `IGD`, `GD`, `HV_fixed`, `Spacing`, `archive_size`, `feasible_count`, and original relative `source_file`. Empty cells were not imputed in this index.
- `report_consistent/corrected_archive_metrics.csv`: the 1,040 MSCR-BO quota, ablation, and ten-seed main runs remeasured from their true-evaluated feasible nondominated archives. `HV_fixed_normalized` uses the common fixed evaluation box. Use this for comparisons between quota/ablation arms.
- `report_consistent/corrected_archive_metric_audit.json`: corrected quota mean ranks, full-minus-ablation scores, intervals, and paired-test results.
- `report_consistent/corrected_fixed_hv_comparison.json`: the corrected original ten-seed standard comparison.
- `report_consistent/pooled_15_seed_summary.json` and `pooled_engineering_15_seed_summary.json`: post hoc summaries combining ten original seeds with five new seeds. The five-seed result also appears separately in the independent campaign's `analysis_summary.json`.
- Campaign `per_round_metrics.csv` and `terminal_seed_metrics.csv`: metric trajectories and terminal observations from the original analysis programs. Preserve original field names when joining tables.

The four quota arms are Q1=7:6:5, Q2=9:5:4, Q3=5:8:5, and Q4=5:6:7. Q3 was selected by the prespecified mean-rank rule. The ablation source-removal controls reassign the disabled source's blocks to remaining sources in their existing proportions using largest-remainder integer rounding, keeping the proposal count fixed. The uniform qLogNEHVI baseline uses an equal-size uniform candidate pool.

## Integrity

`MANIFEST.csv` lists each packaged path, group, byte count and SHA-256 digest. `verify_archive.py` checks those digests, exactly 1,120 complete MSCR-BO runs, 160 complete EGBO runs, 114 evaluations per run, and identical initial archives within each pair. The five experiment groups contain 320 + 640 + 160 + 60 + 100 = 1,280 terminal records. Images and redundant cumulative CSVs are excluded only to keep the upload archive small; no true evaluation rows or terminal metrics were removed.
