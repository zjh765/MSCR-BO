"""Verify package hashes, paired initial designs, and 114-evaluation runs.

Run from any directory: python verify_archive.py
Only Python's standard library is required.
"""
from __future__ import annotations

from collections import Counter
import csv
import hashlib
import json
from pathlib import Path
import re


ROOT = Path(__file__).resolve().parent
STAGED = "MSCR_BO_新算法顺序实验_20261111"
ENGINEERING = "MSCR_BO_工程三案例_配对10次_20261114"
HOLDOUT = "MSCR_BO_独立5种子配对验证_20261114"
EXPECTED = {"quota_10": 320, "ablation_10": 640,
            "standard_comparison_10": 160, "engineering_comparison_10": 60,
            "independent_recheck_5": 100}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def matrix(path: Path) -> list[list[float]]:
    with path.open(encoding="utf-8", newline="") as stream:
        return [[float(v) for v in row] for row in csv.reader(stream) if row]


def same_initial(observed: list[list[float]], initial: list[list[float]]) -> bool:
    return (len(initial) == 18 and len(observed) >= 18 and
            all(len(a) == len(b) and
                all(abs(x - y) <= 1e-8 for x, y in zip(a, b))
                for a, b in zip(observed[:18], initial)))


def verify_msrc() -> int:
    base = ROOT / "data" / "raw"
    runs = 0
    campaign_paths = (
        (base / STAGED / "results" / "quota", "quota_10"),
        (base / STAGED / "results" / "ablation", "ablation_10"),
        (base / STAGED / "results" / "final", "standard_10"),
        (base / ENGINEERING / "results", "engineering_10"),
        (base / HOLDOUT / "results" / "mscr", "independent_5"),
    )
    for folder, group in campaign_paths:
        for final_file in folder.rglob("round_12.csv"):
            run = final_file.parent
            if group == "engineering_10":
                case = run.parent.name
                test = {"RCM21": 54, "RCM27": 57, "RCM02": 56}[case]
                init_group = f"engineering_10/{case}"
            else:
                test = int(re.search(r"T(\d+)", str(run)).group(1))
                init_group = group
            seed = int(re.fullmatch(r"seed(\d+)", run.name).group(1))
            name = f"T{test:02d}_seed{seed:02d}.csv"
            initial = matrix(ROOT / "data" / "initial" / init_group / name)
            observed = matrix(final_file)
            assert len(observed) == 114, run
            assert same_initial(observed, initial), run
            assert not (run / "round_00.csv").exists(), run
            status_file = run / ("run_status.json" if group in
                                 ("quota_10", "ablation_10", "standard_10")
                                 else "status.json")
            status = json.loads(status_file.read_text(encoding="utf-8"))
            assert status["status"] == "ok", run
            assert status.get("budget", status.get("objective_budget")) == 114, run
            runs += 1
    assert runs == 1120, runs
    return runs


def verify_egbo() -> int:
    root = ROOT / "data" / "egbo"
    author_source = (ROOT / "code" / "egbo" / "author_source_snapshot" /
                     "run_synthetic_pairwise_egbo_novelty_nehvi.py")
    license_file = author_source.parent / "License.md"
    assert sha256(license_file) == (
        "508a77d2e7b51d98adeed32648ad124b7b30241a8e70b2e72c99f92d8e5874d1")
    source_hash = sha256(author_source)
    runs = 0
    for train in root.rglob("train_data.csv"):
        parts = train.relative_to(root).parts
        if parts[0] == "standard_10":
            test = int(parts[1][1:]); seed = int(parts[2][4:])
            initial = ROOT / "data" / "initial" / "standard_10" / f"T{test:02d}_seed{seed:02d}.csv"
        elif parts[0] == "engineering_10":
            case = parts[1]
            test = {"RCM21": 54, "RCM27": 57, "RCM02": 56}[case]
            seed = int(parts[2][4:])
            initial = ROOT / "data" / "initial" / "engineering_10" / case / f"T{test:02d}_seed{seed:02d}.csv"
        elif parts[0] == "independent_5":
            seed = int(parts[1][4:]); test = int(parts[2][1:])
            initial = ROOT / "data" / "initial" / "independent_5" / f"T{test:02d}_seed{seed:02d}.csv"
        else:
            raise AssertionError(parts)
        meta = json.loads((train.parent / "metadata.json").read_text(encoding="utf-8"))
        assert meta["source_sha256"] == source_hash, train
        raw = matrix(train)
        assert len(raw) == 114 and meta["physical_eval_count"] == 114, train
        assert meta["candidate_pool_per_round"] == 144, train
        d, m = meta["n_var"], meta["n_obj"]
        observed = [row[:d] + [-v for v in row[d:d+m]] + row[d+m:]
                    for row in raw]
        assert same_initial(observed, matrix(initial)), train
        runs += 1
    assert runs == 160, runs
    return runs


def main() -> None:
    with (ROOT / "MANIFEST.csv").open(encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream))
    report = json.loads((ROOT / "PACKAGE_REPORT.json").read_text(encoding="utf-8"))
    assert report["mscr_code_license"] is None
    assert report["experiment_data_license"] is None
    assert not (ROOT / "LICENSE").exists()
    assert not (ROOT / "DATA_LICENSE.md").exists()
    assert (ROOT / "RIGHTS_NOTICE.md").is_file()
    assert len(rows) == report["files_excluding_manifest"]
    for item in rows:
        target = (ROOT / item["path"]).resolve()
        assert target.is_relative_to(ROOT.resolve()), item["path"]
        assert target.stat().st_size == int(item["bytes"]), target
        assert sha256(target) == item["sha256"], target
    with (ROOT / "data" / "derived" / "canonical_terminal_results.csv").open(
            encoding="utf-8-sig", newline="") as stream:
        canonical = list(csv.DictReader(stream))
    assert Counter(row["experiment"] for row in canonical) == EXPECTED
    mscr = verify_msrc()
    egbo = verify_egbo()
    print(json.dumps({"manifest_files_verified": len(rows),
                      "canonical_rows": len(canonical),
                      "mscr_runs_verified": mscr,
                      "egbo_runs_verified": egbo,
                      "status": "PASS"}, indent=2))


if __name__ == "__main__":
    main()
