"""Recompute the locked four-metric composite from packaged terminal results.

Requires NumPy. Usage: python reproduce_score.py --experiment standard_comparison_10
Options: standard_comparison_10, independent_recheck_5, pooled_standard_15.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
CASES = ("ZDT1", "ZDT3", "ZDT4", "DTLZ1", "DTLZ2", "MW3", "MW5", "MW7")
METRICS = ("IGD", "GD", "HV_fixed", "Spacing")


def read_cube(experiment: str) -> tuple[np.ndarray, tuple[int, ...]]:
    with (ROOT / "data" / "derived" / "canonical_terminal_results.csv").open(
            encoding="utf-8-sig", newline="") as stream:
        rows = list(csv.DictReader(stream))
    if experiment == "standard_comparison_10":
        selected = [r for r in rows if r["experiment"] == experiment]
        seeds = tuple(range(10, 20))
    elif experiment == "independent_recheck_5":
        selected = [r for r in rows if r["experiment"] == experiment and
                    r["case"] in CASES]
        seeds = tuple(range(100, 105))
    else:
        selected = [r for r in rows if r["experiment"] in
                    ("standard_comparison_10", "independent_recheck_5") and
                    r["case"] in CASES]
        seeds = tuple(range(10, 20)) + tuple(range(100, 105))
    keyed = {(r["case"], int(r["seed"]), r["method_id"]): r for r in selected}
    assert len(keyed) == 8 * len(seeds) * 2, len(keyed)
    cube = np.empty((8, len(seeds), 4, 2), dtype=float)
    for ci, case in enumerate(CASES):
        for si, seed in enumerate(seeds):
            for mi, method in enumerate(("MSCR-BO", "EGBO")):
                row = keyed[case, seed, method]
                assert int(row["true_evaluations"]) == 114
                for ki, metric in enumerate(METRICS):
                    cell = row[metric]
                    cube[ci, si, ki, mi] = (float(cell) if cell else
                                            float("inf") if ki < 2 else
                                            0.0 if ki == 2 else float("nan"))
    return cube, seeds


def score_many(cube: np.ndarray, spacing_valid: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    # Leading dimension indexes bootstrap or label-swap replicates.
    means = np.mean(cube, axis=2)
    a, b = means[..., 0], means[..., 1]
    with np.errstate(invalid="ignore", divide="ignore"):
        oriented = np.stack((b[..., 0] - a[..., 0], b[..., 1] - a[..., 1],
                             a[..., 2] - b[..., 2], b[..., 3] - a[..., 3]),
                            axis=-1)
        denom = np.maximum(np.maximum(np.abs(a), np.abs(b)), 1e-12)
        advantage = oriented / denom
    both_inf = np.isinf(a) & np.isinf(b)
    only_a_inf = np.isinf(a) & ~np.isinf(b)
    only_b_inf = np.isinf(b) & ~np.isinf(a)
    advantage = np.where(both_inf, 0, advantage)
    advantage = np.where(only_a_inf, -1, advantage)
    advantage = np.where(only_b_inf, 1, advantage)
    advantage[..., 3] = np.where(spacing_valid, advantage[..., 3], 0)
    assert np.isfinite(advantage).all()
    return advantage.mean(axis=(-2, -1)), advantage


def analyze(experiment: str, draws: int = 20_000, flips: int = 100_000) -> dict:
    cube, seeds = read_cube(experiment)
    spacing_valid = np.isfinite(cube[:, :, 3, :]).all(axis=(1, 2))
    observed_array, cells = score_many(cube[None], spacing_valid)
    observed = float(observed_array[0])
    rng_seed = (20261114 if experiment == "independent_recheck_5"
                else 20261106)
    rng = np.random.default_rng(rng_seed)
    ncase, nseed = cube.shape[:2]
    bootstrap = []
    for n in range(0, draws, 1000):
        width = min(1000, draws - n)
        indices = rng.integers(nseed, size=(width, ncase, nseed))
        samples = np.take_along_axis(np.broadcast_to(cube, (width,) + cube.shape),
                                     indices[..., None, None], axis=2)
        scores, _ = score_many(samples, spacing_valid)
        bootstrap.extend(scores.tolist())
    ci = np.quantile(bootstrap, [0.025, 0.975]).tolist()
    extreme = 0
    for n in range(0, flips, 1000):
        width = min(1000, flips - n)
        switch = rng.integers(2, size=(width, ncase, nseed), dtype=np.int8).astype(bool)
        original = np.broadcast_to(cube, (width,) + cube.shape)
        swapped = np.where(switch[..., None, None], original[..., ::-1], original)
        values, _ = score_many(swapped, spacing_valid)
        extreme += int(np.count_nonzero(values >= observed - 1e-14))
    return {"experiment": experiment, "cases": list(CASES), "seeds": list(seeds),
            "observed_score": observed, "paired_bootstrap_95_ci": ci,
            "one_sided_p_label_flip": (extreme + 1) / (flips + 1),
            "spacing_valid_by_case": dict(zip(CASES, spacing_valid.tolist())),
            "per_case_scores": dict(zip(CASES, cells[0].mean(axis=1).tolist())),
            "n_bootstrap": draws, "n_label_flips": flips, "rng_seed": rng_seed}


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--experiment", choices=("standard_comparison_10",
        "independent_recheck_5", "pooled_standard_15"),
        default="standard_comparison_10")
    parser.add_argument("--bootstrap", type=int, default=20_000)
    parser.add_argument("--flips", type=int, default=100_000)
    args = parser.parse_args()
    print(json.dumps(analyze(args.experiment, args.bootstrap, args.flips),
                     ensure_ascii=False, indent=2))
