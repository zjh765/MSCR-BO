# EGBO source included in this archive

The following files were copied without editing from the project's `author_original` folder into `code/egbo/author_source_snapshot/`. Both were compared byte for byte with the corresponding files in the [upstream Aqeeli Novelty-Aware EGBO repository](https://github.com/shorthouse-lab/Aqeeli_NoveltyAware_EGBO); their SHA-256 hashes match.

| File | Role | SHA-256 |
|---|---|---|
| `run_synthetic_pairwise_egbo_novelty_nehvi.py` | Contains the EGBO optimization functions called by the comparison runner | `9a5e5dbdd140495ce82690cff1a23fbb9eaa27a1daee767fab8f753c185bf247` |
| `run_novelty_initial10_standalone.py` | Supplies problem and helper definitions imported by that file | `98c5a7dbd7710ee408334476d2d55db143f9b385c327115b5aa6737d58e224ca` |

The experiment-specific adapter files are separate under `code/egbo/local_experiment_adapters/`:

| File | Role | SHA-256 |
|---|---|---|
| `run_author_egbo_47.py` | Imports the optimizer functions, sets the 114-evaluation/144-proposal protocol, and writes metadata/results | `138018eba051725ccc3b0223e0946a3696fe30c037037118d5e3cce491bd95bd` |
| `egbo_author_eval_server.m` | MATLAB objective/constraint evaluator for the matched benchmarks | `fd2cf7df54cba9d455e4afdd7f6fb259a750993d91c13c1593969c59c9ac202f` |

All 160 packaged EGBO `metadata.json` files record the first file's SHA-256 as `source_sha256`. This links the included optimizer snapshot to the observed comparison runs. The upstream repository supplies an [MIT license](https://github.com/shorthouse-lab/Aqeeli_NoveltyAware_EGBO/blob/main/License.md); its exact `License.md` is included beside the two source files. The local copy lacked that file, which caused the earlier incomplete license note. Preserve the upstream notice and attribution in redistributed copies.

EGBO `train_data.csv` stores objective values in maximization direction; MSCR-BO `round_XX.csv` stores minimization objectives. `verify_archive.py` checks the sign conversion and every shared initial archive. The EGBO source files are retained byte for byte; the metadata copies omit only machine-specific `source_file` paths and retain `source_sha256`.
