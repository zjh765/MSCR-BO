"""Restore all cumulative MSCR-BO round CSVs from compact final traces.

Run from the package as:
    python reconstruct_rounds.py --output PATH_OUTSIDE_THIS_PACKAGE
No objective function is called and no experiment is rerun.
"""
from __future__ import annotations

import argparse
from pathlib import Path
import shutil


ROOT = Path(__file__).resolve().parent
RAW = ROOT / "data" / "raw"


def main(output: Path) -> None:
    destination = output.resolve()
    if destination == ROOT or destination.is_relative_to(ROOT):
        raise SystemExit("Choose an output directory outside this compact package")
    if destination.exists() and any(destination.iterdir()):
        raise SystemExit(f"Output directory is not empty: {destination}")
    count = 0
    for source in RAW.rglob("*"):
        if not source.is_file():
            continue
        target = destination / source.relative_to(RAW)
        target.parent.mkdir(parents=True, exist_ok=True)
        if source.name != "round_12.csv":
            shutil.copyfile(source, target)
            continue
        lines = source.read_bytes().splitlines(keepends=True)
        if len(lines) != 114:
            raise ValueError(f"Expected 114 true evaluation rows: {source}")
        for round_id in range(13):
            n = 18 + 8 * round_id
            (target.parent / f"round_{round_id:02d}.csv").write_bytes(
                b"".join(lines[:n]))
        count += 1
    if count != 1120:
        raise ValueError(f"Expected 1120 runs, found {count}")
    print(f"Restored 13 round CSVs for {count} MSCR-BO runs in {destination}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    main(parser.parse_args().output)
