function Xr = surrepair(X, Xd, G, LB, UB, params)
%SURREPAIR  约束代理 Pre-repair（方法 DPRS / DPRSE）：
%   用已收集的 (Xd, G) 训练每个约束 c_j(x)<=0 的固定核 GP（RBF(median(xstd))
%   +White(1e-4)），修复全程绝不调用昂贵真约束。对应 Python 端
%   repair.py::SurrogatePreRepair。两个鲁棒机制：
%   1. 代理均值梯度投影 + 回溯线搜索；
%   2. 仍预测不可行时，围绕已知可行点(或最轻违反点)局部采样兜底。
%   无约束或数据不足 → 退化为盒式裁剪（尽力而为）。
X = min(max(X, LB), UB);
lo = LB; hi = UB;
wdt = hi - lo;
use_gpu=isfield(params,'require_gpu') && params.require_gpu;
normalized_ls=[];
if isfield(params,'surrogate_normalized_ls')
    normalized_ls=params.surrogate_normalized_ls;
end
repair_kernel='rbf';
if isfield(params,'repair_gp_kernel'), repair_kernel=params.repair_gp_kernel; end
rep = consurfit(Xd, G, params.gp_alpha, params.min_data, ...
    use_gpu, normalized_ls, repair_kernel);
if isempty(rep)
    Xr = X;
    return;
end
for i = 1:size(X, 1)
    x = X(i, :);
    for st = 1:params.repair_steps
        v0 = sum(max(surG(rep, x), 0));
        if v0 < params.repair_tol
            break;
        end
        g = sgrad(rep, x);
        t = params.repair_lr;
        moved = false;
        for bt = 1:12                       % 回溯线搜索
            xn = min(max(x - t*g, lo), hi);
            if sum(max(surG(rep, xn), 0)) < v0 - 1e-9
                x = xn;
                moved = true;
                break;
            end
            t = t*0.5;
        end
        if ~moved
            break;
        end
    end
    % 便宜的代理引导局部细化
    X(i, :) = lfs(rep, x, x, LB, UB, params.repair_k, params.repair_sigma);
end
% 兜底：仍预测不可行的候选，围绕已知可行点(或最轻违反点)搜索
v = sum(max(surG(rep, X), 0), 2);
if max(v) > params.repair_tol
    vd = sum(max(G, 0), 2);
    [~, o] = sort(vd);
    fi = o(vd(o) <= params.repair_tol);
    if isempty(fi)
        c0 = Xd(o(1:max(1, floor(params.repair_k/2))), :);
    else
        c0 = Xd(fi, :);
    end
    for i = 1:size(X, 1)
        if sum(max(surG(rep, X(i, :)), 0)) <= params.repair_tol
            continue;
        end
        X(i, :) = lfs(rep, X(i, :), [X(i, :); c0], LB, UB, ...
            params.repair_k, params.repair_sigma);
    end
end
Xr = min(max(X, LB), UB);
end

function Gp = surG(rep, X)
Xn = (X - rep.xmean)./rep.xstd;
Gp = zeros(size(X, 1), numel(rep.g));
for j = 1:numel(rep.g)
    Gp(:, j) = gppred(rep.g{j}.gp, Xn)*rep.g{j}.sd + rep.g{j}.mu;
end
end

function g = sgrad(rep, x)
d = numel(x);
e0 = 1e-4;
v0 = sum(max(surG(rep, x), 0));
g = zeros(1, d);
for j = 1:d
    xp = x;
    xp(j) = xp(j) + e0;
    g(j) = (sum(max(surG(rep, xp), 0)) - v0)/e0;
end
end

function b = lfs(rep, x0, ctr, LB, UB, k, sg)
% 代理引导局部可行搜索：x0 与 ctr 周围 k 个扰动中取预测违反量最小者
lo = LB; hi = UB;
wdt = hi - lo;
d = numel(x0);
b = x0;
bv = sum(max(surG(rep, x0), 0));
for t = 1:k
    c = ctr(randi(size(ctr, 1)), :);
    xp = min(max(c + sg*wdt.*randn(1, d), lo), hi);
    vp = sum(max(surG(rep, xp), 0));
    if vp < bv
        b = xp;
        bv = vp;
    end
end
end
