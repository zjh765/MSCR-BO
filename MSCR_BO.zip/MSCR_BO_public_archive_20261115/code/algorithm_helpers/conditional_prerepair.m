function [Xr, triggered] = conditional_prerepair(X, LB, UB, observedG, evalG, steps, lr, tol)
%CONDITIONAL_PREREPAIR Always project bounds; repair only violated constraints.
% An empty observed constraint matrix means the problem is unconstrained.
Xr = min(max(X, LB), UB);
triggered = false(size(Xr, 1), 1);
if isempty(observedG) || size(observedG, 2) == 0
    return;
end
G = evalG(Xr);
assert(size(G, 1) == size(Xr, 1) && size(G, 2) == size(observedG, 2), ...
    'Constraint evaluation dimensions do not match observed constraints.');
triggered = sum(max(G, 0), 2) > tol;
if any(triggered)
    Xr(triggered, :) = prerepair(Xr(triggered, :), LB, UB, evalG, ...
        steps, lr, tol);
end
Xr = min(max(Xr, LB), UB);
end
