function p = diffusion_params(p)
%DIFFUSION_PARAMS Explicit, saved configuration for the main candidate source.
p.candidate_source='conditional_diffusion_guided_v1';
p.walk_source='feasible_elite_multiscale_walk_v1';
p.acqf_source='botorch_qlognehvi_gradient_optimize_v1';
p.diffusion_steps=32;
p.diffusion_train_initial=100;
p.diffusion_train_update=40;
p.diffusion_train_mode='elite_near_cover';
p.diffusion_hidden=64;
p.diffusion_heads=4;
p.diffusion_layers=2;
p.diffusion_lr=1e-3;
p.diffusion_guidance=.04;
p.diffusion_repulsion=.01;
p.diffusion_rbf_ridge=1e-4;
p.walk_adaptive=true;
p.walk_stall_patience=2;
p.walk_expand_factor=2;
p.walk_expand_max=4;
p.acq_global_starts=4;
p.require_gpu=true;
p.metrics_backend='cuda_torch_exact2d3d_v1';
end
