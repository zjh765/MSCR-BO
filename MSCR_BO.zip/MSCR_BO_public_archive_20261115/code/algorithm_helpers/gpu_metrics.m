function metrics = gpu_metrics(F, PF)
%GPU_METRICS CUDA implementation of the repository's four metric formulas.
% F and PF must be finite, nonempty, and have 2 or 3 objectives.
root=fileparts(mfilename('fullpath'));
python=getenv('DPR_QLOGNEHVI_PYTHON');
if isempty(python)
    python=fullfile(root,'科研实验报告_新版', ...
        '临时_原作者EGBO_ZDT1_预算56','.venv','Scripts','python.exe');
end
assert(exist(python,'file')==2,'GPU metrics Python environment not found.');
request=struct('front',F,'reference_front',PF,'n_obj',size(F,2));
input=[tempname '.json']; output=[tempname '.json'];
cleanup=onCleanup(@() cleanup_files(input,output)); %#ok<NASGU>
fid=fopen(input,'w','n','UTF-8');
assert(fid>0,'Cannot create GPU metrics request.');
fprintf(fid,'%s',jsonencode(request)); fclose(fid);
[status,message]=system(sprintf('"%s" "%s" "%s" "%s"', ...
    python,fullfile(root,'gpu_metrics_bridge.py'),input,output));
assert(status==0 && exist(output,'file')==2,'GPU metrics failed: %s',message);
result=jsondecode(fileread(output));
assert(strcmp(result.device,'cuda'),'GPU metrics did not use CUDA.');
metrics=[result.igd,result.gd,result.hv,result.spacing];
end

function cleanup_files(input,output)
if exist(input,'file'), delete(input); end
if exist(output,'file'), delete(output); end
end
