function Xw = elite_walk(X, F, G, q, LB, UB, p)
%ELITE_WALK  NSDBO 式精英局部游走候选生成。
%   沿用蜣螂繁殖算子的核心机制：在 X 空间围绕归档优秀解做局部随机
%   游走生成候选。与蜣螂包的两点对应关系：
%     * 繁殖算子局部游走   → 本函数围绕精英的多尺度扰动（粗→细阶梯）；
%     * 按真实目标值选择   → BO 预算下由闭环实现：游走候选经采集函数
%       选批、真实评估后按真实 F 进归档，成为下一轮游走的新精英
%       （真实目标值的选择压力作用在"评估→归档"环节，不额外烧预算）。
%   输出加入共享候选池，与随机池 / optimize_acqf 提议统一打分选择。
%
%   输入：X/F/G 归档（X: n×d, F: n×M, G: n×ncons）；q 批大小；
%         LB/UB 边界（1×d）；p.walk_batches 生成批次数；
%         p.walk_sigma 基础扰动（相对盒宽）。
%   输出：Xw（K*q × d，批主序；每批次抽 q 个精英分别扰动——批内天然多样）。
LB = LB(:)'; UB = UB(:)';
d = size(X, 2);
% ---- 精英 = 可行非支配解（真实目标值口径）----
n = size(X, 1);
if isempty(G)
    feas = true(n, 1);
else
    feas = all(G <= 0, 2);
end
msk = false(n, 1);
if any(feas)
    idx = find(feas);
    nd = non_dominated_front(F(feas, :));
    msk(idx(nd)) = true;
end
Xe = X(msk, :);
if isempty(Xe)
    % With no feasible archive yet, walk from the least violating points.
    violation = sum(max(G,0),2);
    [~,order] = sort(violation,'ascend');
    Xe = X(order(1:min(numel(order),max(q,5))),:);
end
E = size(Xe, 1);
K = p.walk_batches;
bw = UB - LB;
sig = p.walk_sigma*[1, 0.5, 0.25];       % 粗→细扰动阶梯（多尺度局部游走）
if isfield(p,'walk_adaptive') && p.walk_adaptive
    patience = p.walk_stall_patience;
    assert(patience>=1 && patience==floor(patience));
    stalled = 0;
    if isfield(p,'walk_stagnation_rounds')
        stalled = p.walk_stagnation_rounds;
    end
    factor = min(p.walk_expand_max, ...
        p.walk_expand_factor^floor(stalled/patience));
    sig = min(sig*factor,0.5);
end
Xw = zeros(K*q, d);
for i = 1:K
    e = randi(E, 1, q);                    % 每批次抽 q 个精英
    s = sig(mod(i-1, 3) + 1);
    Xw((i-1)*q+(1:q), :) = min(max(Xe(e, :) + s*bw.*randn(q, d), ...
        repmat(LB, q, 1)), repmat(UB, q, 1));
end
end
