function diffusion_cleanup(p)
%DIFFUSION_CLEANUP Remove trained DDPM checkpoint after one method run.
if isfield(p,'diffusion_checkpoint') && exist(p.diffusion_checkpoint,'file')
    delete(p.diffusion_checkpoint);
end
end
