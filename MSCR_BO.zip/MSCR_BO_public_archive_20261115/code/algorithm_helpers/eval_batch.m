function [F, G] = eval_batch(MultiObj, X)
%EVAL_BATCH  Evaluate objectives and explicit constraints at each decision.
%   CF1-CF10 return c>=0 when feasible; G=-c follows the local G<=0 rule.
n = size(X, 1);
F = zeros(n, MultiObj.numOfObj);
if isfield(MultiObj,'raw_fun') && ~isempty(MultiObj.raw_fun)
    G = zeros(n,0);
    for i = 1:n
        [y,c] = MultiObj.raw_fun(X(i,:));
        F(i,:) = y(:)';
        if i==1, G=zeros(n,numel(c)); end
        assert(numel(c)==size(G,2),'Constraint count changed between decisions.');
        G(i,:) = -c(:)';
    end
else
    G = zeros(n,0);
    for i = 1:n
        y = MultiObj.fun(X(i, :));
        F(i, :) = y(:)';
    end
    if isfield(MultiObj,'con') && ~isempty(MultiObj.con)
        G = MultiObj.con(X);
        assert(size(G,1)==n,'Constraint row count does not match decisions.');
    end
end
end
