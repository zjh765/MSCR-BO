"""CUDA evaluation of the repository's IGD, GD, HV (2D/3D), and Spacing.

The formulas and HV normalization follow IGD.m, GD.m, HV.m, Spacing.m.
This bridge deliberately errors without CUDA; it never evaluates objectives.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import torch


def nearest_distance(rows: torch.Tensor, columns: torch.Tensor) -> torch.Tensor:
    pieces = []
    for chunk in rows.split(4096):
        pieces.append(torch.cdist(chunk, columns, p=2).min(dim=1).values)
    return torch.cat(pieces)


def hv2(points: torch.Tensor) -> torch.Tensor:
    ordered = points[torch.argsort(points[:, 0])]
    best_y = torch.cummin(ordered[:, 1], dim=0).values
    widths = torch.cat((ordered[1:, 0] - ordered[:-1, 0],
                        1 - ordered[-1:, 0]))
    return (widths * (1 - best_y).clamp_min(0)).sum()


def hypervolume(front: torch.Tensor, reference: torch.Tensor) -> torch.Tensor:
    n_obj = front.shape[1]
    origin = torch.minimum(front.min(dim=0).values,
                           torch.zeros(n_obj, device=front.device, dtype=front.dtype))
    nadir = reference.max(dim=0).values
    normalized = (front - origin) / ((nadir - origin) * 1.1)
    normalized = normalized[(normalized <= 1).all(dim=1)]
    if len(normalized) == 0:
        return front.new_tensor(0.0)
    if n_obj == 2:
        return hv2(normalized)
    if n_obj == 3:
        xs = torch.unique(normalized[:, 0], sorted=True)
        volume = front.new_tensor(0.0)
        for i, x in enumerate(xs):
            width = (xs[i + 1] - x) if i + 1 < len(xs) else (1 - x)
            volume = volume + width * hv2(normalized[normalized[:, 0] <= x, 1:])
        return volume
    raise ValueError("Exact CUDA HV bridge currently supports 2 or 3 objectives")


def calculate(request: dict) -> dict:
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required for GPU metrics")
    n_obj = int(request["n_obj"])
    front_np = np.asarray(request["front"], dtype=float).reshape((-1, n_obj))
    pf_np = np.asarray(request["reference_front"], dtype=float).reshape((-1, n_obj))
    if front_np.shape[1] != pf_np.shape[1]:
        raise ValueError("Front and reference front must be aligned 2-D matrices")
    if len(front_np) == 0 or len(pf_np) == 0 or not np.isfinite(front_np).all() or not np.isfinite(pf_np).all():
        raise ValueError("Nonempty finite fronts are required")
    front = torch.as_tensor(front_np, dtype=torch.float64, device="cuda")
    pf = torch.as_tensor(pf_np, dtype=torch.float64, device="cuda")
    igd_dist = nearest_distance(pf, front)
    gd_dist = nearest_distance(front, pf)
    if len(front) < 2:
        spacing = float("nan")
    else:
        manhattan = torch.cdist(front, front, p=1)
        manhattan.fill_diagonal_(float("inf"))
        spacing = manhattan.min(dim=1).values.std(correction=1).item()
    result = {
        "igd": igd_dist.mean().item(),
        "gd": (torch.linalg.vector_norm(gd_dist) / len(gd_dist)).item(),
        "hv": hypervolume(front, pf).item(),
        "spacing": spacing,
        "device": "cuda",
    }
    return result


def main() -> None:
    request_path, response_path = map(Path, sys.argv[1:3])
    result = calculate(json.loads(request_path.read_text(encoding="utf-8")))
    response_path.write_text(json.dumps(result), encoding="utf-8")


if __name__ == "__main__":
    main()
