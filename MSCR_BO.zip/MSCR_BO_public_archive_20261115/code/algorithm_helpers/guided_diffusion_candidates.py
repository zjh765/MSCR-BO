"""Preference-conditioned, gradient-guided DDPM candidate source.

This is a structural adaptation of Chen (2026), DOI 10.1016/j.swevo.2026.102340:
Transformer noise prediction, Pareto-set conditioning, surrogate gradient
guidance and repulsion. The paper's full implementation and hyperparameters
were not available, so this module does not claim exact author reproduction.
Only candidate generation is replaced; the MATLAB qLogNEHVI selector remains.
"""

from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np
import torch
from torch import nn


class ConditionalDenoiser(nn.Module):
    def __init__(self, n_var: int, n_obj: int, hidden: int, heads: int, layers: int):
        super().__init__()
        self.value = nn.Linear(1, hidden)
        self.position = nn.Embedding(n_var, hidden)
        self.preference = nn.Linear(n_obj, hidden)
        self.time = nn.Sequential(nn.Linear(2, hidden), nn.SiLU(), nn.Linear(hidden, hidden))
        block = nn.TransformerEncoderLayer(
            d_model=hidden, nhead=heads, dim_feedforward=2 * hidden,
            dropout=0.0, activation="gelu", batch_first=True, norm_first=True,
        )
        self.encoder = nn.TransformerEncoder(
            block, num_layers=layers, enable_nested_tensor=False
        )
        self.out = nn.Sequential(nn.LayerNorm(hidden), nn.Linear(hidden, 1))

    def forward(self, noisy: torch.Tensor, step: torch.Tensor,
                preference: torch.Tensor, total_steps: int) -> torch.Tensor:
        batch, n_var = noisy.shape
        phase = step.float().reshape(batch, 1) / max(total_steps - 1, 1)
        t_embed = self.time(torch.cat((torch.sin(2 * math.pi * phase),
                                       torch.cos(2 * math.pi * phase)), dim=1))
        index = torch.arange(n_var, device=noisy.device)
        tokens = (self.value(noisy.unsqueeze(-1)) + self.position(index)[None]
                  + self.preference(preference)[:, None] + t_embed[:, None])
        return self.out(self.encoder(tokens)).squeeze(-1)


def non_dominated(f: np.ndarray) -> np.ndarray:
    mask = np.ones(len(f), dtype=bool)
    for i in range(len(f)):
        if np.any(np.all(f <= f[i], axis=1) & np.any(f < f[i], axis=1)):
            mask[i] = False
    return mask


def training_groups(x: np.ndarray, f: np.ndarray, feasible: np.ndarray,
                    elite: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Use observed objectives for near-front points and X for broad coverage."""
    eligible = np.flatnonzero(feasible) if np.any(feasible) else np.arange(len(x))
    remaining = eligible[~np.isin(eligible, elite)]
    near_count = min(len(remaining), max(1, math.ceil(len(x) / 4)))
    if near_count:
        distance = np.linalg.norm(f[remaining, None] - f[elite][None], axis=2).min(axis=1)
        near = remaining[np.argsort(distance, kind="stable")[:near_count]]
    else:
        near = elite.copy()

    # Farthest-first points add regions that the elite and near-front samples miss.
    broad_count = min(len(eligible), max(2, math.ceil(len(x) / 4)))
    covered = np.unique(np.concatenate((elite, near)))
    available = eligible[~np.isin(eligible, covered)].tolist()
    broad = []
    for _ in range(min(broad_count, len(available))):
        distances = np.linalg.norm(x[available, None] - x[covered][None], axis=2).min(axis=1)
        chosen = available.pop(int(np.argmax(distances)))
        broad.append(chosen)
        covered = np.append(covered, chosen)
    if not broad:
        broad = eligible.tolist()  # All feasible observations can be elite early on.
    return near, np.asarray(broad, dtype=int)


def rbf_model(x: torch.Tensor, y: torch.Tensor, ridge: float):
    distances = torch.cdist(x, x)
    positive = distances[distances > 1e-8]
    bandwidth = positive.median().clamp_min(0.1) if positive.numel() else x.new_tensor(0.5)
    kernel = torch.exp(-distances.square() / (2 * bandwidth.square()))
    coeff = torch.linalg.solve(kernel + ridge * torch.eye(len(x), device=x.device), y)
    return x, coeff, bandwidth


def preference_gradient(points: torch.Tensor, preference: torch.Tensor,
                        model) -> torch.Tensor:
    centers, coeff, bandwidth = model
    difference = points[:, None] - centers[None]
    kernel = torch.exp(-difference.square().sum(-1) / (2 * bandwidth.square()))
    objective_grad = -torch.einsum("nc,ncd,cm->nmd", kernel, difference, coeff)
    objective_grad = objective_grad / bandwidth.square()
    return torch.einsum("nmd,nm->nd", objective_grad, preference)


def repulsion(points: torch.Tensor) -> torch.Tensor:
    difference = points[:, None] - points[None]
    squared = difference.square().sum(-1)
    off_diagonal = squared[~torch.eye(len(points), dtype=torch.bool, device=points.device)]
    bandwidth2 = off_diagonal.median().clamp_min(0.01)
    kernel = torch.exp(-squared / (2 * bandwidth2))
    kernel.fill_diagonal_(0)
    return (kernel[:, :, None] * difference).mean(1) / bandwidth2


def unit_direction(vector: torch.Tensor) -> torch.Tensor:
    return vector / vector.norm(dim=1, keepdim=True).clamp_min(1e-8)


def run(request: dict) -> dict:
    lower = np.asarray(request["lb"], dtype=float).reshape(-1)
    upper = np.asarray(request["ub"], dtype=float).reshape(-1)
    n_var = len(lower)
    n_obj = int(request["n_obj"])
    x = np.asarray(request["train_x"], dtype=float).reshape((-1, n_var))
    f = np.asarray(request["train_f"], dtype=float).reshape((-1, n_obj))
    n_con = int(request["n_constraints"])
    g = np.asarray(request.get("train_g", []), dtype=float).reshape((-1, n_con)) if n_con else np.empty((len(x), 0))
    if len(x) != len(f) or len(x) != len(g) or len(x) < 2:
        raise ValueError("Misaligned or insufficient observed data")
    if np.any(upper <= lower) or not all(np.isfinite(a).all() for a in (x, f, g)):
        raise ValueError("Invalid bounds or non-finite observations")
    n_candidates = int(request["n_candidates"])
    batch_q = int(request["q"])
    if n_candidates < 1 or n_candidates % batch_q:
        raise ValueError("Candidate count must be a positive multiple of q")
    steps = int(request["diffusion_steps"])
    hidden = int(request["hidden"])
    heads = int(request["heads"])
    layers = int(request["layers"])
    if steps < 2 or hidden % heads or not 0 <= float(request["guidance"]) <= 0.5:
        raise ValueError("Invalid diffusion architecture or guidance")

    torch.manual_seed(int(request["seed"]))
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if request.get("require_gpu", False) and device.type != "cuda":
        raise RuntimeError("CUDA is required for conditional diffusion")
    torch.set_num_threads(min(4, torch.get_num_threads()))
    normalized = np.clip((x - lower) / (upper - lower), 0, 1)
    feasible = np.all(g <= 0, axis=1) if n_con else np.ones(len(x), dtype=bool)
    if np.any(feasible):
        feasible_indices = np.flatnonzero(feasible)
        elite_indices = feasible_indices[non_dominated(f[feasible])]
    else:
        # A constrained problem can begin without feasible observations.
        # Use the least violating observations until a feasible set exists.
        violation = np.maximum(g, 0).sum(axis=1)
        elite_indices = np.argsort(violation)[:max(2, min(8, len(x)))]
    x_t = torch.as_tensor(normalized, dtype=torch.float32, device=device)
    f_t = torch.as_tensor(f, dtype=torch.float32, device=device)
    scale = (f_t.max(0).values - f_t.min(0).values).clamp_min(1e-6)
    f_scaled = (f_t - f_t.min(0).values) / scale
    elite_x = x_t[elite_indices]
    elite_f = f_scaled[elite_indices]
    train_preference = torch.softmax(-elite_f / 0.25, dim=-1)
    train_mode = request.get("train_mode", "elite_near_cover")
    if train_mode not in ("elite_only", "elite_near_cover"):
        raise ValueError(f"Unknown diffusion training mode: {train_mode}")
    near_indices = np.empty(0, dtype=int)
    broad_indices = np.empty(0, dtype=int)
    if train_mode == "elite_near_cover":
        near_indices, broad_indices = training_groups(
            normalized, f_scaled.cpu().numpy(), feasible, elite_indices)
        all_preference = torch.softmax(-f_scaled / 0.25, dim=-1)
        near_index_t = torch.as_tensor(near_indices, device=device)
        broad_index_t = torch.as_tensor(broad_indices, device=device)
    surrogate = rbf_model(x_t, f_scaled, float(request["rbf_ridge"]))

    net = ConditionalDenoiser(n_var, n_obj, hidden, heads, layers).to(device)
    checkpoint = Path(request["checkpoint"])
    reused = checkpoint.is_file()
    if reused:
        state = torch.load(checkpoint, map_location=device, weights_only=True)
        if state["architecture"] != [n_var, n_obj, hidden, heads, layers, steps]:
            raise ValueError("Diffusion checkpoint architecture changed during a run")
        net.load_state_dict(state["model"])
    beta = torch.linspace(1e-4, 0.02, steps, device=device)
    alpha_bar = torch.cumprod(1 - beta, dim=0)
    optimizer = torch.optim.AdamW(net.parameters(), lr=float(request["learning_rate"]), weight_decay=1e-4)
    train_steps = int(request["train_steps_update"] if reused else request["train_steps_initial"])
    net.train()
    for _ in range(train_steps):
        batch_size = min(64, max(16, 4 * len(elite_x)))
        if train_mode == "elite_only":
            index = torch.randint(len(elite_x), (batch_size,), device=device)
            clean = 2 * elite_x[index] - 1
            preference = train_preference[index]
        else:
            counts = (batch_size // 2, batch_size // 4)
            groups = (torch.as_tensor(elite_indices, device=device),
                      near_index_t, broad_index_t)
            sampled = [groups[j][torch.randint(len(groups[j]), (count,), device=device)]
                       for j, count in enumerate((*counts, batch_size - sum(counts)))]
            index = torch.cat(sampled)[torch.randperm(batch_size, device=device)]
            clean = 2 * x_t[index] - 1
            preference = all_preference[index]
        step = torch.randint(steps, (len(index),), device=device)
        noise = torch.randn_like(clean)
        a = alpha_bar[step, None]
        noisy = a.sqrt() * clean + (1 - a).sqrt() * noise
        predicted = net(noisy, step, preference, steps)
        loss = (predicted - noise).square().mean()
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        nn.utils.clip_grad_norm_(net.parameters(), 1.0)
        optimizer.step()
    torch.save({"architecture": [n_var, n_obj, hidden, heads, layers, steps],
                "model": net.state_dict()}, checkpoint)

    net.eval()
    n_batches = n_candidates // batch_q
    preferences = torch.distributions.Dirichlet(
        torch.ones(n_obj, device=device)).sample((n_batches,))
    # Cover objective extremes as well as the interior of the simplex.
    extreme = min(n_batches, n_obj)
    preferences[:extreme] = torch.eye(n_obj, device=device)[:extreme]
    preferences = preferences.repeat_interleave(batch_q, dim=0)
    preferences = 0.9 * preferences + 0.1 / n_obj
    z = torch.randn(n_candidates, n_var, device=device)
    guide = float(request["guidance"])
    repel = float(request["repulsion"])
    with torch.no_grad():
        for step_number in range(steps - 1, -1, -1):
            t = torch.full((n_candidates,), step_number, dtype=torch.long, device=device)
            predicted = net(z, t, preferences, steps)
            a = alpha_bar[step_number]
            clean = ((z - (1 - a).sqrt() * predicted) / a.sqrt()).clamp(-1, 1)
            points = (clean + 1) / 2
            gradient = unit_direction(preference_gradient(points, preferences, surrogate))
            spread = unit_direction(repulsion(points)) if repel > 0 else 0
            points = (points - guide * gradient + repel * spread).clamp(0, 1)
            clean = 2 * points - 1
            prev_a = alpha_bar[step_number - 1] if step_number else torch.ones_like(a)
            z = prev_a.sqrt() * clean + (1 - prev_a).sqrt() * predicted
    candidates = ((z + 1) / 2).clamp(0, 1).cpu().numpy()
    candidates = candidates * (upper - lower) + lower
    if candidates.shape != (n_candidates, n_var) or not np.isfinite(candidates).all():
        raise ValueError("Diffusion generated invalid candidates")
    return {"candidates": candidates.tolist(), "source": "conditional_diffusion_guided_v1",
            "elite_training_points": int(len(elite_indices)),
            "near_training_points": int(len(near_indices)),
            "broad_training_points": int(len(broad_indices)),
            "train_mode": train_mode, "trained_steps": train_steps,
            "checkpoint_reused": reused, "device": str(device)}


def main() -> None:
    input_path, output_path = map(Path, sys.argv[1:3])
    result = run(json.loads(input_path.read_text(encoding="utf-8")))
    output_path.write_text(json.dumps(result), encoding="utf-8")


if __name__ == "__main__":
    main()
