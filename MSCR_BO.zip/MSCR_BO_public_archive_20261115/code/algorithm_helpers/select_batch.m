function [Xb, batch_index] = select_batch(scorefun, Xf, q, ~, ~, ~)
%SELECT_BATCH Select the best complete q-point batch by raw joint qLogNEHVI.
assert(mod(size(Xf,1),q)==0,'Candidate pool must contain full q-point batches.');
scores=scorefun(Xf);
assert(numel(scores)==size(Xf,1)/q && all(isfinite(scores)));
[~,batch_index]=max(scores);
Xb=Xf((batch_index-1)*q+(1:q),:);
end
