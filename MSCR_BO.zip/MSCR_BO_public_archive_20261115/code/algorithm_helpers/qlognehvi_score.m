function [values, predicted_means] = qlognehvi_score(candidate, p, pfarg)
%QLOGNEHVI_SCORE True joint-batch log noisy EHVI scores; higher is better.
p.acq_return_means = nargout > 1;
result = qlognehvi_bridge('score',candidate,p,pfarg);
values = result.values(:);
assert(numel(values)==size(candidate,1)/p.q);
if nargout > 1
    assert(isfield(result,'predicted_means_minimization'), ...
        'CUDA GP predicted means missing from qLogNEHVI bridge.');
    predicted_means = reshape(result.predicted_means_minimization, ...
        size(candidate,1),size(p.acq_train_f,2));
end
end
