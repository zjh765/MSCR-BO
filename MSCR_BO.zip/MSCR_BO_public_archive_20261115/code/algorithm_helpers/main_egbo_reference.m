function [ref,meta] = main_egbo_reference(obj, test_id, egbo_root)
% Load the paired author's EGBO reference point for the 114-evaluation run.
if nargin<3 || isempty(egbo_root)
    root=fileparts(mfilename('fullpath'));
    egbo_root=fullfile(root,'科研实验报告_新版', ...
        '对比实验_预算114_八函数','EGBO_144_seed0');
end
case_dir=fullfile(egbo_root,sprintf('T%02d',test_id));
meta_file=fullfile(case_dir,'metadata.json');
train_file=fullfile(case_dir,'train_data.csv');
assert(exist(meta_file,'file')==2 && exist(train_file,'file')==2, ...
    'Paired EGBO result missing for T%d. Run EGBO first.',test_id);
meta=jsondecode(fileread(meta_file));
assert(meta.test_id==test_id && ismember(meta.seed,[0 60]) && meta.budget==114 && ...
    meta.initial==18 && meta.batches==12 && meta.batch_size==8 && ...
    meta.physical_eval_count==114 && meta.candidate_pool_per_round==144 && ...
    meta.qnehvi_candidates==16 && meta.evo_candidates==128 && ...
    meta.qbo_chunk==8 && meta.sampler_samples==16 && ...
    meta.n_var==obj.nVar && meta.n_obj==obj.numOfObj && ...
    startsWith(meta.device,'cuda'),'EGBO protocol mismatch for T%d',test_id);
train=readmatrix(train_file);
assert(isequal(size(train),[114,obj.nVar+obj.numOfObj+meta.n_constr]) ...
    && all(isfinite(train(:))),'EGBO train data invalid for T%d',test_id);
% The historical synthetic protocol used seed 0 and the generic LHS check.
% Engineering CRE references use seed 60 and the shared CRE21 feasible-sector
% initializer; the author runner has already checked those exact points.
if meta.seed==0
    rng(0,'twister'); u=zeros(18,obj.nVar);
    for j=1:obj.nVar
        u(:,j)=(randperm(18)'+rand(18,1)-1)/18;
    end
    initial=repmat(obj.var_min,18,1)+ ...
        repmat(obj.var_max-obj.var_min,18,1).*u;
    assert(max(abs(initial(:)-reshape(train(1:18,1:obj.nVar),[],1)))<1e-7, ...
        'EGBO initial decisions differ for T%d',test_id);
end
ref=meta.acquisition_ref_minimization(:)';
assert(numel(ref)==obj.numOfObj && all(isfinite(ref)), ...
    'EGBO reference invalid for T%d',test_id);
end
