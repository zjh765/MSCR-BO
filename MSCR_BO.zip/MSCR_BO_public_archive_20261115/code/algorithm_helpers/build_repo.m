function f = build_repo(X, F, G, M, D, Nr)
%BUILD_REPO  可行归档 → 非支配排序 → Repository（对应 NSDBO 的 archive 收尾口径，
%   调用蜣螂包同名工具 non_domination_sort_mod / replace_chromosome）。
%   返回 f = [决策变量 目标]（同 NSDBO：f(:,1:D)=PS，f(:,D+1:D+M)=PF）。
if isempty(G) || size(G, 2) == 0
    fe = true(size(F, 1), 1);
else
    fe = all(G <= 0, 2);
end
chromosome = [X(fe, :), F(fe, :)];
if isempty(chromosome)
    f = zeros(0, D + M);
    return;
end
inter = non_domination_sort_mod(chromosome, M, D);
Pop = replace_chromosome(inter, M, D, Nr);
Pop = Pop(Pop(:, M+D+1) == 1, :);   % 只保留第一前沿（同 NSDBO 的 archive 口径）
f = Pop(:, 1:D+M);
end
