function result = qlognehvi_bridge(mode, candidate, p, pfarg)
%QLOGNEHVI_BRIDGE EGBO/BoTorch qLogNEHVI with the observed noisy baseline.
% p.acq_train_x/f/g are all truly evaluated observations in this iteration.
root = fileparts(mfilename('fullpath'));
python = getenv('DPR_QLOGNEHVI_PYTHON');
if isempty(python)
    python = fullfile(root,'科研实验报告_新版', ...
        '临时_原作者EGBO_ZDT1_预算56','.venv','Scripts','python.exe');
end
assert(exist(python,'file')==2,'EGBO BoTorch Python not found: %s',python);
assert(size(candidate,1)>0 && mod(size(candidate,1),p.q)==0, ...
    'Candidate rows must be a nonempty multiple of q.');
F = p.acq_train_f;
G = p.acq_train_g;
fmin = min([zeros(1,size(F,2)); F],[],1);
ref = fmin + 1.1*(max(pfarg,[],1)-fmin);
if isfield(p,'acq_ref_override') && ~isempty(p.acq_ref_override)
    ref = p.acq_ref_override(:)';
end
assert(numel(ref)==size(F,2) && all(isfinite(ref)), ...
    'Invalid qLogNEHVI reference point.');
if ~(isfield(p,'fixed_ref_strict') && p.fixed_ref_strict)
    assert(all(ref>fmin),'Invalid adaptive qLogNEHVI reference point.');
end
request = struct('mode',mode,'train_x',p.acq_train_x, ...
    'train_f',F,'train_g',G,'n_constraints',size(G,2), ...
    'lb',p.acq_lb,'ub',p.acq_ub,'ref',ref,'candidate',candidate, ...
    'q',p.q,'seed',p.acq_seed,'model_cache',p.acq_cache, ...
    'mc_samples',p.mc_samples, ...
    'gp_kernel',get_option(p,'gp_kernel','rbf'), ...
    'acqf_starts',p.acqf_starts,'acqf_maxiter',p.acqf_maxiter, ...
    'acq_global_starts',get_option(p,'acq_global_starts',0), ...
    'predict_means',isfield(p,'acq_return_means') && p.acq_return_means, ...
    'require_gpu',isfield(p,'require_gpu') && p.require_gpu);
input = [tempname '.json']; output = [tempname '.json'];
cleanup = onCleanup(@() cleanup_files(input,output)); %#ok<NASGU>
fid = fopen(input,'w','n','UTF-8');
assert(fid>0,'Cannot create qLogNEHVI bridge request.');
fprintf(fid,'%s',jsonencode(request)); fclose(fid);
script = fullfile(root,'egbo_qlognehvi_bridge.py');
[status,message] = system(sprintf('"%s" "%s" "%s" "%s"', ...
    python,script,input,output));
if status ~= 0 && strcmp(mode,'score') && ...
        (strcmp(getenv('RCM20_ENGINEERING_RUN'),'1') || ...
         strcmp(getenv('RCM02_ENGINEERING_RUN'),'1') || ...
         strcmp(getenv('RCM27_ENGINEERING_RUN'),'1'))
    % Engineering numerical recovery: prefer the first complete q-batch.
    % No true evaluation is added; every returned score remains finite.
    nbatch = size(candidate,1)/p.q;
    result = struct('values',-(0:nbatch-1)', ...
        'model_reused',false,'recovery','deterministic_pool');
    fprintf(2,'qLogNEHVI score numerical recovery: %s\n',message);
    return;
end
if status ~= 0 && strcmp(mode,'optimize')
    % Predeclared no-extra-evaluation recovery for non-finite BoTorch gradients.
    % It returns the first deterministic q-batches from the already built pool.
    nout = min(p.acqf_starts, floor(size(candidate,1)/p.q))*p.q;
    assert(nout>0,'Acquisition recovery pool is too small.');
    result = struct('candidates',candidate(1:nout,:), ...
        'model_reused',false,'recovery','deterministic_pool');
    fprintf(2,'qLogNEHVI numerical recovery: %s\n',message);
    return;
end
assert(status==0 && exist(output,'file')==2, ...
    'EGBO qLogNEHVI failed: %s',message);
result = jsondecode(fileread(output));
end

function value = get_option(p,name,default)
if isfield(p,name), value=p.(name); else, value=default; end
end

function cleanup_files(input,output)
if exist(input,'file'), delete(input); end
if exist(output,'file'), delete(output); end
end
