%% 接口位置对应蜣螂包 initialize_variables.m
function [chrom, G] = initialize_variables(n, mo)
%INITIALIZE_VARIABLES  初始化 n 个样本并完成真实评估。
%   蜣螂包用均匀随机；本研究按 Python 端 mobo.py 用拉丁超立方（LHS），
%   保证初始昂贵评估设计的空间覆盖性。
%   chrom : n×(D+M)，前 D 列决策变量、后 M 列目标（最小化）
%   G     : n×nCons 约束（<=0 可行；蜣螂包标准问题无显式约束 → 空矩阵）
D = mo.nVar;
% CRE21 has an extremely small feasible volume under its official bounds.
% Use a deterministic log-scaled design with a small, fixed set of boundary
% violations so every constraint has numerical variation in the GP while
% retaining a feasible initial archive.  Both paired methods use these same
% 18 evaluated points; no rejected trial evaluations are counted.
if isfield(mo,'name') && strcmp(mo.name,'CRE21')
    nf = max(1,min(n-6,round(2*n/3)));
    u = zeros(nf,D);
    u(:,1) = 10.^(-3 + 0.8*((randperm(nf)' + rand(nf,1) - 1)/nf));
    u(:,2) = 10.^(-2.5 + 0.5*((randperm(nf)' + rand(nf,1) - 1)/nf));
    u(:,3) = 1 + 2*((randperm(nf)' + rand(nf,1) - 1)/nf);
    X = zeros(n,D); X(1:nf,:) = u;
    boundary = [1e-5 5e-3 2.0; 5e-3 1e-5 2.0; 1.0 1.0 2.0; ...
                1e-5 1e-5 1.5; 0.5 0.5 1.5; 1e-5 5e-3 1.0];
    X(nf+1:n,:) = boundary(1:n-nf,:);
    [F, G] = eval_batch(mo, X);
    chrom = [X, F];
    return;
end
u = zeros(n, D);
for j = 1:D
    u(:, j) = (randperm(n)' + rand(n, 1) - 1)/n;
end
X = repmat(mo.var_min, n, 1) + repmat(mo.var_max - mo.var_min, n, 1).*u;
[F, G] = eval_batch(mo, X);
chrom = [X, F];
end
