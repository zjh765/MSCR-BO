function gained = archive_gain(F, G, Fn, Gn)
%ARCHIVE_GAIN True if a new feasible observation expands the Pareto archive.
if isempty(G) || size(G,2)==0
    old_feasible = true(size(F,1),1);
    new_feasible = true(size(Fn,1),1);
else
    old_feasible = all(G<=0,2);
    new_feasible = all(Gn<=0,2);
end
old = F(old_feasible,:);
gained = false;
for i = find(new_feasible)'
    if ~any(all(old<=Fn(i,:),2))
        gained = true;
        return;
    end
end
end
