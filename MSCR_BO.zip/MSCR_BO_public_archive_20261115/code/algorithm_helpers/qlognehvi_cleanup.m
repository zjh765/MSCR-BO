function qlognehvi_cleanup(p)
%QLOGNEHVI_CLEANUP Remove this iteration's fitted BoTorch GP cache.
if isfield(p,'acq_cache') && exist(p.acq_cache,'file')
    delete(p.acq_cache);
end
end
