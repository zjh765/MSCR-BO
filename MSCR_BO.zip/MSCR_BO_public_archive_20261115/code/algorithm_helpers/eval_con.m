function G = eval_con(MultiObj, X)
%EVAL_CON Explicit constraint violations (G<=0 means feasible).
if isfield(MultiObj,'con') && ~isempty(MultiObj.con)
    G = MultiObj.con(X);
else
    [~, G] = eval_batch(MultiObj, X);
end
end
