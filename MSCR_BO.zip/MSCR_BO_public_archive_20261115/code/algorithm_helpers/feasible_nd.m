function Fnd = feasible_nd(F, G)
%FEASIBLE_ND  可行非支配目标集（最小化）。无约束 → 全体；空可行集保持为空。
if isempty(G) || size(G, 2) == 0
    fe = true(size(F, 1), 1);
else
    fe = all(G <= 0, 2);
end
Ff = F(fe, :);
if isempty(Ff)
    Fnd = Ff;
else
    Fnd = Ff(non_dominated_front(Ff), :);
end
end
