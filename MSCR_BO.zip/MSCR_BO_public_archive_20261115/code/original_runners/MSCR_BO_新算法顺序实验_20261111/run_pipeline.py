"""Sequential, resumable quota -> ablation -> EGBO comparison campaign."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

import numpy as np

ROOT = Path(__file__).resolve().parent
LEGACY = Path(r"F:\全局优化\DPR-qNEHVI_MATLAB")
OLD = LEGACY / "科研实验报告_新版" / "MSCR_BO_冻结版后续实验"
MATLAB = Path(r"E:\Program Files\Polyspace\R2020a\bin\matlab.exe")
PYTHON = (LEGACY / "科研实验报告_新版" / "临时_原作者EGBO_ZDT1_预算56"
          / ".venv" / "Scripts" / "python.exe")
TESTS = (1, 3, 4, 6, 7, 48, 49, 50)
QUOTAS = ((7, 6, 5), (9, 5, 4), (5, 8, 5), (5, 6, 7))
ARMS = ("FULL", "NO_DIFFUSION", "NO_WALK", "NO_ACQ_OPT",
        "NO_REPAIR", "NO_SPREAD_ANCHOR", "NO_GREEDY", "QLOG_BASE")
SEEDS = {"quota": tuple(range(10)), "ablation": tuple(range(20, 30)),
         "final": tuple(range(10, 20))}
METRICS = ("IGD", "GD", "HV_fixed", "Spacing")


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def initial_path(stage: str, test: int, seed: int) -> Path:
    folder = {"quota": "配对多种子_预算114_八函数",
              "ablation": "组件消融_15重复_预算114_八函数",
              "final": "确认性独立验证_seed10_19"}[stage]
    return OLD / folder / "initial" / f"T{test:02d}_seed{seed:02d}.csv"


def output(stage: str, test: int, seed: int, config: int) -> Path:
    label = (f"Q{config}" if stage == "quota" else
             ARMS[config - 1] if stage == "ablation" else None)
    base = ROOT / "results" / stage
    if label:
        base = base / label
    return base / f"T{test:02d}" / f"seed{seed:02d}"


def audit() -> dict:
    protocol = json.loads((ROOT / "protocol.json").read_text(encoding="utf-8"))
    assert protocol["tests"] == list(TESTS)
    assert protocol["quota_stage"]["quotas"] == [list(q) for q in QUOTAS]
    assert protocol["ablation_stage"]["arms"] == list(ARMS)
    assert MATLAB.is_file() and PYTHON.is_file()
    source = {p.name: sha(p) for p in (ROOT / "MSCR_BO_staged.m",
             ROOT / "run_stage_case.m", ROOT / "select_batch_greedy.m",
             ROOT / "greedy_qlognehvi_bridge.py", ROOT / "elite_walk_spread.m",
             ROOT / "surrepair_gate_engineering.m")}
    assert "remaining_quota" in (ROOT / "run_stage_case.m").read_text(encoding="utf-8")
    inputs = {}
    for stage in SEEDS:
        for test in TESTS:
            for seed in SEEDS[stage]:
                path = initial_path(stage, test, seed)
                data = np.loadtxt(path, delimiter=",")
                assert data.shape[0] == 18 and np.isfinite(data).all(), path
                inputs[f"{stage}/T{test:02d}/seed{seed:02d}"] = sha(path)
                if stage == "final":
                    egbo = (OLD / "确认性独立验证_seed10_19" / "results"
                            / f"T{test:02d}" / f"seed{seed:02d}" / "EGBO"
                            / f"T{test:02d}")
                    meta = json.loads((egbo / "metadata.json").read_text(encoding="utf-8"))
                    train = np.loadtxt(egbo / "train_data.csv", delimiter=",")
                    d, m = meta["n_var"], meta["n_obj"]
                    paired = np.column_stack((train[:18, :d],
                                              -train[:18, d:d + m],
                                              train[:18, d + m:]))
                    assert train.shape[0] == 114 and np.allclose(
                        paired, data, atol=1e-8, rtol=0)
                    assert meta["candidate_pool_per_round"] == 144
    return {"protocol_sha256": sha(ROOT / "protocol.json"),
            "source_sha256": source, "input_sha256": inputs}


def verify(stage: str, test: int, seed: int, config: int) -> bool:
    out = output(stage, test, seed, config)
    try:
        item = json.loads((out / "run_status.json").read_text(encoding="utf-8"))
        assert item["status"] == "ok" and item["stage"] == stage
        assert item["test_id"] == test and item["seed"] == seed
        assert item["config_id"] == config and item["budget"] == 114
        initial = np.loadtxt(initial_path(stage, test, seed), delimiter=",")
        for it in range(13):
            data = np.loadtxt(out / f"round_{it:02d}.csv", delimiter=",")
            assert data.shape == (18 + 8 * it, initial.shape[1])
            assert np.isfinite(data).all()
            assert np.allclose(data[:18], initial, atol=1e-8, rtol=0)
        log = (out / "progress.log").read_text(encoding="utf-8")
        assert len(re.findall(r"iter=\d+/12", log)) == 12
        if item["arm"] != "NO_GREEDY":
            chosen = re.findall(r"greedy_round=(\d+).*source_counts=(\d+),(\d+),(\d+)", log)
            assert len(chosen) == 12
            assert [int(x[0]) for x in chosen] == list(range(1, 13))
            assert all(sum(map(int, x[1:])) == 8 for x in chosen)
        assert len(item["metrics"]) == 4
        return True
    except (OSError, ValueError, KeyError, TypeError, AssertionError):
        return False


def run_one(stage: str, test: int, seed: int, config: int) -> None:
    out = output(stage, test, seed, config)
    if verify(stage, test, seed, config):
        return
    assert out.resolve().is_relative_to((ROOT / "results").resolve())
    for retry in range(3):
        if out.exists() and any(out.iterdir()):
            if (out / "run_status.json").exists():
                raise RuntimeError(f"Invalid completed result needs review: {out}")
            number = 1
            archive = out.with_name(f"{out.name}_failed_attempt{number:02d}")
            while archive.exists():
                number += 1
                archive = out.with_name(f"{out.name}_failed_attempt{number:02d}")
            assert archive.resolve().is_relative_to((ROOT / "results").resolve())
            out.rename(archive)
            print(f"ARCHIVED_INCOMPLETE {archive}", flush=True)
        out.mkdir(parents=True, exist_ok=True)
        env = os.environ.copy()
        env["DPR_QLOGNEHVI_PYTHON"] = str(PYTHON)
        command = [str(MATLAB), "-wait", "-batch",
                   f"run_stage_case('{stage}',{test},{seed},{config})"]
        with (out / "matlab.log").open("ab") as stream:
            process = subprocess.Popen(command, cwd=ROOT, env=env,
                                       stdout=stream, stderr=subprocess.STDOUT,
                                       creationflags=subprocess.CREATE_NO_WINDOW)
            started = time.monotonic()
            try:
                while process.poll() is None:
                    elapsed = time.monotonic() - started
                    if elapsed > 300 and not (out / "round_00.csv").exists():
                        raise TimeoutError(f"MATLAB startup exceeded 300 seconds: {out}")
                    if elapsed > 2400:
                        raise TimeoutError(f"MATLAB run exceeded 2400 seconds: {out}")
                    time.sleep(2)
            except BaseException:
                if process.poll() is None:
                    subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"],
                                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                   check=False)
                raise
        if verify(stage, test, seed, config):
            if process.returncode:
                print(f"MATLAB_SHUTDOWN_WARNING {out} exit={process.returncode}",
                      flush=True)
            return
        if (out / "run_status.json").exists():
            raise RuntimeError(f"Invalid completed result needs review: {out}")
        print(f"RETRY_INCOMPLETE attempt={retry + 1} exit={process.returncode} {out}",
              flush=True)
    raise RuntimeError(f"MATLAB failed after three incomplete attempts: {out}")


def rank_values(values: np.ndarray, higher: bool) -> np.ndarray:
    finite = np.isfinite(values)
    ranks = np.full(values.shape, float(finite.sum() + 1))
    if not finite.any():
        return ranks
    ordered_indices = np.flatnonzero(finite)[np.argsort(
        -values[finite] if higher else values[finite], kind="mergesort")]
    ordered = values[ordered_indices]
    start = 0
    while start < len(ordered):
        stop = start + 1
        while stop < len(ordered) and ordered[stop] == ordered[start]:
            stop += 1
        ranks[ordered_indices[start:stop]] = (start + 1 + stop) / 2
        start = stop
    return ranks


def finite(value) -> float:
    try:
        x = float(value)
    except (TypeError, ValueError):
        return np.nan
    return x if np.isfinite(x) else np.nan


def select_quota() -> dict:
    assert all(verify("quota", t, s, q) for t in TESTS for s in SEEDS["quota"]
               for q in range(1, 5))
    scores = np.empty((4, len(TESTS), 10))
    for ti, test in enumerate(TESTS):
        for si, seed in enumerate(SEEDS["quota"]):
            records = [json.loads((output("quota", test, seed, q) / "run_status.json")
                                  .read_text(encoding="utf-8")) for q in range(1, 5)]
            parts = []
            for mi, name in enumerate(METRICS):
                values = np.array([finite(item["metrics"][mi]) for item in records])
                if np.isfinite(values).any():
                    parts.append(rank_values(values, name == "HV_fixed"))
            assert parts
            scores[:, ti, si] = np.mean(parts, axis=0)
    means = scores.mean(axis=(1, 2))
    winner = int(np.argmin(means)) + 1
    report = {"quota_ids": list(range(1, 5)), "quotas": [list(q) for q in QUOTAS],
              "overall_mean_ranks": means.tolist(), "winner_id": winner,
              "winner_quota": list(QUOTAS[winner - 1]),
              "per_test_mean_ranks": scores.mean(axis=2).T.tolist(),
              "criterion": "minimum four-metric mean rank, no significance threshold"}
    path = ROOT / "quota_summary.json"
    if path.exists():
        assert json.loads(path.read_text(encoding="utf-8")) == report
    else:
        path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n",
                        encoding="utf-8")
    selected = {"quota_id": winner, "quota": list(QUOTAS[winner - 1]),
                "quota_summary_sha256": sha(path), "algorithm_version": "joint_selection_v1"}
    path = ROOT / "selected_quota.json"
    if path.exists():
        assert json.loads(path.read_text(encoding="utf-8")) == selected
    else:
        path.write_text(json.dumps(selected, ensure_ascii=False, indent=2) + "\n",
                        encoding="utf-8")
    return selected


def promote_main(selected: dict) -> None:
    """Make the quota selected on seeds 0-9 the only active main setting."""
    config = {"algorithm": "MSCR-BO joint_selection_v1",
              "source_quota": selected["quota"],
              "source_quota_id": selected["quota_id"],
              "selection_record_sha256": sha(ROOT / "selected_quota.json"),
              "entry_point": "run_main_case.m",
              "evaluation_seeds": list(SEEDS["final"]),
              "budget": 114, "candidate_points_per_round": 144}
    target = ROOT / "main_config.json"
    if target.exists():
        assert json.loads(target.read_text(encoding="utf-8")) == config
    else:
        target.write_text(json.dumps(config, ensure_ascii=False, indent=2) + "\n",
                          encoding="utf-8")
    current = ROOT.parent / "CURRENT_EXPERIMENT.md"
    current.write_text(
        "# 当前主实验代码\n\n"
        "主实验采用 [MSCR-BO 顺序实验](MSCR_BO_新算法顺序实验_20261111/README.md) "
        "中的逐点联合 qLogNEHVI 选批、分散精英起点与约束感知选择性修复（CASR）。"
        f"10 次配额重测选定的候选来源配额为 {':'.join(map(str, selected['quota']))}；"
        "配置锁定在 `MSCR_BO_新算法顺序实验_20261111/main_config.json`，"
        "主实验入口为 `MSCR_BO_新算法顺序实验_20261111/run_main_case.m`。\n\n"
        "八个标准函数为 ZDT1、ZDT3、ZDT4、DTLZ1、DTLZ2、MW3、MW5、MW7。"
        "每函数使用 10 个与原作者 EGBO 匹配的初始种子 10–19；"
        "初始 18 点，12 轮，每轮 8 点，共 114 次真实评估。"
        "配额选择使用种子 0–9；组件消融使用种子 20–29。"
        "本轮最终结果保存在 `MSCR_BO_新算法顺序实验_20261111/results/final`。"
        "旧版原始数据仅供审计，不计入新结果。\n",
        encoding="utf-8")


def run_stage(stage: str, limit: int | None = None) -> int:
    configs = range(1, 5 if stage == "quota" else 9 if stage == "ablation" else 2)
    done = 0
    for test in TESTS:
        for seed in SEEDS[stage]:
            for config in configs:
                if not verify(stage, test, seed, config):
                    if limit is not None and done >= limit:
                        return done
                    run_one(stage, test, seed, config)
                    done += 1
                    print(f"COMPLETE {stage} T{test:02d} seed{seed:02d} config{config}", flush=True)
                (ROOT / "campaign_status.json").write_text(json.dumps({
                    "stage": stage, "current_test": test, "current_seed": seed,
                    "current_config": config, "new_runs_this_invocation": done,
                    "status": "running"}, indent=2) + "\n", encoding="utf-8")
    return done


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--stage", choices=("quota", "ablation", "final", "all"),
                        default="all")
    parser.add_argument("--limit", type=int)
    args = parser.parse_args()
    record = audit()
    if args.check:
        print("STAGED_SOURCE_AND_PAIRED_INPUTS_OK")
        return 0
    lock = ROOT / "input_lock.json"
    if lock.exists():
        assert json.loads(lock.read_text(encoding="utf-8")) == record
    else:
        lock.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n",
                        encoding="utf-8")
    stages = ("quota", "ablation", "final") if args.stage == "all" else (args.stage,)
    try:
        for stage in stages:
            if stage != "quota":
                assert (ROOT / "selected_quota.json").is_file(), "Quota not selected yet"
            run_stage(stage, args.limit)
            complete = all(verify(stage, t, s, q) for t in TESTS for s in SEEDS[stage]
                           for q in range(1, 5 if stage == "quota" else
                                          9 if stage == "ablation" else 2))
            if not complete:
                (ROOT / "campaign_status.json").write_text(json.dumps({
                    "stage": stage, "status": "partial_validated",
                    "new_runs_this_invocation": args.limit}, indent=2) + "\n",
                    encoding="utf-8")
                print(f"PARTIAL {stage}", flush=True)
                return 0
            if stage == "quota":
                selected = select_quota()
                promote_main(selected)
                print("SELECTED_QUOTA", selected, flush=True)
            subprocess.run([str(PYTHON), str(ROOT / "analyze_pipeline.py"), stage],
                           cwd=ROOT, check=True)
            (ROOT / "campaign_status.json").write_text(json.dumps({
                "stage": stage, "status": "stage_complete"}, indent=2) + "\n",
                encoding="utf-8")
        if args.stage in ("all", "final"):
            (ROOT / "campaign_status.json").write_text(json.dumps({
                "status": "all_runs_complete", "quota": json.loads(
                    (ROOT / "selected_quota.json").read_text(encoding="utf-8"))["quota"]},
                indent=2) + "\n", encoding="utf-8")
        return 0
    except Exception as exc:
        (ROOT / "campaign_status.json").write_text(json.dumps({
            "status": "paused_runtime_error", "stage": stage, "reason": str(exc)},
            ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        raise


if __name__ == "__main__":
    raise SystemExit(main())
