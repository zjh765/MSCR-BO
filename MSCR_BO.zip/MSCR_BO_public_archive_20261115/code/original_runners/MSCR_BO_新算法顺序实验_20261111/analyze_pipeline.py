"""Analyze completed stages without borrowing outcomes from old MSCR-BO versions."""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import subprocess
import sys

import numpy as np

import run_pipeline as p

sys.path.insert(0, str(p.LEGACY))
from analyze_confirmatory_campaign import primary_test  # noqa: E402

DISPLAY_ARMS = {
    "NO_DIFFUSION": "MSCR-BO w/o diffusion",
    "NO_WALK": "MSCR-BO w/o elite walk",
    "NO_ACQ_OPT": "MSCR-BO w/o acquisition optimisation",
    "NO_REPAIR": "MSCR-BO w/o CASR",
    "NO_SPREAD_ANCHOR": "MSCR-BO w/o dispersed elite starts",
    "NO_GREEDY": "MSCR-BO w/o greedy joint selection",
    "QLOG_BASE": "qLogNEHVI baseline",
}

def reported_metrics(record: dict) -> list[float]:
    """Preserve the empty-archive convention used by the locked analysis."""
    result = []
    for index, value in enumerate(record["metrics"]):
        if value is None:
            result.append(float("inf") if index < 2 else
                          0.0 if index == 2 else float("nan"))
        else:
            result.append(float(value))
    return result


def cube_for(stage: str, compare: int | str) -> np.ndarray:
    cube = np.empty((8, 10, 4, 2), dtype=float)
    old_egbo = {}
    if stage == "final":
        path = p.OLD / "确认性独立验证_seed10_19" / "per_round_metrics.csv"
        with path.open(encoding="utf-8-sig", newline="") as stream:
            for row in csv.DictReader(stream):
                if row["method"] == "Author EGBO" and int(row["round"]) == 12:
                    old_egbo[int(row["test_id"]), int(row["seed"])] = [
                        float(row[name]) for name in
                        ("IGD", "GD", "HV_fixed_normalized", "Spacing")]
        assert len(old_egbo) == 80
    for ti, test in enumerate(p.TESTS):
        for si, seed in enumerate(p.SEEDS[stage]):
            a = json.loads((p.output(stage, test, seed, 1) / "run_status.json")
                           .read_text(encoding="utf-8"))
            if stage == "final":
                b = old_egbo[test, seed]
            else:
                b = json.loads((p.output(stage, test, seed, int(compare)) /
                                "run_status.json").read_text(encoding="utf-8"))["metrics"]
            cube[ti, si, :, 0] = reported_metrics(a)
            cube[ti, si, :, 1] = (b if stage == "final" else
                                  reported_metrics({"metrics": b}))
    return cube


def holm_adjust(p_values: list[float]) -> list[float]:
    ordered = np.argsort(p_values)
    adjusted = np.empty(len(p_values))
    ceiling = 0.0
    for rank, index in enumerate(ordered):
        ceiling = max(ceiling, min(1.0, (len(p_values) - rank) * p_values[index]))
        adjusted[index] = ceiling
    return adjusted.tolist()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=("quota", "ablation", "final"))
    args = parser.parse_args()
    if args.stage == "quota":
        selected = p.select_quota()
        (p.ROOT / "quota_conclusion.json").write_text(json.dumps({
            "method_id": "MSCR-BO",
            "algorithm_version": "joint_selection_v1",
            "selected": selected,
            "summary": json.loads((p.ROOT / "quota_summary.json").read_text(encoding="utf-8")),
            "interpretation": "The lowest mean rank selects the quota; no significance claim."},
            ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print("QUOTA_ANALYSIS_COMPLETE", flush=True)
        return
    if args.stage == "ablation":
        assert all(p.verify("ablation", t, s, a) for t in p.TESTS
                   for s in p.SEEDS["ablation"] for a in range(1, 9))
        results = {}
        for arm_id in range(2, 9):
            outcome = primary_test(cube_for("ablation", arm_id))
            results[p.ARMS[arm_id - 1]] = outcome
        adjusted = holm_adjust([results[arm]["one_sided_p_label_flip"]
                                for arm in results])
        for arm, value in zip(results, adjusted):
            results[arm]["method_id"] = (
                "qLogNEHVI" if arm == "QLOG_BASE" else "MSCR-BO")
            results[arm]["display_name"] = DISPLAY_ARMS[arm]
            results[arm]["holm_p"] = value
            results[arm]["supported_after_holm"] = bool(
                value < .05 and results[arm]["paired_bootstrap_95_ci"][0] > 0)
            results[arm]["interpretation"] = (
                "Exploratory ablation result; prior cases and seeds have been observed.")
            results[arm].pop("confirmatory_criterion_passed", None)
        (p.ROOT / "ablation_summary.json").write_text(json.dumps(results,
            ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        lines = ["# MSCR-BO：10 次配对组件消融结论", "",
                 "正分数表示完整算法优于消融组；此组实验属于探索性分析。",
                 "候选来源消融仅将配额按原比例分配给余下来源，保持每轮 144 个候选点。", "",
                 "| Ablated component | Full minus ablated score | 95% paired CI | One-sided p | Holm p | Conclusion |",
                 "|---|---:|---:|---:|---:|---|"]
        for arm, item in results.items():
            ci = item["paired_bootstrap_95_ci"]
            if item["supported_after_holm"]:
                label = "Positive contribution supported"
            elif ci[1] < 0:
                label = "Full algorithm worse in this ablation"
            else:
                label = "Positive contribution not established"
            lines.append(f"| {DISPLAY_ARMS[arm]} | {item['observed_score']:.4f} | "
                         f"[{ci[0]:.4f}, {ci[1]:.4f}] | "
                         f"{item['one_sided_p_label_flip']:.4g} | "
                         f"{item['holm_p']:.4g} | {label} |")
        (p.ROOT / "ablation_conclusion.md").write_text(
            "\n".join(lines) + "\n", encoding="utf-8")
        print("ABLATION_ANALYSIS_COMPLETE", flush=True)
        return
    assert all(p.verify("final", t, s, 1) for t in p.TESTS
               for s in p.SEEDS["final"])
    outcome = primary_test(cube_for("final", "EGBO"))
    outcome["method_id"] = "MSCR-BO"
    outcome["comparison_method_id"] = "EGBO"
    outcome["algorithm_version"] = "joint_selection_v1"
    outcome["interpretation"] = (
        "Paired evaluation of the selected MSCR-BO on ten seeds; prior EGBO outcomes were known, so this is not a fresh confirmatory holdout.")
    outcome.pop("confirmatory_criterion_passed", None)
    (p.ROOT / "final_vs_EGBO_summary.json").write_text(json.dumps(outcome,
        ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    subprocess.run([str(p.PYTHON), str(p.ROOT / "plot_final_results.py")],
                   cwd=p.ROOT, check=True)
    print("FINAL_EGBO_ANALYSIS_COMPLETE", flush=True)


if __name__ == "__main__":
    main()
