function run_stage_case(stage,test_id,seed,config_id)
%RUN_STAGE_CASE Paired quota, ablation, and final MSCR-BO experiments.
assert(ismember(test_id,[1 3 4 6 7 48 49 50]));
here=fileparts(mfilename('fullpath'));
legacy='F:\全局优化\DPR-qNEHVI_MATLAB';
addpath(legacy); addpath(here,'-begin'); cd(legacy);
old=fullfile(legacy,'科研实验报告_新版','MSCR_BO_冻结版后续实验');
quotas=[7 6 5;9 5 4;5 8 5;5 6 7];
arms={'FULL','NO_DIFFUSION','NO_WALK','NO_ACQ_OPT', ...
    'NO_REPAIR','NO_SPREAD_ANCHOR','NO_GREEDY','QLOG_BASE'};
if strcmp(stage,'quota')
    assert(ismember(seed,0:9) && ismember(config_id,1:4));
    initial=fullfile(old,'配对多种子_预算114_八函数','initial', ...
        sprintf('T%02d_seed%02d.csv',test_id,seed));
    quota=quotas(config_id,:); arm='FULL';
    out=fullfile(here,'results','quota',sprintf('Q%d',config_id), ...
        sprintf('T%02d',test_id),sprintf('seed%02d',seed));
elseif strcmp(stage,'ablation')
    assert(ismember(seed,20:29) && ismember(config_id,1:numel(arms)));
    initial=fullfile(old,'组件消融_15重复_预算114_八函数','initial', ...
        sprintf('T%02d_seed%02d.csv',test_id,seed));
    selected=jsondecode(fileread(fullfile(here,'selected_quota.json')));
    quota=reshape(selected.quota,1,[]); arm=arms{config_id};
    if ismember(arm,{'NO_DIFFUSION','NO_WALK','NO_ACQ_OPT'})
        k=find(strcmp(arm,{'NO_DIFFUSION','NO_WALK','NO_ACQ_OPT'}));
        quota=remaining_quota(quota,k);
    elseif strcmp(arm,'QLOG_BASE')
        quota=[18 0 0];
    end
    out=fullfile(here,'results','ablation',arm, ...
        sprintf('T%02d',test_id),sprintf('seed%02d',seed));
else
    assert(strcmp(stage,'final') && ismember(seed,10:19) && config_id==1);
    initial=fullfile(old,'确认性独立验证_seed10_19','initial', ...
        sprintf('T%02d_seed%02d.csv',test_id,seed));
    selected=jsondecode(fileread(fullfile(here,'selected_quota.json')));
    quota=reshape(selected.quota,1,[]); arm='FULL';
    out=fullfile(here,'results','final',sprintf('T%02d',test_id), ...
        sprintf('seed%02d',seed));
end
assert(sum(quota)==18 && all(quota>=0));
assert(exist(initial,'file')==2,'Locked paired initial data missing.');
obj=GetFunInfo(test_id); data=readmatrix(initial);
assert(size(data,1)==18 && size(data,2)>=obj.nVar+obj.numOfObj ...
    && all(isfinite(data(:))));
if ~exist(out,'dir'), mkdir(out); end
writematrix(data,fullfile(out,'round_00.csv'));
reference_root=fullfile(legacy,'科研实验报告_新版', ...
    '对比实验_预算114_八函数','EGBO_144_seed0');
[ref,~]=main_egbo_reference(obj,test_id,reference_root);
p=struct();
p.Nr=300; p.n_init=18; p.n_iter=12; p.q=8;
p.n_cand=quota(1); p.walk_batches=quota(2); p.acqf_starts=quota(3);
p.mc_samples=16; p.refine_topk=8; p.refine_rounds=0;
p.refine_sigma=.05; p.gp_alpha=1e-6;
p.repair_steps=30; p.repair_lr=.05; p.repair_tol=1e-3;
p.repair_k=8; p.repair_sigma=.15; p.surrogate_normalized_ls=1.5;
p.min_data=4; p.use_walk=true; p.walk_sigma=.10;
p.use_acqf=true; p.acqf_maxiter=40;
p=diffusion_params(p);
p.gp_kernel='rbf'; p.repair_gp_kernel='rbf';
p.coord_restart=false; p.surrogate_de=false;
p.acquisition='EGBO_qLogNEHVI';
p.repair_policy='engineering_safety_gate_v1';
p.repair_order='after_scoring'; p.scoring_rule='qlognehvi_raw_v2';
p.acq_ref_override=ref; p.fixed_ref_strict=true;
p.method_name='MSCR-BO'; p.algorithm_version='joint_selection_v1';
p.ablation_arm=arm; p.source_quota=quota;
p.frozen_initial_file=initial;
p.frozen_trace_file=fullfile(out,sprintf('trace_T%d_seed%d.mat',test_id,seed));
p.logfile=fullfile(out,'progress.log');
rng(seed,'twister');
status='ok'; err=''; elapsed=NaN; result=[];
metrics=[NaN NaN NaN NaN]; timer=tic;
try
    result=MSCR_BO_staged(p,obj);
    final=readmatrix(fullfile(out,'round_12.csv'));
    assert(isequal(size(final),[114 size(data,2)]) && all(isfinite(final(:))));
    assert(max(abs(final(1:18,:)-data),[],'all')<1e-8);
    F=result(:,obj.nVar+1:obj.nVar+obj.numOfObj);
    if isempty(F), metrics=[Inf Inf 0 NaN];
    else, metrics=gpu_metrics(F,obj.truePF); end
    writematrix(F,fullfile(out,'archive_front.csv'));
    writematrix(obj.truePF,fullfile(out,'reference_front.csv'));
catch ME
    status='error'; err=getReport(ME,'extended','hyperlinks','off');
end
elapsed=toc(timer);
save(fullfile(out,'case.mat'),'stage','test_id','seed','config_id', ...
    'quota','arm','status','err','elapsed','metrics','p','result','-v7.3');
fid=fopen(fullfile(out,'run_status.json'),'w'); assert(fid>0);
fprintf(fid,'%s\n',jsonencode(struct('stage',stage,'test_id',test_id, ...
    'seed',seed,'config_id',config_id,'quota',quota,'arm',arm, ...
    'status',status,'budget',114,'metrics',metrics, ...
    'elapsed_seconds',elapsed,'error',err)));
fclose(fid);
fprintf('STAGE %s T%d seed%d config%d status=%s elapsed=%.1f\n', ...
    stage,test_id,seed,config_id,status,elapsed);
assert(strcmp(status,'ok'),'%s',err);
end

function quota=remaining_quota(base,removed)
assert(numel(base)==3 && sum(base)==18 && ismember(removed,1:3));
base(removed)=0;
raw=18*base/sum(base); quota=floor(raw);
left=18-sum(quota); fractions=raw-quota;
fractions(base==0)=-Inf;
for j=1:left
    [~,k]=max(fractions); quota(k)=quota(k)+1;
    fractions(k)=-Inf;
end
assert(quota(removed)==0 && sum(quota)==18);
end
