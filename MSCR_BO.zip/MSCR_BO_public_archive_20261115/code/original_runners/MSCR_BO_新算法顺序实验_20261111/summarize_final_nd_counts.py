"""Count distinct feasible nondominated objective vectors from paired raw data."""
from __future__ import annotations

import csv
import json

import numpy as np

import run_pipeline as p

NAMES = {1: "ZDT1", 3: "ZDT3", 4: "ZDT4", 6: "DTLZ1",
         7: "DTLZ2", 48: "MW3", 49: "MW5", 50: "MW7"}
OUT = p.ROOT / "results" / "final"


def nd_count(f: np.ndarray, g: np.ndarray) -> int:
    feasible = f[np.all(g <= 0, axis=1)] if g.shape[1] else f
    if not len(feasible):
        return 0
    dominated = np.zeros(len(feasible), dtype=bool)
    for i, point in enumerate(feasible):
        dominated[i] = np.any(np.all(feasible <= point, axis=1) &
                              np.any(feasible < point, axis=1))
    return len(np.unique(feasible[~dominated], axis=0))


def paired_count(test: int, seed: int) -> tuple[int, int]:
    root = (p.OLD / "确认性独立验证_seed10_19" / "results" /
            f"T{test:02d}" / f"seed{seed:02d}" / "EGBO" / f"T{test:02d}")
    meta = json.loads((root / "metadata.json").read_text(encoding="utf-8"))
    d, m = meta["n_var"], meta["n_obj"]
    mscr = np.loadtxt(p.output("final", test, seed, 1) / "round_12.csv",
                      delimiter=",")
    egbo = np.loadtxt(root / "train_data.csv", delimiter=",")
    assert mscr.shape == egbo.shape and mscr.shape[0] == 114
    assert np.allclose(mscr[:18, :d], egbo[:18, :d], atol=1e-8, rtol=0)
    a = nd_count(mscr[:, d:d + m], mscr[:, d + m:])
    b = nd_count(-egbo[:, d:d + m], egbo[:, d + m:])
    return a, b


def write(path, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)


def main() -> None:
    rows = []
    summary = []
    for test in p.TESTS:
        for seed in p.SEEDS["final"]:
            if not p.verify("final", test, seed, 1):
                continue
            a, b = paired_count(test, seed)
            rows.append(dict(test=NAMES[test], test_id=test, seed=seed,
                             **{"MSCR-BO_nd": a, "EGBO_nd": b,
                                "difference": a - b}))
        group = [row for row in rows if row["test_id"] == test]
        if len(group) == 10:
            a = np.asarray([row["MSCR-BO_nd"] for row in group])
            b = np.asarray([row["EGBO_nd"] for row in group])
            summary.append(dict(test=NAMES[test], n_paired=10,
                                **{"MSCR-BO_median": float(np.median(a)),
                                "EGBO_median": float(np.median(b)),
                                "MSCR-BO_mean": float(a.mean()),
                                "EGBO_mean": float(b.mean()),
                                "median_paired_difference": float(np.median(a-b)),
                                "MSCR-BO_more": int(np.sum(a>b)),
                                "equal": int(np.sum(a==b)),
                                "EGBO_more": int(np.sum(a<b))}))
    write(OUT / "nd_counts_completed_seed_pairs.csv", rows)
    write(OUT / "nd_counts_completed_test_summary.csv", summary)
    for item in summary:
        print(item, flush=True)
    print("COMPLETE_TESTS", len(summary), "VALID_PAIRS", len(rows), flush=True)


if __name__ == "__main__":
    main()
