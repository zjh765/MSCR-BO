function run_main_case(test_id,seed)
%RUN_MAIN_CASE Active main MSCR-BO experiment after ten-repeat quota selection.
here=fileparts(mfilename('fullpath'));
addpath(here,'-begin');
config=jsondecode(fileread(fullfile(here,'main_config.json')));
selected=jsondecode(fileread(fullfile(here,'selected_quota.json')));
assert(isequal(reshape(config.source_quota,1,[]), ...
    reshape(selected.quota,1,[])) && ...
    config.source_quota_id==selected.quota_id, ...
    'Main source quota differs from the locked quota selection.');
assert(ismember(seed,10:19),'Main comparison seeds are 10 through 19.');
run_stage_case('final',test_id,seed,1);
end
