"""English, method-separated Pareto figures and paired convergence curves."""
from __future__ import annotations

import csv
import json
from pathlib import Path
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

import run_pipeline as p

sys.path.insert(0, str(p.LEGACY))
from analyze_frozen_campaign import evaluate, front  # noqa: E402


NAMES = {1: "ZDT1", 3: "ZDT3", 4: "ZDT4", 6: "DTLZ1",
         7: "DTLZ2", 48: "MW3", 49: "MW5", 50: "MW7"}
METHODS = ("MSCR-BO", "EGBO")
COLORS = {"MSCR-BO": "#163a5f", "EGBO": "#5a2a4a"}
REFERENCE_COLOR = "#8293a5"
REFERENCE_ALPHA = .8
METRICS = ("IGD", "GD", "HV_fixed_normalized", "Spacing")


def load_egbo(test: int, seed: int) -> tuple[np.ndarray, np.ndarray]:
    folder = (p.OLD / "确认性独立验证_seed10_19" / "results" /
              f"T{test:02d}" / f"seed{seed:02d}" / "EGBO" /
              f"T{test:02d}")
    meta = json.loads((folder / "metadata.json").read_text(encoding="utf-8"))
    data = np.loadtxt(folder / "train_data.csv", delimiter=",")
    d, m = meta["n_var"], meta["n_obj"]
    return -data[:, d:d + m], data[:, d + m:]


def load_mscr(test: int, seed: int, round_id: int) -> tuple[np.ndarray, np.ndarray]:
    data = np.loadtxt(p.output("final", test, seed, 1) /
                      f"round_{round_id:02d}.csv", delimiter=",")
    m = 3 if test in (6, 7) else 2
    d = data.shape[1] - m
    if test in (48, 49, 50):
        d = json.loads((p.OLD / "确认性独立验证_seed10_19" / "results" /
                        f"T{test:02d}" / f"seed{seed:02d}" / "EGBO" /
                        f"T{test:02d}" / "metadata.json").read_text(
                            encoding="utf-8"))["n_var"]
    return data[:, d:d + m], data[:, d + m:]


def pareto_figures(out: Path) -> None:
    figdir = out / "pareto_figures"
    figdir.mkdir(exist_ok=True)
    for test in p.TESTS:
        pf = np.loadtxt(p.output("final", test, 10, 1) /
                        "reference_front.csv", delimiter=",")
        pools: dict[str, np.ndarray] = {}
        for method in METHODS:
            pieces = []
            for seed in p.SEEDS["final"]:
                f, g = (load_mscr(test, seed, 12) if method == "MSCR-BO"
                        else load_egbo(test, seed))
                archive = front(f, g)
                if len(archive):
                    pieces.append(archive)
            pools[method] = (np.concatenate(pieces) if pieces else
                             np.empty((0, pf.shape[1])))
        joined = np.concatenate((pf, *pools.values()))
        limits = []
        for axis in range(pf.shape[1]):
            low, high = np.min(joined[:, axis]), np.max(joined[:, axis])
            pad = max((high - low) * .04, 1e-8)
            limits.append((low - pad, high + pad))
        for method in METHODS:
            fig = plt.figure(figsize=(6.4, 5.3), dpi=160)
            if pf.shape[1] == 3:
                ax = fig.add_subplot(111, projection="3d")
                ax.scatter(*pf.T, s=5, color=REFERENCE_COLOR,
                           alpha=REFERENCE_ALPHA,
                           label="Reference front", depthshade=False)
                if len(pools[method]):
                    ax.scatter(*pools[method].T, s=12,
                               color=COLORS[method], alpha=.8,
                               label=method, depthshade=False)
                ax.set_zlim(*limits[2])
                ax.set_zlabel("f3")
            else:
                ax = fig.add_subplot(111)
                ax.scatter(pf[:, 0], pf[:, 1], s=7,
                           color=REFERENCE_COLOR, alpha=REFERENCE_ALPHA,
                           label="Reference front", rasterized=True)
                if len(pools[method]):
                    ax.scatter(pools[method][:, 0], pools[method][:, 1],
                               s=13, color=COLORS[method], alpha=.8,
                               label=method, rasterized=True)
                ax.grid(alpha=.22)
            ax.set_xlim(*limits[0]); ax.set_ylim(*limits[1])
            ax.set_xlabel("f1"); ax.set_ylabel("f2")
            ax.set_title(f"{NAMES[test]} — {method} (10 paired seeds)")
            ax.legend(loc="best", frameon=False)
            fig.tight_layout()
            fig.savefig(figdir / f"{NAMES[test]}_{method.replace(' ', '_')}.png",
                        dpi=220)
            plt.close(fig)


def convergence(out: Path) -> None:
    prior = p.OLD / "确认性独立验证_seed10_19" / "per_round_metrics.csv"
    old = {}
    with prior.open(encoding="utf-8-sig", newline="") as stream:
        for row in csv.DictReader(stream):
            if row["method"] == "Author EGBO":
                old[int(row["test_id"]), int(row["seed"]),
                    int(row["round"])] = row
    assert len(old) == 8 * 10 * 13
    rows = []
    for test in p.TESTS:
        pf = np.loadtxt(p.output("final", test, 10, 1) /
                        "reference_front.csv", delimiter=",")
        lower = np.minimum(0, pf.min(axis=0))
        upper = lower + 1.1 * (pf.max(axis=0) - lower)
        for seed in p.SEEDS["final"]:
            for round_id in range(13):
                f, g = load_mscr(test, seed, round_id)
                metric = evaluate(f, g, pf, lower, upper)
                rows.append(dict(test_id=test, seed=seed, method="MSCR-BO",
                                 round=round_id, evaluations=18 + 8 * round_id,
                                 **metric))
                item = old[test, seed, round_id]
                rows.append(dict(test_id=test, seed=seed,
                                 method="EGBO", round=round_id,
                                 evaluations=18 + 8 * round_id,
                                 **{name: float(item[name]) for name in METRICS},
                                 archive_size=int(item["archive_size"])))
    with (out / "per_round_metrics.csv").open("w", encoding="utf-8-sig",
                                                newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)
    rng = np.random.default_rng(20261111)
    summary = []
    for test in p.TESTS:
        for method in METHODS:
            for metric in METRICS:
                values = np.asarray([r[metric] for r in rows
                                     if r["test_id"] == test and
                                     r["method"] == method and r["round"] == 12],
                                    dtype=float)
                finite = values[np.isfinite(values)]
                if len(finite):
                    means = finite[rng.integers(len(finite),
                                                size=(5000, len(finite)))].mean(axis=1)
                    ci = np.quantile(means, [.025, .975])
                    mean, median = float(np.mean(finite)), float(np.median(finite))
                    q25, q75 = np.quantile(finite, [.25, .75])
                else:
                    ci = (np.nan, np.nan); mean = median = q25 = q75 = np.nan
                summary.append(dict(test=NAMES[test], method=method,
                                    metric=metric, n_total=10,
                                    n_finite=len(finite),
                                    n_nonfinite=10-len(finite),
                                    mean=mean, median=median, q25=q25, q75=q75,
                                    mean_bootstrap_95_low=ci[0],
                                    mean_bootstrap_95_high=ci[1]))
    with (out / "terminal_metric_distributions.csv").open(
            "w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(summary[0]))
        writer.writeheader(); writer.writerows(summary)
    figdir = out / "convergence_figures"
    figdir.mkdir(exist_ok=True)
    for test in p.TESTS:
        for metric in METRICS:
            fig, ax = plt.subplots(figsize=(6.4, 4.2), dpi=160)
            for method in METHODS:
                median, lower_band, upper_band = [], [], []
                for round_id in range(13):
                    values = np.asarray([row[metric] for row in rows
                                         if row["test_id"] == test and
                                         row["method"] == method and
                                         row["round"] == round_id], dtype=float)
                    finite = values[np.isfinite(values)]
                    if len(finite):
                        median.append(float(np.median(finite)))
                        lower_band.append(float(np.quantile(finite, .25)))
                        upper_band.append(float(np.quantile(finite, .75)))
                    else:
                        median.append(np.nan); lower_band.append(np.nan)
                        upper_band.append(np.nan)
                x = 18 + 8 * np.arange(13)
                ax.plot(x, median, marker="o", ms=3, linewidth=1.8,
                        color=COLORS[method], label=method)
                ax.fill_between(x, lower_band, upper_band,
                                color=COLORS[method], alpha=.13)
            ax.set_xlabel("True evaluations")
            ax.set_ylabel(metric.replace("_fixed_normalized", " (fixed)"))
            ax.set_title(f"{NAMES[test]} — {metric}")
            ax.grid(alpha=.22); ax.legend(frameon=False)
            fig.tight_layout()
            fig.savefig(figdir / f"{NAMES[test]}_{metric}.png", dpi=220)
            plt.close(fig)


if __name__ == "__main__":
    target = p.ROOT / "final_figures"
    target.mkdir(exist_ok=True)
    pareto_figures(target)
    convergence(target)
    print("FINAL_FIGURES_COMPLETE", flush=True)
