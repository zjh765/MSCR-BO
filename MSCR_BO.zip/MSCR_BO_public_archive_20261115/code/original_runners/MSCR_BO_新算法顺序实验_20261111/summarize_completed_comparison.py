"""Snapshot only fully completed ten-seed test functions during final runs."""
from __future__ import annotations

import csv
from pathlib import Path

import numpy as np

import run_pipeline as p

METRICS = ("IGD", "GD", "HV_fixed_normalized", "Spacing")
NAMES = {1: "ZDT1", 3: "ZDT3", 4: "ZDT4", 6: "DTLZ1",
         7: "DTLZ2", 48: "MW3", 49: "MW5", 50: "MW7"}
OUT = p.ROOT / "results" / "final"


def old_egbo() -> dict[tuple[int, int], dict[str, float]]:
    path = p.OLD / "确认性独立验证_seed10_19" / "per_round_metrics.csv"
    result = {}
    with path.open(encoding="utf-8-sig", newline="") as stream:
        for row in csv.DictReader(stream):
            if row["method"] == "Author EGBO" and int(row["round"]) == 12:
                result[int(row["test_id"]), int(row["seed"])] = {
                    metric: float(row[metric]) for metric in METRICS}
    assert len(result) == 80
    return result


def write_csv(path: Path, rows: list[dict]) -> None:
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)


def main() -> None:
    old = old_egbo()
    completed = [test for test in p.TESTS if all(
        p.verify("final", test, seed, 1) for seed in p.SEEDS["final"])]
    assert completed
    pairs = []
    summary = []
    for test in completed:
        for seed in p.SEEDS["final"]:
            import json
            item = json.loads((p.output("final", test, seed, 1) /
                               "run_status.json").read_text(encoding="utf-8"))
            for mi, metric in enumerate(METRICS):
                value = item["metrics"][mi]
                mscr = float(value) if value is not None else float("nan")
                egbo = old[test, seed][metric]
                pairs.append(dict(test=NAMES[test], test_id=test, seed=seed,
                                  metric=metric, **{"MSCR-BO": mscr, "EGBO": egbo}))
        for metric in METRICS:
            rows = [r for r in pairs if r["test_id"] == test and r["metric"] == metric]
            a = np.array([r["MSCR-BO"] for r in rows], dtype=float)
            b = np.array([r["EGBO"] for r in rows], dtype=float)
            mask = np.isfinite(a) & np.isfinite(b)
            if mask.any():
                aa, bb = a[mask], b[mask]
                wins = int(np.sum(aa > bb if metric == "HV_fixed_normalized"
                                  else aa < bb))
                ties = int(np.sum(aa == bb))
            else:
                wins = ties = 0
            summary.append(dict(test=NAMES[test], metric=metric,
                                **{"MSCR-BO_median": float(np.median(a[np.isfinite(a)]))
                                if np.isfinite(a).any() else np.nan,
                                "EGBO_median": float(np.median(b[np.isfinite(b)]))
                                if np.isfinite(b).any() else np.nan,
                                "MSCR-BO_finite": int(np.isfinite(a).sum()),
                                "EGBO_finite": int(np.isfinite(b).sum()),
                                "comparable_pairs": int(mask.sum()),
                                "MSCR-BO_wins": wins, "ties": ties,
                                "EGBO_wins": int(mask.sum())-wins-ties}))
    write_csv(OUT / "interim_completed_seed_pairs.csv", pairs)
    write_csv(OUT / "interim_completed_test_summary.csv", summary)
    for test in completed:
        print(NAMES[test], [r for r in summary if r["test"] == NAMES[test]], flush=True)
    print("FULLY_COMPLETED_TESTS", len(completed), "OF", len(p.TESTS), flush=True)


if __name__ == "__main__":
    main()
