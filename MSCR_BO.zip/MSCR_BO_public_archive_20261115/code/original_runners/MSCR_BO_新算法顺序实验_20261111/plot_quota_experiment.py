"""Plot all ten-seed quota outcomes, preserving raw results and missing values."""
from __future__ import annotations

import csv
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image

import run_pipeline as campaign


NAMES = {1: "ZDT1", 3: "ZDT3", 4: "ZDT4", 6: "DTLZ1",
         7: "DTLZ2", 48: "MW3", 49: "MW5", 50: "MW7"}
QUOTA_COLORS = ("#183b66", "#7a321e", "#185638", "#4d3478")
REFERENCE_COLOR = "#8293a5"
REFERENCE_ALPHA = .8
METRICS = ("IGD", "GD", "Fixed-reference HV", "Spacing")
PLOTS = campaign.ROOT / "results" / "quota" / "figures"


def nondominated_objectives(data: np.ndarray, d: int, m: int) -> np.ndarray:
    objectives = data[:, d:d + m]
    constraints = data[:, d + m:]
    if constraints.shape[1]:
        objectives = objectives[np.all(constraints <= 0, axis=1)]
    if not len(objectives):
        return np.empty((0, m))
    keep = np.ones(len(objectives), dtype=bool)
    for index, candidate in enumerate(objectives):
        keep[index] = not np.any(
            np.all(objectives <= candidate, axis=1) &
            np.any(objectives < candidate, axis=1))
    return np.unique(objectives[keep], axis=0)


def metadata(test: int) -> tuple[int, int]:
    path = (campaign.OLD / "确认性独立验证_seed10_19" / "results" /
            f"T{test:02d}" / "seed10" / "EGBO" / f"T{test:02d}" /
            "metadata.json")
    item = json.loads(path.read_text(encoding="utf-8"))
    return item["n_var"], item["n_obj"]


def read_test(test: int) -> tuple[np.ndarray, list[np.ndarray], list[list[np.ndarray]], np.ndarray]:
    d, m = metadata(test)
    reference = None
    pooled = []
    by_seed = []
    metrics = np.empty((4, 10, 4), dtype=float)
    for qi in range(4):
        seeds = []
        for seed in range(10):
            assert campaign.verify("quota", test, seed, qi + 1), (test, seed, qi)
            folder = campaign.output("quota", test, seed, qi + 1)
            data = np.loadtxt(folder / "round_12.csv", delimiter=",")
            assert data.shape[0] == 114 and data.shape[1] >= d + m
            archive = nondominated_objectives(data, d, m)
            seeds.append(archive)
            record = json.loads((folder / "run_status.json").read_text(encoding="utf-8"))
            assert record["quota"] == list(campaign.QUOTAS[qi])
            for mi, value in enumerate(record["metrics"]):
                metrics[qi, seed, mi] = (float(value) if value is not None
                                         else np.nan)
            pf = np.loadtxt(folder / "reference_front.csv", delimiter=",")
            if reference is None:
                reference = pf
            else:
                assert pf.shape == reference.shape and np.allclose(pf, reference)
        by_seed.append(seeds)
        pooled.append(np.concatenate([a for a in seeds if len(a)], axis=0)
                      if any(len(a) for a in seeds) else np.empty((0, m)))
    assert reference is not None
    return reference, pooled, by_seed, metrics


def limits(reference: np.ndarray, pooled: list[np.ndarray]) -> list[tuple[float, float]]:
    all_points = np.concatenate([reference] + [a for a in pooled if len(a)])
    result = []
    for axis in range(all_points.shape[1]):
        low = float(np.min(all_points[:, axis]))
        high = float(np.max(all_points[:, axis]))
        pad = max((high - low) * .04, 1e-8)
        result.append((low - pad, high + pad))
    return result


def pareto_figure(test: int, reference: np.ndarray, pooled: list[np.ndarray],
                  axis_limits: list[tuple[float, float]]) -> list[str]:
    m = reference.shape[1]
    fig = plt.figure(figsize=(16, 4.5 if m == 2 else 5.1),
                     layout="constrained")
    images = []
    for qi, points in enumerate(pooled):
        ax = fig.add_subplot(1, 4, qi + 1,
                             projection="3d" if m == 3 else None)
        if m == 2:
            ax.scatter(reference[:, 0], reference[:, 1], s=7,
                       color=REFERENCE_COLOR, alpha=REFERENCE_ALPHA,
                       rasterized=True,
                       label="Reference front")
            if len(points):
                ax.scatter(points[:, 0], points[:, 1], s=13,
                           color=QUOTA_COLORS[qi], alpha=.78,
                           edgecolors="none", rasterized=True,
                           label="Feasible nondominated")
            ax.set_xlim(*axis_limits[0]); ax.set_ylim(*axis_limits[1])
            ax.grid(alpha=.22)
        else:
            ax.scatter(*reference.T, s=4, color=REFERENCE_COLOR,
                       alpha=REFERENCE_ALPHA,
                       depthshade=False, rasterized=True,
                       label="Reference front")
            if len(points):
                ax.scatter(*points.T, s=11, color=QUOTA_COLORS[qi],
                           alpha=.78, depthshade=False, rasterized=True,
                           label="Feasible nondominated")
            ax.set_xlim(*axis_limits[0]); ax.set_ylim(*axis_limits[1])
            ax.set_zlim(*axis_limits[2]); ax.set_zlabel("f3")
            ax.view_init(elev=22, azim=-62)
        ax.set_title(f"MSCR-BO ({':'.join(map(str, campaign.QUOTAS[qi]))})",
                     fontsize=11)
        ax.set_xlabel("f1"); ax.set_ylabel("f2")
        if qi == 0:
            ax.legend(loc="upper center" if m == 2 else "upper left",
                      fontsize=8, frameon=False)
    fig.suptitle(f"{NAMES[test]} — final feasible nondominated archives of 10 seeds",
                 fontsize=13)
    path = PLOTS / f"{NAMES[test]}_Pareto_4quotas.png"
    fig.savefig(path, dpi=220, facecolor="white")
    plt.close(fig)
    images.append(path.name)
    return images


def metric_figure(test: int, metrics: np.ndarray) -> str:
    fig, axes = plt.subplots(2, 2, figsize=(11.6, 8.0),
                             layout="constrained")
    rng = np.random.default_rng(20261111 + test)
    for mi, ax in enumerate(axes.flat):
        for qi in range(4):
            values = metrics[qi, :, mi]
            finite = values[np.isfinite(values)]
            if len(finite):
                x = qi + 1 + rng.uniform(-.075, .075, size=len(finite))
                ax.scatter(x, finite, s=30, color=QUOTA_COLORS[qi],
                           alpha=.85, edgecolors="white", linewidths=.3,
                           zorder=3)
                median = float(np.median(finite))
                ax.plot([qi + .78, qi + 1.22], [median, median],
                        color="black", linewidth=1.2, zorder=4)
            missing = len(values) - len(finite)
            if missing:
                ax.text(qi + 1, .97, f"{missing} missing/nonfinite",
                        transform=ax.get_xaxis_transform(), ha="center",
                        va="top", fontsize=7, color="#7a1d1d")
        ax.set_xlim(.5, 4.5)
        ax.set_xticks(range(1, 5),
                      [f"MSCR-BO ({':'.join(map(str, campaign.QUOTAS[i-1]))})"
                       for i in range(1, 5)], rotation=15, ha="right")
        ax.set_ylabel(METRICS[mi]); ax.grid(axis="y", alpha=.22)
        ax.set_title(METRICS[mi])
        if mi == 2 and np.all(metrics[:, :, mi] == 0):
            ax.set_ylim(0, .05)
            ax.text(.5, .9, "HV = 0 in all 40 runs",
                    transform=ax.transAxes, ha="center", va="top",
                    fontsize=9, color="#555555")
    fig.suptitle(f"{NAMES[test]} — final metrics across 10 paired seeds\n"
                 "Dots: individual seeds; black bar: median", fontsize=13)
    path = PLOTS / f"{NAMES[test]}_metrics_4quotas.png"
    fig.savefig(path, dpi=210, facecolor="white")
    plt.close(fig)
    return path.name


def main() -> None:
    PLOTS.mkdir(parents=True, exist_ok=True)
    manifest = {"method_id": "MSCR-BO", "algorithm_version": "joint_selection_v1",
                "source": "results/quota/Q1-Q4/Txx/seedxx",
                "seeds": list(range(10)),
                "quotas": [list(q) for q in campaign.QUOTAS],
                "archive_policy": "feasible nondominated within each final 114-evaluation run; ten run archives overlaid without cross-seed filtering",
                "reference_policy": "the saved benchmark reference_front.csv is shown in medium-light gray in all four panels; drawn before the darker method points",
                "reference_style": {"color": REFERENCE_COLOR, "alpha": REFERENCE_ALPHA},
                "axes": "identical axis limits across the four quota panels for each test; limits include all plotted points",
                "metric_policy": "all ten seed values shown; black bar is finite median; missing/nonfinite values counted, not converted to zero",
                "figures": []}
    metric_rows = []
    for test in campaign.TESTS:
        reference, pooled, by_seed, values = read_test(test)
        axis_limits = limits(reference, pooled)
        fronts = pareto_figure(test, reference, pooled, axis_limits)
        metric = metric_figure(test, values)
        manifest["figures"].append({"test": NAMES[test],
                                    "pareto": fronts, "metrics": metric,
                                    "archive_counts_by_quota_and_seed": [
                                        [len(a) for a in group] for group in by_seed],
                                    "axis_limits": axis_limits})
        for qi in range(4):
            for seed in range(10):
                metric_rows.append({"test": NAMES[test], "method": "MSCR-BO",
                                    "quota_id": qi + 1,
                                    "quota": ":".join(map(str, campaign.QUOTAS[qi])),
                                    "seed": seed, "archive_size": len(by_seed[qi][seed]),
                                    **{METRICS[mi]: values[qi, seed, mi]
                                       for mi in range(4)}})
        print(f"PLOTTED {NAMES[test]}", flush=True)
    with (PLOTS / "quota_figure_source_data.csv").open(
            "w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(metric_rows[0]))
        writer.writeheader(); writer.writerows(metric_rows)
    (PLOTS / "figure_manifest.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8")
    for item in manifest["figures"]:
        for name in item["pareto"] + [item["metrics"]]:
            with Image.open(PLOTS / name) as image:
                assert image.width >= 2000 and image.height >= 800
                image.verify()
    print("ALL_QUOTA_FIGURES_VERIFIED", flush=True)


if __name__ == "__main__":
    main()
