"""Post hoc pooled per-case summaries for RCM21 and RCM27 (15 paired seeds)."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np

from audit_fixed_reference_hv import score_many


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
MAIN_CSV = ROOT / "MSCR_BO_工程三案例_配对10次_20261114" / "terminal_seed_metrics.csv"
NEW_CSV = ROOT / "MSCR_BO_独立5种子配对验证_20261114" / "terminal_seed_metrics.csv"
OUTPUT = HERE / "pooled_engineering_15_seed_summary.json"
CASES = (("RCM21", 54), ("RCM27", 57))
METHODS = ("MSCR-BO", "EGBO")
METRICS = ("IGD", "GD", "HV_fixed", "Spacing")
N_BOOTSTRAP = 20_000
N_EXACT_FLIPS = 1 << 15


def read_rows(path: Path) -> dict[tuple[str, int, str], dict[str, str]]:
    with path.open(encoding="utf-8-sig", newline="") as stream:
        return {
            (row["case"], int(row["seed"]), row["method"]): row
            for row in csv.DictReader(stream)
            if int(row["round"]) == 12 and row["case"] in {name for name, _ in CASES}
        }


def make_cube(rows: dict, case: str, seeds: range) -> np.ndarray:
    cube = np.empty((1, len(seeds), len(METRICS), len(METHODS)), dtype=float)
    for si, seed in enumerate(seeds):
        for mi, method in enumerate(METHODS):
            row = rows[case, seed, method]
            assert int(row["true_evaluations"]) == 114
            cube[0, si, :, mi] = [float(row[metric]) for metric in METRICS]
    return cube


def value(cube: np.ndarray) -> tuple[float, dict[str, float], np.ndarray]:
    valid = np.isfinite(cube[:, :, 3, :]).all(axis=(1, 2))
    score, cells = score_many(cube[None], valid)
    return float(score[0]), dict(zip(METRICS, cells[0, 0].tolist())), valid


def summarize(case: str, case_id: int, main_rows: dict, new_rows: dict) -> dict:
    original = make_cube(main_rows, case, range(60, 70))
    fresh = make_cube(new_rows, case, range(100, 105))
    cube = np.concatenate((original, fresh), axis=1)
    observed, parts, valid = value(cube)
    expected_original = {"RCM21": 0.15615841376604436, "RCM27": 0.05641767344342929}
    expected_fresh = {"RCM21": 0.1334, "RCM27": 0.0523}
    assert abs(value(original)[0] - expected_original[case]) < 1e-12
    assert abs(value(fresh)[0] - expected_fresh[case]) < 0.0001

    rng = np.random.default_rng(20261114 + case_id)
    bootstrap = []
    for _ in range(N_BOOTSTRAP // 1000):
        indices = rng.integers(15, size=(1000, 1, 15))
        sampled = np.take_along_axis(
            np.broadcast_to(cube, (1000,) + cube.shape), indices[..., None, None], axis=2
        )
        bootstrap.extend(score_many(sampled, valid)[0].tolist())

    extreme = 0
    for start in range(0, N_EXACT_FLIPS, 1024):
        assignments = np.arange(start, min(start + 1024, N_EXACT_FLIPS), dtype=np.uint32)
        switch = ((assignments[:, None] >> np.arange(15)) & 1).astype(bool)[:, None, :]
        original_batch = np.broadcast_to(cube, (len(assignments),) + cube.shape)
        permuted = np.where(switch[..., None, None], original_batch[..., ::-1], original_batch)
        scores, _ = score_many(permuted, valid)
        extreme += int(np.count_nonzero(scores >= observed - 1e-14))

    return {
        "score": observed,
        "metric_parts": parts,
        "paired_bootstrap_95_ci": np.quantile(bootstrap, [0.025, 0.975]).tolist(),
        "one_sided_exact_label_flip_p": (extreme + 1) / (N_EXACT_FLIPS + 1),
        "n_exact_assignments": N_EXACT_FLIPS,
        "n_bootstrap": N_BOOTSTRAP,
        "original_ten_score": value(original)[0],
        "new_five_score": value(fresh)[0],
    }


def main() -> None:
    main_rows, new_rows = read_rows(MAIN_CSV), read_rows(NEW_CSV)
    result = {
        "analysis_status": "post_hoc_pooled_summary; original and new-seed results retained separately",
        "source_csvs": [str(MAIN_CSV.relative_to(ROOT)), str(NEW_CSV.relative_to(ROOT))],
        "seeds": list(range(60, 70)) + list(range(100, 105)),
        "cases": {
            case: summarize(case, case_id, main_rows, new_rows)
            for case, case_id in CASES
        },
    }
    OUTPUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
