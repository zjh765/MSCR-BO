"""Audit metric consistency from all true-evaluated final archives.

This does not rerun optimisation or modify experimental records. It applies
one common reference front and fixed HV evaluation box per problem to each
quota and component arm, then writes audit summaries next to the manuscript.
"""

from __future__ import annotations

import csv
import json
import math
from pathlib import Path

import numpy as np

from audit_fixed_reference_hv import score_many


HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[1]
MAIN = WORKSPACE / "MSCR_BO_新算法顺序实验_20261111"
OLD = Path(r"F:\全局优化\DPR-qNEHVI_MATLAB\科研实验报告_新版\MSCR_BO_冻结版后续实验\确认性独立验证_seed10_19")
TESTS = (1, 3, 4, 6, 7, 48, 49, 50)
ARMS = ("FULL", "NO_DIFFUSION", "NO_WALK", "NO_ACQ_OPT", "NO_REPAIR", "NO_SPREAD_ANCHOR", "NO_GREEDY", "QLOG_BASE")
QUOTAS = ("Q1", "Q2", "Q3", "Q4")
METRICS = ("IGD", "GD", "HV_fixed_normalized", "Spacing")
N_BOOTSTRAP = 20_000
N_PERMUTATIONS = 100_000
RNG_SEED = 20261106


def read_array(path: Path) -> np.ndarray:
    arr = np.loadtxt(path, delimiter=",")
    return arr.reshape(1, -1) if arr.ndim == 1 else arr


def front(f: np.ndarray, g: np.ndarray) -> np.ndarray:
    feasible = f[np.all(g <= 0, axis=1)] if g.shape[1] else f
    if not len(feasible):
        return feasible
    keep = np.ones(len(feasible), dtype=bool)
    for i, point in enumerate(feasible):
        keep[i] = not np.any(np.all(feasible <= point, axis=1) & np.any(feasible < point, axis=1))
    return np.unique(feasible[keep], axis=0)


def hv2(points: np.ndarray) -> float:
    if len(points) == 0:
        return 0.0
    ordered = points[np.argsort(points[:, 0], kind="stable")]
    best_y = np.minimum.accumulate(ordered[:, 1])
    widths = np.diff(np.r_[ordered[:, 0], 1.0])
    return float(np.dot(widths, np.maximum(1.0 - best_y, 0)))


def fixed_hv(points: np.ndarray, lower: np.ndarray, upper: np.ndarray) -> float:
    if len(points) == 0:
        return 0.0
    normal = (points - lower) / (upper - lower)
    normal = normal[np.all(normal <= 1.0, axis=1)]
    if len(normal) == 0:
        return 0.0
    if normal.shape[1] == 2:
        return hv2(normal)
    xs = np.unique(normal[:, 0])
    volume = 0.0
    for i, x in enumerate(xs):
        width = (xs[i + 1] - x) if i + 1 < len(xs) else (1.0 - x)
        volume += width * hv2(normal[normal[:, 0] <= x, 1:])
    return float(volume)


def distances(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    return np.sqrt(np.sum((a[:, None, :] - b[None, :, :]) ** 2, axis=2)).min(axis=1)


def metrics_from_archive(archive: np.ndarray, pf: np.ndarray, n_var: int, n_obj: int) -> tuple[list[float], int]:
    f = archive[:, n_var:n_var + n_obj]
    g = archive[:, n_var + n_obj:]
    a = front(f, g)
    if len(a) == 0:
        return [math.inf, math.inf, 0.0, math.nan], 0
    lower = np.minimum(0, pf.min(axis=0))
    upper = lower + 1.1 * (pf.max(axis=0) - lower)
    igd = float(np.mean(distances(pf, a)))
    nearest = distances(a, pf)
    gd = float(np.linalg.norm(nearest) / len(nearest))
    hv = fixed_hv(a, lower, upper)
    if len(a) < 2:
        spacing = math.nan
    else:
        manhattan = np.sum(np.abs(a[:, None, :] - a[None, :, :]), axis=2)
        np.fill_diagonal(manhattan, np.inf)
        spacing = float(np.std(manhattan.min(axis=1), ddof=1))
    return [igd, gd, hv, spacing], len(a)


def rank(values: list[float], reverse: bool) -> list[float]:
    order = sorted(range(len(values)), key=lambda i: (
        not np.isfinite(values[i]), -values[i] if reverse else values[i]))
    result = [0.0] * len(values)
    pos = 0
    while pos < len(values):
        end = pos + 1
        while end < len(values) and (
            values[order[end]] == values[order[pos]] or
            (not np.isfinite(values[order[end]]) and not np.isfinite(values[order[pos]]))
        ):
            end += 1
        for index in order[pos:end]:
            result[index] = (pos + 1 + end) / 2
        pos = end
    return result


def paired_inference(cube: np.ndarray, spacing_valid: np.ndarray, observed: float) -> tuple[list[float], float]:
    rng = np.random.default_rng(RNG_SEED)
    boot = []
    for _ in range(N_BOOTSTRAP // 1000):
        indices = rng.integers(10, size=(1000, 8, 10))
        sampled = np.take_along_axis(np.broadcast_to(cube, (1000,) + cube.shape),
                                     indices[..., None, None], axis=2)
        values, _ = score_many(sampled, spacing_valid)
        boot.extend(values.tolist())
    ci = np.quantile(boot, [0.025, 0.975]).tolist()
    extreme = 0
    for _ in range(N_PERMUTATIONS // 1000):
        switch = rng.integers(2, size=(1000, 8, 10), dtype=np.int8).astype(bool)
        original = np.broadcast_to(cube, (1000,) + cube.shape)
        permuted = np.where(switch[..., None, None], original[..., ::-1], original)
        values, _ = score_many(permuted, spacing_valid)
        extreme += int(np.count_nonzero(values >= observed - 1e-14))
    return ci, (extreme + 1) / (N_PERMUTATIONS + 1)


def holm_adjust(p_values: list[float]) -> list[float]:
    order = np.argsort(p_values)
    result = np.empty(len(p_values))
    ceiling = 0.0
    for rank_no, index in enumerate(order):
        ceiling = max(ceiling, min(1.0, (len(p_values) - rank_no) * p_values[index]))
        result[index] = ceiling
    return result.tolist()


def main() -> None:
    rows = []
    meta_by_test = {}
    pf_by_test = {}
    for test in TESTS:
        folder = OLD / "results" / f"T{test:02d}" / "seed10" / "EGBO" / f"T{test:02d}"
        meta_by_test[test] = json.loads((folder / "metadata.json").read_text(encoding="utf-8"))
        pf_by_test[test] = read_array(MAIN / "results" / "final" / f"T{test:02d}" / "seed10" / "reference_front.csv")
    stages = (("quota", QUOTAS, range(10)), ("ablation", ARMS, range(20, 30)), ("final", ("FULL",), range(10, 20)))
    for stage, arms, seeds in stages:
        for arm in arms:
            for test in TESTS:
                meta = meta_by_test[test]
                for seed in seeds:
                    folder = MAIN / "results" / stage
                    if stage != "final":
                        folder = folder / arm
                    folder = folder / f"T{test:02d}" / f"seed{seed:02d}"
                    archive = read_array(folder / "round_12.csv")
                    assert archive.shape == (114, meta["n_var"] + meta["n_obj"] + meta["n_constr"])
                    values, size = metrics_from_archive(archive, pf_by_test[test], meta["n_var"], meta["n_obj"])
                    rows.append({"stage": stage, "arm": arm, "test_id": test, "seed": seed,
                                 "IGD": values[0], "GD": values[1], "HV_fixed_normalized": values[2],
                                 "Spacing": values[3], "archive_size": size})
        print(stage, "audited", len(arms) * len(TESTS) * len(tuple(seeds)), "final archives", flush=True)
    csv_path = HERE / "corrected_archive_metrics.csv"
    with csv_path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

    # Verify that the full-arm audit matches the independently generated
    # per-round CSV used for the terminal standard comparison.
    with (MAIN / "final_figures" / "per_round_metrics.csv").open(encoding="utf-8-sig", newline="") as stream:
        prior_rows = list(csv.DictReader(stream))
    prior = {(int(x["test_id"]), int(x["seed"])): x for x in prior_rows
             if x["method"] == "MSCR-BO" and int(x["round"]) == 12}
    for row in rows:
        if row["stage"] == "final":
            old = prior[row["test_id"], row["seed"]]
            for metric in METRICS:
                a, b = float(row[metric]), float(old[metric])
                assert (np.isnan(a) and np.isnan(b)) or abs(a - b) < 2e-8, (row, metric, b)

    lookup = {(r["stage"], r["arm"], r["test_id"], r["seed"]): r for r in rows}
    quota_scores = np.empty((4, 8, 10))
    for ti, test in enumerate(TESTS):
        for si, seed in enumerate(range(10)):
            metric_ranks = []
            for metric in METRICS:
                values = [float(lookup["quota", arm, test, seed][metric]) for arm in QUOTAS]
                if all(not np.isfinite(v) for v in values):
                    continue
                metric_ranks.append(rank(values, reverse=metric == "HV_fixed_normalized"))
            quota_scores[:, ti, si] = np.mean(metric_ranks, axis=0)
    quota_means = quota_scores.mean(axis=(1, 2))
    quota_case_means = quota_scores.mean(axis=2).T

    # Build the same cube and four-metric composite for each ablation arm.
    ablation_scores = {}
    for arm in ARMS[1:]:
        cube = np.empty((8, 10, 4, 2))
        for ti, test in enumerate(TESTS):
            for si, seed in enumerate(range(20, 30)):
                for mi, member in enumerate(("FULL", arm)):
                    r = lookup["ablation", member, test, seed]
                    cube[ti, si, :, mi] = [float(r[m]) for m in METRICS]
        spacing_valid = np.isfinite(cube[:, :, 3, :]).all(axis=(1, 2))
        score, cells = score_many(cube[None], spacing_valid)
        ci, p = paired_inference(cube, spacing_valid, float(score[0]))
        ablation_scores[arm] = {"full_minus_ablated": float(score[0]),
                                "paired_bootstrap_95_ci": ci,
                                "one_sided_p_label_flip": p,
                                "per_test_scores": dict(zip(map(str, TESTS), cells[0].mean(axis=1).tolist()))}
        print("ablation inference", arm, round(float(score[0]), 4), ci, p, flush=True)
    adjusted = holm_adjust([ablation_scores[arm]["one_sided_p_label_flip"] for arm in ARMS[1:]])
    for arm, p in zip(ARMS[1:], adjusted):
        ablation_scores[arm]["holm_p"] = p

    audit = {"metric_source": str(csv_path.relative_to(WORKSPACE)),
             "method": "complete true-evaluated feasible nondominated archives; common fixed HV evaluation box",
             "quota_mean_ranks": dict(zip(QUOTAS, quota_means.tolist())),
             "quota_selected_by_minimum_mean_rank": QUOTAS[int(np.argmin(quota_means))],
             "quota_case_mean_ranks": dict(zip(map(str, TESTS), quota_case_means.tolist())),
             "ablation_full_minus_arm": ablation_scores}
    (HERE / "corrected_archive_metric_audit.json").write_text(json.dumps(audit, indent=2, ensure_ascii=False), encoding="utf-8")
    print(json.dumps({"quota_mean_ranks": audit["quota_mean_ranks"],
                      "quota_selected": audit["quota_selected_by_minimum_mean_rank"],
                      "ablation_scores": {k: v["full_minus_ablated"] for k, v in ablation_scores.items()}},
                     indent=2))


if __name__ == "__main__":
    main()
