"""Post hoc pooled summary of the ten-seed comparison and five-seed recheck.

Reads terminal metrics without changing the two locked, separate analyses.
The statistic and label-flip unit match audit_fixed_reference_hv.py.
"""

from __future__ import annotations

import csv
import json
from pathlib import Path

import numpy as np

from audit_fixed_reference_hv import score_many


HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
MAIN_CSV = ROOT / "MSCR_BO_新算法顺序实验_20261111" / "final_figures" / "per_round_metrics.csv"
NEW_CSV = ROOT / "MSCR_BO_独立5种子配对验证_20261114" / "terminal_seed_metrics.csv"
OUTPUT = HERE / "pooled_15_seed_summary.json"
TESTS = (1, 3, 4, 6, 7, 48, 49, 50)
NAMES = ("ZDT1", "ZDT3", "ZDT4", "DTLZ1", "DTLZ2", "MW3", "MW5", "MW7")
METHODS = ("MSCR-BO", "EGBO")
N_BOOTSTRAP = 20_000
N_LABEL_FLIPS = 100_000
RNG_SEED = 20261106


def load_cube(path: Path, seeds: range, hv_key: str) -> np.ndarray:
    with path.open(encoding="utf-8-sig", newline="") as stream:
        rows = {
            (int(row["test_id"]), int(row["seed"]), row["method"]): row
            for row in csv.DictReader(stream)
            if int(row["round"]) == 12
            and int(row["test_id"]) in TESTS
            and int(row["seed"]) in seeds
        }
    cube = np.empty((len(TESTS), len(seeds), 4, len(METHODS)), dtype=float)
    for ci, test in enumerate(TESTS):
        for si, seed in enumerate(seeds):
            for mi, method in enumerate(METHODS):
                row = rows[test, seed, method]
                assert int(row.get("evaluations", row.get("true_evaluations"))) == 114
                cube[ci, si, :, mi] = (
                    float(row["IGD"]), float(row["GD"]),
                    float(row[hv_key]), float(row["Spacing"]),
                )
    assert len(rows) == cube.shape[0] * cube.shape[1] * cube.shape[3]
    return cube


def main() -> None:
    first = load_cube(MAIN_CSV, range(10, 20), "HV_fixed_normalized")
    second = load_cube(NEW_CSV, range(100, 105), "HV_fixed")
    cube = np.concatenate((first, second), axis=1)
    spacing_valid = np.isfinite(cube[:, :, 3, :]).all(axis=(1, 2))
    score, cells = score_many(cube[None], spacing_valid)
    observed = float(score[0])

    # Check that the two input cohorts reproduce their independently saved results.
    for part, expected in ((first, 0.1174043469250529), (second, 0.10128503927854829)):
        part_valid = np.isfinite(part[:, :, 3, :]).all(axis=(1, 2))
        assert abs(float(score_many(part[None], part_valid)[0][0]) - expected) < 1e-12

    rng = np.random.default_rng(RNG_SEED)
    bootstrap = []
    for _ in range(N_BOOTSTRAP // 1000):
        indices = rng.integers(15, size=(1000, len(TESTS), 15))
        sampled = np.take_along_axis(
            np.broadcast_to(cube, (1000,) + cube.shape), indices[..., None, None], axis=2
        )
        bootstrap.extend(score_many(sampled, spacing_valid)[0].tolist())

    extreme = 0
    for _ in range(N_LABEL_FLIPS // 1000):
        switch = rng.integers(2, size=(1000, len(TESTS), 15), dtype=np.int8).astype(bool)
        original = np.broadcast_to(cube, (1000,) + cube.shape)
        permuted = np.where(switch[..., None, None], original[..., ::-1], original)
        values, _ = score_many(permuted, spacing_valid)
        extreme += int(np.count_nonzero(values >= observed - 1e-14))

    result = {
        "analysis_status": "post_hoc_pooled_summary; separate five-seed confirmatory result retained",
        "source_csvs": [str(MAIN_CSV.relative_to(ROOT)), str(NEW_CSV.relative_to(ROOT))],
        "seeds": list(range(10, 20)) + list(range(100, 105)),
        "tests": list(TESTS),
        "score": observed,
        "bootstrap_95_ci": np.quantile(bootstrap, [0.025, 0.975]).tolist(),
        "one_sided_label_flip_p": (extreme + 1) / (N_LABEL_FLIPS + 1),
        "per_case_score": dict(zip(NAMES, cells[0].mean(axis=1).tolist())),
        "spacing_valid_by_case": dict(zip(NAMES, spacing_valid.tolist())),
        "n_bootstrap": N_BOOTSTRAP,
        "n_label_flips": N_LABEL_FLIPS,
        "rng_seed": RNG_SEED,
    }
    OUTPUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
