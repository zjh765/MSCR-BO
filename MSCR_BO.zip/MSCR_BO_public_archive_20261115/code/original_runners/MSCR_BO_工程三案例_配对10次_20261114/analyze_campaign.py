"""Analyze paired author EGBO and current selected-quota MSCR-BO engineering runs."""
from __future__ import annotations

import csv
import json
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

import run_campaign as run

sys.path.insert(0, str(run.WORKSPACE / "engineering_branch_20261108"))
from analyze_branch import inference, metric, references  # noqa: E402

METHODS = ("MSCR-BO", "EGBO")
COLORS = {"MSCR-BO": "#163a5f", "EGBO": "#5a2a4a"}
REFERENCE_COLOR = "#8293a5"
FIELDS = ("archive_size", "feasible_count", "IGD", "GD",
          "HV_fixed", "Spacing")


def round_data(case: str, seed: int, method: str, round_id: int) -> np.ndarray:
    n = 18 + 8 * round_id
    if method == "MSCR-BO":
        data = np.loadtxt(run.output(case, seed) /
                          f"round_{round_id:02d}.csv", delimiter=",")
    else:
        folder = run.egbo(case, seed)
        train = np.loadtxt(folder / "train_data.csv", delimiter=",")[:n]
        d = run.CASES[case][1]
        data = np.column_stack((train[:, :d], -train[:, d:d + 2],
                                train[:, d + 2:]))
    assert data.shape[0] == n
    return data


def write_csv(path, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)


def finite_stats(values):
    x = np.asarray(values, dtype=float)
    f = x[np.isfinite(x)]
    return {"n_finite": int(len(f)),
            "mean": float(f.mean()) if len(f) else None,
            "median": float(np.median(f)) if len(f) else None,
            "q25": float(np.quantile(f, .25)) if len(f) else None,
            "q75": float(np.quantile(f, .75)) if len(f) else None}


def plot_fronts(case: str, pf: np.ndarray, fronts: dict) -> None:
    out = run.ROOT / "figures" / "pareto"
    out.mkdir(parents=True, exist_ok=True)
    available = [archive for archive in fronts.values() if len(archive)]
    all_points = np.vstack([pf] + available)
    lo, hi = all_points.min(axis=0), all_points.max(axis=0)
    pad = .045 * np.maximum(hi - lo, 1e-8)
    for method in METHODS:
        members = [fronts[method, seed] for seed in run.SEEDS
                   if len(fronts[method, seed])]
        observed = np.vstack(members) if members else np.empty((0, 2))
        fig, ax = plt.subplots(figsize=(6.6, 4.8), layout="constrained")
        ax.scatter(pf[:, 0], pf[:, 1], s=7, color=REFERENCE_COLOR,
                   alpha=.8, label="Numerical reference front", zorder=1,
                   rasterized=True)
        if len(observed):
            ax.scatter(observed[:, 0], observed[:, 1], s=17,
                       color=COLORS[method], alpha=.82,
                       label="Feasible nondominated", zorder=2,
                       rasterized=True)
        ax.set(xlim=(lo[0]-pad[0], hi[0]+pad[0]),
               ylim=(lo[1]-pad[1], hi[1]+pad[1]),
               xlabel="Objective 1", ylabel="Objective 2",
               title=f"{case} — {method} — 10 paired seeds")
        ax.grid(alpha=.22); ax.legend(frameon=False)
        fig.savefig(out / f"{case}_{method.replace(' ', '_')}.png", dpi=240)
        plt.close(fig)


def plot_convergence(case: str, rows: list[dict]) -> None:
    out = run.ROOT / "figures" / "convergence"
    out.mkdir(parents=True, exist_ok=True)
    x = 18 + 8 * np.arange(13)
    for field in FIELDS:
        fig, ax = plt.subplots(figsize=(6.8, 4.6), layout="constrained")
        for method in METHODS:
            middle, q25, q75 = [], [], []
            for round_id in range(13):
                values = [r[field] for r in rows if r["method"] == method
                          and r["round"] == round_id]
                stats = finite_stats(values)
                middle.append(stats["median"])
                q25.append(stats["q25"])
                q75.append(stats["q75"])
            y = np.asarray([np.nan if z is None else z for z in middle])
            low = np.asarray([np.nan if z is None else z for z in q25])
            high = np.asarray([np.nan if z is None else z for z in q75])
            ax.plot(x, y, marker="o", markersize=3, linewidth=1.7,
                    color=COLORS[method], label=method)
            ax.fill_between(x, low, high, color=COLORS[method], alpha=.14)
        ax.set(xlabel="True evaluations", ylabel=field,
               title=f"{case} — {field} — median and IQR")
        ax.grid(alpha=.22); ax.legend(frameon=False)
        fig.savefig(out / f"{case}_{field}.png", dpi=220)
        plt.close(fig)


def main() -> None:
    assert all(run.verify(case, seed) for case in run.CASES for seed in run.SEEDS)
    all_rows, final_rows = [], []
    report = {}
    for case, (_, d) in run.CASES.items():
        pf, lower, upper = references(case)
        rows, fronts = [], {}
        terminal = {}
        for seed in run.SEEDS:
            baseline = np.loadtxt(run.initial(case, seed), delimiter=",")
            for method in METHODS:
                assert np.allclose(round_data(case, seed, method, 0), baseline,
                                   rtol=0, atol=1e-8)
                for round_id in range(13):
                    data = round_data(case, seed, method, round_id)
                    values, archive = metric(data, d, pf, lower, upper)
                    row = {"case": case, "seed": seed, "method": method,
                           "round": round_id,
                           "true_evaluations": 18 + 8 * round_id,
                           **values}
                    rows.append(row)
                    if round_id == 12:
                        terminal[method, seed] = row
                        fronts[method, seed] = archive
                        final_rows.append(row)
        case_summary = {method: {field: finite_stats([
            terminal[method, seed][field] for seed in run.SEEDS])
            for field in FIELDS} for method in METHODS}
        paired = inference([terminal["MSCR-BO", seed] for seed in run.SEEDS],
                           [terminal["EGBO", seed] for seed in run.SEEDS],
                           20261114 + run.CASES[case][0])
        for field in FIELDS:
            a = np.asarray([terminal["MSCR-BO", seed][field]
                            for seed in run.SEEDS], dtype=float)
            b = np.asarray([terminal["EGBO", seed][field]
                            for seed in run.SEEDS], dtype=float)
            finite = np.isfinite(a) & np.isfinite(b)
            better = a > b if field == "HV_fixed" else a < b
            case_summary["MSCR-BO"][field]["paired_wins"] = int(np.sum(better & finite))
            case_summary["EGBO"][field]["paired_wins"] = int(
                np.sum((~better) & (a != b) & finite))
            case_summary["MSCR-BO"][field]["paired_ties"] = int(
                np.sum((a == b) & finite))
        report[case] = {"terminal_distributions": case_summary,
                        "paired_composite": paired}
        plot_fronts(case, pf, fronts)
        plot_convergence(case, rows)
        all_rows.extend(rows)
        print("ANALYZED", case, paired, flush=True)
    write_csv(run.ROOT / "per_round_metrics.csv", all_rows)
    write_csv(run.ROOT / "terminal_seed_metrics.csv", final_rows)
    (run.ROOT / "case_summary.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print("THREE_ENGINEERING_CASES_ANALYSIS_COMPLETE", flush=True)


if __name__ == "__main__":
    main()
