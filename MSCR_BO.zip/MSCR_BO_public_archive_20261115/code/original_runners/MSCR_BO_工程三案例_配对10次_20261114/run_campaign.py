"""Paired current MSCR-BO engineering runs against locked author EGBO data."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

import numpy as np

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parent
LEGACY = Path(r"F:\全局优化\DPR-qNEHVI_MATLAB")
OLD = LEGACY / "科研实验报告_新版" / "MSCR_BO_冻结版后续实验"
MATLAB = Path(r"E:\Program Files\Polyspace\R2020a\bin\matlab.exe")
PYTHON = (LEGACY / "科研实验报告_新版" / "临时_原作者EGBO_ZDT1_预算56"
          / ".venv" / "Scripts" / "python.exe")
CASES = {"RCM21": (54, 6), "RCM27": (57, 3), "RCM02": (56, 5)}
SEEDS = tuple(range(60, 70))
SOURCES = ("MSCR_BO_staged.m", "run_engineering_case.m",
           "select_batch_greedy.m", "greedy_qlognehvi_bridge.py",
           "elite_walk_spread.m", "surrepair_gate_engineering.m")


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def old(case: str) -> Path:
    return OLD / f"工程验证_{case}_10重复"


def initial(case: str, seed: int) -> Path:
    return old(case) / "initial" / f"T{CASES[case][0]}_seed{seed:02d}.csv"


def egbo(case: str, seed: int) -> Path:
    return old(case) / f"EGBO_seed{seed:02d}" / f"T{CASES[case][0]}"


def output(case: str, seed: int) -> Path:
    return ROOT / "results" / case / f"seed{seed:02d}"


def audit() -> dict:
    protocol = json.loads((ROOT / "protocol.json").read_text(encoding="utf-8"))
    assert protocol["cases"] == {name: test for name, (test, _) in CASES.items()}
    assert protocol["seeds"] == list(SEEDS)
    assert MATLAB.is_file() and PYTHON.is_file()
    selected = json.loads((WORKSPACE / "MSCR_BO_新算法顺序实验_20261111" /
                           "selected_quota.json").read_text(encoding="utf-8"))
    assert selected["quota"] == [5, 8, 5]
    records = {}
    for case, (test, d) in CASES.items():
        reference = None
        for seed in SEEDS:
            path = initial(case, seed)
            data = np.loadtxt(path, delimiter=",")
            folder = egbo(case, seed)
            metadata = json.loads((folder / "metadata.json").read_text(
                encoding="utf-8"))
            train = np.loadtxt(folder / "train_data.csv", delimiter=",")
            m = metadata["n_obj"]
            assert m == 2 and metadata["n_var"] == d
            assert metadata["seed"] == seed and metadata["test_id"] == test
            assert metadata["budget"] == 114 and metadata["physical_eval_count"] == 114
            assert metadata["initial"] == 18 and metadata["batches"] == 12
            assert metadata["batch_size"] == 8
            assert metadata["candidate_pool_per_round"] == 144
            assert metadata["sampler_samples"] == 16
            assert str(metadata["device"]).startswith("cuda")
            assert train.shape == (114, data.shape[1])
            paired = np.column_stack((train[:18, :d],
                                      -train[:18, d:d + m],
                                      train[:18, d + m:]))
            assert data.shape == paired.shape and data.shape[0] == 18
            assert np.allclose(data, paired, rtol=0, atol=1e-8)
            point = np.asarray(metadata["acquisition_ref_minimization"], dtype=float)
            if reference is None:
                reference = point
            else:
                assert np.allclose(reference, point, rtol=0, atol=1e-10)
            records[f"{case}/seed{seed:02d}"] = {
                "initial_sha256": sha(path),
                "egbo_metadata_sha256": sha(folder / "metadata.json"),
                "egbo_train_sha256": sha(folder / "train_data.csv")}
    return {"protocol_sha256": sha(ROOT / "protocol.json"),
            "source_sha256": {name: sha(ROOT / name) for name in SOURCES},
            "paired_input_sha256": records}


def verify(case: str, seed: int) -> bool:
    out = output(case, seed)
    try:
        item = json.loads((out / "status.json").read_text(encoding="utf-8"))
        assert item["status"] == "ok" and item["case"] == case
        assert item["seed"] == seed and item["test_id"] == CASES[case][0]
        assert item["source_quota"] == [5, 8, 5]
        assert item["objective_budget"] == 114
        first = np.loadtxt(initial(case, seed), delimiter=",")
        for round_id in range(13):
            data = np.loadtxt(out / f"round_{round_id:02d}.csv", delimiter=",")
            assert data.shape == (18 + 8 * round_id, first.shape[1])
            assert np.isfinite(data).all()
            assert np.allclose(data[:18], first, rtol=0, atol=1e-8)
        log = (out / "progress.log").read_text(encoding="utf-8")
        assert len(re.findall(r"iter=\d+/12", log)) == 12
        assert len(re.findall(r"greedy_round=\d+", log)) == 12
        query = json.loads((out / "query_audit.json").read_text(encoding="utf-8"))
        if case in ("RCM27", "RCM02"):
            assert query["objective_rows_after_initial"] == 96
        return True
    except (OSError, ValueError, TypeError, KeyError, AssertionError):
        return False


def status(**fields) -> None:
    (ROOT / "campaign_status.json").write_text(
        json.dumps(fields, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8")


def run_one(case: str, seed: int) -> None:
    out = output(case, seed)
    if verify(case, seed):
        return
    assert out.resolve().is_relative_to((ROOT / "results").resolve())
    for retry in range(3):
        if out.exists() and any(out.iterdir()):
            if (out / "status.json").exists():
                raise RuntimeError(f"Invalid completed result requires review: {out}")
            number = 1
            archive = out.with_name(f"{out.name}_failed_attempt{number:02d}")
            while archive.exists():
                number += 1
                archive = out.with_name(f"{out.name}_failed_attempt{number:02d}")
            assert archive.resolve().is_relative_to((ROOT / "results").resolve())
            out.rename(archive)
        out.mkdir(parents=True, exist_ok=True)
        env = os.environ.copy()
        env["DPR_QLOGNEHVI_PYTHON"] = str(PYTHON)
        command = [str(MATLAB), "-wait", "-batch",
                   f"run_engineering_case({CASES[case][0]},{seed})"]
        with (out / "matlab.log").open("ab") as stream:
            process = subprocess.Popen(command, cwd=ROOT, env=env,
                                       stdout=stream, stderr=subprocess.STDOUT,
                                       creationflags=subprocess.CREATE_NO_WINDOW)
            started = time.monotonic()
            try:
                while process.poll() is None:
                    elapsed = time.monotonic() - started
                    if elapsed > 300 and not (out / "round_00.csv").exists():
                        raise TimeoutError(f"MATLAB startup exceeded 300 seconds: {out}")
                    if elapsed > 2400:
                        raise TimeoutError(f"MATLAB case exceeded 2400 seconds: {out}")
                    time.sleep(2)
            except BaseException:
                if process.poll() is None:
                    subprocess.run(["taskkill", "/PID", str(process.pid), "/T", "/F"],
                                   stdout=subprocess.DEVNULL,
                                   stderr=subprocess.DEVNULL, check=False)
                raise
        if verify(case, seed):
            if process.returncode:
                print(f"MATLAB_SHUTDOWN_WARNING {out} exit={process.returncode}",
                      flush=True)
            return
        if (out / "status.json").exists():
            raise RuntimeError(f"Invalid completed result requires review: {out}")
        print(f"RETRY_INCOMPLETE {out} attempt={retry + 1}", flush=True)
    raise RuntimeError(f"Three incomplete attempts: {out}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", action="store_true")
    parser.add_argument("--limit", type=int)
    args = parser.parse_args()
    record = audit()
    if args.check:
        print("THREE_ENGINEERING_CASES_PAIRED_INPUTS_OK")
        return 0
    lock = ROOT / "input_lock.json"
    if lock.exists():
        assert json.loads(lock.read_text(encoding="utf-8")) == record
    else:
        lock.write_text(json.dumps(record, ensure_ascii=False, indent=2) + "\n",
                        encoding="utf-8")
    completed = 0
    try:
        for case in CASES:
            for seed in SEEDS:
                if not verify(case, seed):
                    if args.limit is not None and completed >= args.limit:
                        status(status="partial_validated", completed=completed)
                        return 0
                    status(status="running", current_case=case, current_seed=seed,
                           completed=completed)
                    run_one(case, seed)
                    completed += 1
                    print(f"COMPLETE {case} seed{seed:02d}", flush=True)
        assert all(verify(case, seed) for case in CASES for seed in SEEDS)
        status(status="all_runs_complete", completed=30)
        subprocess.run([str(PYTHON), str(ROOT / "analyze_campaign.py")],
                       cwd=ROOT, check=True)
        status(status="analysis_complete", completed=30)
        return 0
    except Exception as exc:
        status(status="paused_runtime_error", reason=str(exc), completed=completed)
        raise


if __name__ == "__main__":
    raise SystemExit(main())
