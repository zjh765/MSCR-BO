function run_engineering_case(case_id,seed)
%RUN_ENGINEERING_CASE Current selected-quota MSCR-BO versus paired author EGBO.
assert(ismember(case_id,[54 56 57]) && ismember(seed,60:69));
here=fileparts(mfilename('fullpath'));
legacy='F:\全局优化\DPR-qNEHVI_MATLAB';
addpath(legacy); addpath(here,'-begin');
cd(legacy); % GetFunInfo loads official RCM reference MAT files here.
if case_id==54, problem='RCM21';
elseif case_id==56, problem='RCM02';
else, problem='RCM27'; end
prior=fullfile(legacy,'科研实验报告_新版', ...
    'MSCR_BO_冻结版后续实验', ...
    sprintf('工程验证_%s_10重复',problem));
obj=GetFunInfo(case_id);
initial=fullfile(prior,'initial',sprintf('T%d_seed%02d.csv',case_id,seed));
assert(exist(initial,'file')==2,'Locked paired initial data missing.');
data=readmatrix(initial);
D=obj.nVar; M=obj.numOfObj;
assert(size(data,1)==18 && size(data,2)>=D+M && all(isfinite(data(:))));
out=fullfile(here,'results',problem,sprintf('seed%02d',seed));
if ~exist(out,'dir'), mkdir(out); end
writematrix(data,fullfile(out,'round_00.csv'));
[ref,~]=main_egbo_reference(obj,case_id,fullfile(prior,'EGBO_seed60'));
p=struct();
p.Nr=300; p.n_init=18; p.n_iter=12; p.q=8; p.n_cand=5;
p.mc_samples=16; p.refine_topk=8; p.refine_rounds=0;
p.refine_sigma=.05; p.gp_alpha=1e-6;
p.repair_steps=30; p.repair_lr=.05; p.repair_tol=1e-3;
p.repair_k=8; p.repair_sigma=.15; p.surrogate_normalized_ls=1.5;
p.min_data=4; p.use_walk=true; p.walk_batches=8; p.walk_sigma=.10;
p.use_acqf=true; p.acqf_starts=5; p.acqf_maxiter=40;
p=diffusion_params(p);
p.gp_kernel='rbf'; p.repair_gp_kernel='rbf';
p.coord_restart=false; p.surrogate_de=false;
p.acquisition='EGBO_qLogNEHVI';
p.repair_policy='engineering_safety_gate_v1';
p.repair_order='after_scoring';
p.acq_ref_override=ref; p.fixed_ref_strict=true;
p.scoring_rule='qlognehvi_raw_v2';
p.method_name='MSCR-BO'; p.algorithm_version='joint_selection_v1';
p.ablation_arm='FULL'; p.source_quota=[5 8 5];
p.frozen_initial_file=initial;
p.frozen_trace_file=fullfile(out,sprintf('trace_T%d_seed%d.mat',case_id,seed));
p.logfile=fullfile(out,'progress.log');
if case_id==56, setenv('RCM02_ENGINEERING_RUN','1'); end
if case_id==57, setenv('RCM27_ENGINEERING_RUN','1'); end
global RCM02_CONSTRAINT_QUERY_ROWS ...
    RCM27_CONSTRAINT_QUERY_ROWS RCM02_OBJECTIVE_QUERY_ROWS RCM27_OBJECTIVE_QUERY_ROWS
RCM02_CONSTRAINT_QUERY_ROWS=0; RCM27_CONSTRAINT_QUERY_ROWS=0;
RCM02_OBJECTIVE_QUERY_ROWS=0; RCM27_OBJECTIVE_QUERY_ROWS=0;
rng(seed,'twister');
status='ok'; err=''; result=[]; timer=tic;
try
    result=MSCR_BO_staged(p,obj);
    saved=readmatrix(fullfile(out,'round_12.csv'));
    assert(isequal(size(saved),[114 size(data,2)]) && all(isfinite(saved(:))));
    assert(max(abs(saved(1:18,:)-data),[],'all')<1e-8);
catch ME
    status='error'; err=getReport(ME,'extended','hyperlinks','off');
end
elapsed=toc(timer);
save(fullfile(out,'case_main_selected.mat'),'case_id','seed', ...
    'status','err','elapsed','p','obj','result','-v7.3');
if case_id==54
    constraint_rows=NaN;
    objective_rows=NaN;
elseif case_id==56
    constraint_rows=RCM02_CONSTRAINT_QUERY_ROWS;
    objective_rows=RCM02_OBJECTIVE_QUERY_ROWS;
else
    constraint_rows=RCM27_CONSTRAINT_QUERY_ROWS;
    objective_rows=RCM27_OBJECTIVE_QUERY_ROWS;
end
fid=fopen(fullfile(out,'query_audit.json'),'w');
assert(fid>0);
fprintf(fid,'%s\n',jsonencode(struct('case_id',case_id,'seed',seed, ...
    'variant','MSCR_BO_joint_selected_5_8_5', ...
    'constraint_rows_after_initial',constraint_rows, ...
    'objective_rows_after_initial',objective_rows)));
fclose(fid);
fid=fopen(fullfile(out,'status.json'),'w'); assert(fid>0);
fprintf(fid,'%s\n',jsonencode(struct('case',problem,'test_id',case_id, ...
    'seed',seed,'status',status,'objective_budget',114, ...
    'source_quota',[5 8 5],'elapsed_seconds',elapsed,'error',err)));
fclose(fid);
fprintf('ENGINEERING_MAIN case=%s seed=%d status=%s elapsed=%.1f\n', ...
    problem,seed,status,elapsed);
assert(strcmp(status,'ok'),'%s',err);
end
