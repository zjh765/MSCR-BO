function run_holdout_case(test_id,seed)
%RUN_HOLDOUT_CASE Frozen current MSCR-BO on shared new initial observations.
assert(ismember(test_id,[1 3 4 6 7 48 49 50 54 57]));
assert(ismember(seed,100:104));
here=fileparts(mfilename('fullpath'));
legacy='F:\全局优化\DPR-qNEHVI_MATLAB';
addpath(legacy); addpath(here,'-begin'); cd(legacy);
obj=GetFunInfo(test_id);
initial=fullfile(here,'initial',sprintf('T%02d_seed%03d.csv',test_id,seed));
data=readmatrix(initial);
assert(size(data,1)==18 && size(data,2)>=obj.nVar+obj.numOfObj);
assert(all(isfinite(data(:))));
refs=jsondecode(fileread(fullfile(here,'reference_points.json')));
ref=reshape(refs.(sprintf('T%02d',test_id)),1,[]);
assert(numel(ref)==obj.numOfObj && all(isfinite(ref)));
out=fullfile(here,'results','mscr',sprintf('T%02d',test_id), ...
    sprintf('seed%03d',seed));
if ~exist(out,'dir'), mkdir(out); end
writematrix(data,fullfile(out,'round_00.csv'));
p=struct();
p.Nr=300; p.n_init=18; p.n_iter=12; p.q=8;
p.n_cand=5; p.walk_batches=8; p.acqf_starts=5;
p.mc_samples=16; p.refine_topk=8; p.refine_rounds=0;
p.refine_sigma=.05; p.gp_alpha=1e-6;
p.repair_steps=30; p.repair_lr=.05; p.repair_tol=1e-3;
p.repair_k=8; p.repair_sigma=.15; p.surrogate_normalized_ls=1.5;
p.min_data=4; p.use_walk=true; p.walk_sigma=.10;
p.use_acqf=true; p.acqf_maxiter=40;
p=diffusion_params(p);
p.gp_kernel='rbf'; p.repair_gp_kernel='rbf';
p.coord_restart=false; p.surrogate_de=false;
p.acquisition='EGBO_qLogNEHVI';
p.repair_policy='engineering_safety_gate_v1';
p.repair_order='after_scoring'; p.scoring_rule='qlognehvi_raw_v2';
p.acq_ref_override=ref; p.fixed_ref_strict=true;
p.method_name='MSCR-BO'; p.algorithm_version='joint_selection_v1';
p.ablation_arm='FULL'; p.source_quota=[5 8 5];
p.frozen_initial_file=initial;
p.frozen_trace_file=fullfile(out,sprintf('trace_T%d_seed%d.mat',test_id,seed));
p.logfile=fullfile(out,'progress.log');
if test_id==57, setenv('RCM27_ENGINEERING_RUN','1'); end
global RCM27_CONSTRAINT_QUERY_ROWS RCM27_OBJECTIVE_QUERY_ROWS
RCM27_CONSTRAINT_QUERY_ROWS=0; RCM27_OBJECTIVE_QUERY_ROWS=0;
rng(seed,'twister');
status='ok'; err=''; elapsed=NaN; result=[]; timer=tic;
try
    result=MSCR_BO_staged(p,obj);
    final=readmatrix(fullfile(out,'round_12.csv'));
    assert(isequal(size(final),[114 size(data,2)]) && all(isfinite(final(:))));
    assert(max(abs(final(1:18,:)-data),[],'all')<1e-8);
catch ME
    status='error'; err=getReport(ME,'extended','hyperlinks','off');
end
elapsed=toc(timer);
save(fullfile(out,'case.mat'),'test_id','seed','status','err', ...
    'elapsed','p','result','-v7.3');
if test_id==57
    objective_rows=RCM27_OBJECTIVE_QUERY_ROWS;
    constraint_rows=RCM27_CONSTRAINT_QUERY_ROWS;
else
    objective_rows=NaN; constraint_rows=NaN;
end
fid=fopen(fullfile(out,'status.json'),'w'); assert(fid>0);
fprintf(fid,'%s\n',jsonencode(struct('test_id',test_id,'seed',seed, ...
    'status',status,'budget',114,'source_quota',[5 8 5], ...
    'elapsed_seconds',elapsed,'objective_rows_after_initial', ...
    objective_rows,'constraint_rows_after_initial',constraint_rows, ...
    'error',err)));
fclose(fid);
fprintf('NEW_MSCR T%02d seed%d status=%s elapsed=%.1f\n', ...
    test_id,seed,status,elapsed);
assert(strcmp(status,'ok'),'%s',err);
end
