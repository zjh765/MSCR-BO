function export_initials()
%EXPORT_INITIALS New paired 18-point designs for five previously unused seeds.
here=fileparts(mfilename('fullpath'));
legacy='F:\全局优化\DPR-qNEHVI_MATLAB';
addpath(legacy); cd(legacy);
ids=[1 3 4 6 7 48 49 50 54 57];
out=fullfile(here,'initial');
if ~exist(out,'dir'), mkdir(out); end
for test_id=ids
    obj=GetFunInfo(test_id);
    for seed=100:104
        file=fullfile(out,sprintf('T%02d_seed%03d.csv',test_id,seed));
        assert(exist(file,'file')~=2,'Initial file already exists: %s',file);
        rng(seed,'twister');
        [chrom,G]=initialize_variables(18,obj);
        data=[chrom,G];
        assert(size(data,1)==18 && size(data,2)>=obj.nVar+obj.numOfObj);
        assert(all(isfinite(data(:))));
        writematrix(data,file);
        fprintf('NEW_INITIAL T%02d seed%d feasible=%d/18\n', ...
            test_id,seed,sum(all(G<=0,2)));
    end
end
fprintf('NEW_INITIALS_COMPLETE count=50\n');
end
