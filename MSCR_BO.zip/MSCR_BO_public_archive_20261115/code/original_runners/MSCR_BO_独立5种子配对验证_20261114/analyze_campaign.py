"""Analyze every new seed and case using the previously locked metric rules."""
from __future__ import annotations

import csv
from itertools import product
import json
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

import run_campaign as run

sys.path.insert(0, str(run.LEGACY))
sys.path.insert(0, str(run.ROOT.parent / "engineering_branch_20261108"))
from analyze_frozen_campaign import evaluate as standard_metric, front as standard_front, POINTS  # noqa: E402
from analyze_branch import metric as engineering_metric, references as engineering_references  # noqa: E402
from analyze_confirmatory_campaign import score_many  # noqa: E402

FIELDS = ("IGD", "GD", "HV_fixed", "Spacing", "archive_size", "feasible_count")
METHODS = ("MSCR-BO", "EGBO")
COLORS = {"MSCR-BO": "#163a5f", "EGBO": "#5a2a4a"}
REFERENCE_COLOR = "#8293a5"
RNG_SEED = 20261114


def csv_write(path, rows):
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader(); writer.writerows(rows)


def ref_for(test):
    if test in (54, 57):
        pf, lower, upper = engineering_references(run.NAME[test])
    else:
        pf = np.loadtxt(POINTS / f"T{test}_reference.csv", delimiter=",")
        pf = np.atleast_2d(pf)
        lower = np.minimum(0, pf.min(axis=0))
        upper = lower + 1.1 * (pf.max(axis=0) - lower)
    assert pf.shape[1] in (2, 3)
    assert np.all(np.asarray(upper) > np.asarray(lower))
    return pf, np.asarray(lower), np.asarray(upper)


def read_round(test, seed, method, round_id):
    n = 18 + 8 * round_id
    if method == "MSCR-BO":
        data = np.loadtxt(run.mscr(test, seed) / f"round_{round_id:02d}.csv",
                          delimiter=",")
    else:
        folder = run.egbo(test, seed)
        meta = json.loads((folder / "metadata.json").read_text(encoding="utf-8"))
        raw = np.loadtxt(folder / "train_data.csv", delimiter=",")[:n]
        d, m = meta["n_var"], meta["n_obj"]
        data = np.column_stack((raw[:, :d], -raw[:, d:d + m], raw[:, d + m:]))
    assert data.shape[0] == n
    return data


def metrics_for(test, data, pf, lower, upper):
    if test in (54, 57):
        d = 6 if test == 54 else 3
        return engineering_metric(data, d, pf, lower, upper)
    m = pf.shape[1]
    d = {1: 30, 3: 30, 4: 10, 6: 7, 7: 12, 48: 8, 49: 8,
         50: 8}.get(test)
    # Dimensions are checked against the recorded initial and EGBO metadata.
    if d is None or data.shape[1] < d + m:
        raise ValueError(f"Invalid dimensions T{test}: {data.shape}")
    f, g = data[:, d:d + m], data[:, d + m:]
    stats = standard_metric(f, g, pf, lower, upper)
    archive = standard_front(f, g)
    stats["HV_fixed"] = stats.pop("HV_fixed_normalized")
    stats["feasible_count"] = int(np.sum(np.all(g <= 0, axis=1))) if g.shape[1] else len(f)
    return stats, archive


def finite_stats(values):
    x = np.asarray(values, float)
    y = x[np.isfinite(x)]
    return {"n_finite": int(len(y)),
            "mean": float(np.mean(y)) if len(y) else None,
            "median": float(np.median(y)) if len(y) else None,
            "q25": float(np.quantile(y, .25)) if len(y) else None,
            "q75": float(np.quantile(y, .75)) if len(y) else None}


def score_cube(cube):
    # cube: case x seed x four metrics x method
    valid = np.isfinite(cube[:, :, 3, :]).all(axis=(1, 2))
    value, cells = score_many(cube[None], valid)
    return float(value[0]), cells[0], valid


def bootstrap_score(cube, rng, count=20000):
    ncase, nseed = cube.shape[:2]
    results = []
    for _ in range(count // 1000):
        indices = rng.integers(nseed, size=(1000, ncase, nseed))
        draws = np.take_along_axis(np.broadcast_to(cube, (1000,) + cube.shape),
                                   indices[..., None, None], axis=2)
        valid = np.isfinite(cube[:, :, 3, :]).all(axis=(1, 2))
        values, _ = score_many(draws, valid)
        results.extend(values.tolist())
    return np.quantile(results, [.025, .975]).tolist()


def permutation_score(cube, observed, rng, count=100000):
    ncase, nseed = cube.shape[:2]
    valid = np.isfinite(cube[:, :, 3, :]).all(axis=(1, 2))
    extreme = 0
    for _ in range(count // 1000):
        switch = rng.integers(2, size=(1000, ncase, nseed), dtype=np.int8).astype(bool)
        original = np.broadcast_to(cube, (1000,) + cube.shape)
        swapped = np.where(switch[..., None, None], original[..., ::-1], original)
        values, _ = score_many(swapped, valid)
        extreme += int(np.count_nonzero(values >= observed - 1e-14))
    return (extreme + 1) / (count + 1)


def exact_case_p(cube, observed):
    assert cube.shape == (1, 5, 4, 2)
    valid = np.isfinite(cube[:, :, 3, :]).all(axis=(1, 2))
    null = []
    for labels in product((0, 1), repeat=5):
        switch = np.asarray(labels, bool)[None, :, None, None]
        swapped = np.where(switch, cube[..., ::-1], cube)
        value, _ = score_many(swapped[None], valid)
        null.append(float(value[0]))
    return (sum(value >= observed - 1e-14 for value in null) + 1) / 33


def plot_case(test, rows, pf, fronts):
    name = run.NAME[test]
    out = run.ROOT / "figures"
    (out / "pareto").mkdir(parents=True, exist_ok=True)
    (out / "convergence").mkdir(parents=True, exist_ok=True)
    points = np.vstack([pf] + [a for a in fronts.values() if len(a)])
    lo, hi = points.min(axis=0), points.max(axis=0)
    pad = .045 * np.maximum(hi - lo, 1e-8)
    for method in METHODS:
        pieces = [fronts[method, seed] for seed in run.SEEDS
                  if len(fronts[method, seed])]
        archive = np.vstack(pieces) if pieces else np.empty((0, pf.shape[1]))
        if pf.shape[1] == 3:
            fig = plt.figure(figsize=(6.7, 5.2))
            ax = fig.add_subplot(111, projection="3d")
            ax.scatter(*pf.T, s=5, color=REFERENCE_COLOR, alpha=.8,
                       depthshade=False, label="Reference front")
            if len(archive):
                ax.scatter(*archive.T, s=14, color=COLORS[method], alpha=.84,
                           depthshade=False, label="Feasible nondominated")
            ax.set_zlim(lo[2]-pad[2], hi[2]+pad[2]); ax.set_zlabel("f3")
        else:
            fig, ax = plt.subplots(figsize=(6.7, 4.9))
            ax.scatter(pf[:, 0], pf[:, 1], s=7, color=REFERENCE_COLOR,
                       alpha=.8, label="Reference front", rasterized=True)
            if len(archive):
                ax.scatter(archive[:, 0], archive[:, 1], s=17,
                           color=COLORS[method], alpha=.84,
                           label="Feasible nondominated", rasterized=True)
            ax.grid(alpha=.22)
        ax.set_xlim(lo[0]-pad[0], hi[0]+pad[0])
        ax.set_ylim(lo[1]-pad[1], hi[1]+pad[1])
        ax.set_xlabel("f1"); ax.set_ylabel("f2")
        ax.set_title(f"{name} — {method} — five paired seeds")
        ax.legend(frameon=False)
        fig.tight_layout()
        fig.savefig(out / "pareto" / f"{name}_{method.replace(' ', '_')}.png",
                    dpi=230)
        plt.close(fig)
    x = 18 + 8 * np.arange(13)
    for field in FIELDS:
        fig, ax = plt.subplots(figsize=(6.9, 4.6), layout="constrained")
        for method in METHODS:
            med, low, high = [], [], []
            for it in range(13):
                stats = finite_stats([row[field] for row in rows
                    if row["method"] == method and row["round"] == it])
                med.append(np.nan if stats["median"] is None else stats["median"])
                low.append(np.nan if stats["q25"] is None else stats["q25"])
                high.append(np.nan if stats["q75"] is None else stats["q75"])
            ax.plot(x, med, color=COLORS[method], marker="o", markersize=3,
                    linewidth=1.6, label=method)
            ax.fill_between(x, low, high, color=COLORS[method], alpha=.14)
        ax.set(xlabel="True evaluations", ylabel=field,
               title=f"{name} — {field} — median and IQR")
        ax.grid(alpha=.2); ax.legend(frameon=False)
        fig.savefig(out / "convergence" / f"{name}_{field}.png", dpi=220)
        plt.close(fig)


def main():
    assert all(run.verify_egbo(t, s) and run.verify_mscr(t, s)
               for t in run.TESTS for s in run.SEEDS)
    all_rows, terminal = [], []
    cubes = {}
    summaries = {}
    for test in run.TESTS:
        pf, lower, upper = ref_for(test)
        rows, fronts = [], {}
        cube = np.empty((1, 5, 4, 2), float)
        for si, seed in enumerate(run.SEEDS):
            first = np.loadtxt(run.initial(test, seed), delimiter=",")
            for mi, method in enumerate(METHODS):
                assert np.allclose(read_round(test, seed, method, 0), first,
                                   rtol=0, atol=1e-8)
                for it in range(13):
                    data = read_round(test, seed, method, it)
                    values, archive = metrics_for(test, data, pf, lower, upper)
                    row = {"case": run.NAME[test], "test_id": test, "seed": seed,
                           "method": method, "round": it,
                           "true_evaluations": 18 + 8 * it, **values}
                    rows.append(row)
                    if it == 12:
                        terminal.append(row)
                        fronts[method, seed] = archive
                        cube[0, si, :, mi] = [row[x] for x in FIELDS[:4]]
        score, parts, valid = score_cube(cube)
        summary = {method: {field: finite_stats([row[field] for row in rows
                    if row["method"] == method and row["round"] == 12])
                    for field in FIELDS} for method in METHODS}
        rng = np.random.default_rng(RNG_SEED + test)
        summary["paired_composite"] = {
            "score": score, "parts": parts[0].tolist(),
            "spacing_valid": bool(valid[0]),
            "bootstrap_95_ci": bootstrap_score(cube, rng),
            "one_sided_exact_label_flip_p": exact_case_p(cube, score)}
        summaries[run.NAME[test]] = summary
        cubes[test] = cube[0]
        plot_case(test, rows, pf, fronts)
        all_rows.extend(rows)
        print(f"ANALYZED {run.NAME[test]} score={score:.6f}", flush=True)
    standard_cube = np.stack([cubes[t] for t in run.TESTS[:8]])
    overall, cells, valid = score_cube(standard_cube)
    rng = np.random.default_rng(RNG_SEED)
    primary = {"score": overall,
               "bootstrap_95_ci": bootstrap_score(standard_cube, rng),
               "one_sided_label_flip_p": permutation_score(standard_cube, overall, rng),
               "spacing_valid_by_case": dict(zip(
                   [run.NAME[t] for t in run.TESTS[:8]], valid.tolist())),
               "per_case_score": dict(zip(
                   [run.NAME[t] for t in run.TESTS[:8]],
                   cells.mean(axis=1).tolist()))}
    primary["locked_criterion_passed"] = bool(
        primary["one_sided_label_flip_p"] < .05 and
        primary["bootstrap_95_ci"][0] > 0)
    csv_write(run.ROOT / "per_round_metrics.csv", all_rows)
    csv_write(run.ROOT / "terminal_seed_metrics.csv", terminal)
    result = {"primary_eight_benchmarks": primary,
              "case_results": summaries,
              "interpretation": "Five new seeds per case; independent-seed recheck only."
              " Engineering cases have five pairs and were selected using prior results."}
    (run.ROOT / "analysis_summary.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    lines = ["# MSCR-BO 与原作者 EGBO：5 个新种子配对复核", "",
             "每个案例使用 seed 100–104，共享相同的初始 18 点；两方法各 114 次真实评估、每轮 144 个候选。",
             "此次为新种子复核；案例均已在前期开发或筛选中出现，不能解释为新问题的盲法验证。", "",
             f"八标准函数等权四指标综合评分差：{overall:+.4f}；95% 配对 bootstrap 区间"
             f" [{primary['bootstrap_95_ci'][0]:.4f}, {primary['bootstrap_95_ci'][1]:.4f}]；"
             f"单侧配对标签翻转 p={primary['one_sided_label_flip_p']:.4g}；"
             f"预定判据{'通过' if primary['locked_criterion_passed'] else '未通过'}。", "",
             "| Case | MSCR-BO IGD / EGBO | MSCR-BO GD / EGBO | MSCR-BO HV / EGBO | MSCR-BO Spacing / EGBO | MSCR-BO ND / EGBO | Case score [95% CI] |",
             "|---|---:|---:|---:|---:|---:|---:|"]
    def fmt(value):
        return "NA" if value is None else f"{value:.5g}"
    for test in run.TESTS:
        name = run.NAME[test]
        entry = summaries[name]
        a, b = entry[METHODS[0]], entry[METHODS[1]]
        cells_text = [f"{fmt(a[key]['mean'])} / {fmt(b[key]['mean'])}"
                      for key in FIELDS[:4] + ("archive_size",)]
        ps = entry["paired_composite"]
        ci = ps["bootstrap_95_ci"]
        lines.append(f"| {name} | " + " | ".join(cells_text) +
                     f" | {ps['score']:+.4f} [{ci[0]:.4f}, {ci[1]:.4f}] |")
    lines += ["", "工程案例的单侧精确配对标签翻转仅有 32 种交换方式；"
              "本项目采用加一校正，因此 5 对种子的最小 p 值为 2/33≈0.0606，"
              "不对单个工程案例作 p<0.05 的确认性主张。", "",
              "完整逐种子和逐轮数据见 `terminal_seed_metrics.csv`、`per_round_metrics.csv`；"
              "各方法解集分图见 `figures/pareto/`，收敛图见 `figures/convergence/`。"]
    (run.ROOT / "独立5种子结果报告.md").write_text(
        "\n".join(lines) + "\n", encoding="utf-8")
    print("FIVE_NEW_SEED_ANALYSIS_COMPLETE", flush=True)


if __name__ == "__main__":
    main()
