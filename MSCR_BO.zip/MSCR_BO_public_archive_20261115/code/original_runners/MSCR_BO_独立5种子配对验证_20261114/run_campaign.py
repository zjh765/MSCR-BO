"""Resumable new-seed paired MSCR-BO/author-EGBO campaign."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time

import numpy as np

ROOT = Path(__file__).resolve().parent
LEGACY = Path(r"F:\全局优化\DPR-qNEHVI_MATLAB")
OLD = LEGACY / "科研实验报告_新版" / "MSCR_BO_冻结版后续实验"
MATLAB = Path(r"E:\Program Files\Polyspace\R2020a\bin\matlab.exe")
PYTHON = (LEGACY / "科研实验报告_新版" / "临时_原作者EGBO_ZDT1_预算56"
          / ".venv" / "Scripts" / "python.exe")
AUTHOR_RUNNER = LEGACY / "run_author_egbo_47.py"
AUTHOR_SOURCE = (LEGACY / "科研实验报告_新版" / "临时_原作者EGBO_ZDT1_预算56"
                 / "author_original" / "run_synthetic_pairwise_egbo_novelty_nehvi.py")
TESTS = (1, 3, 4, 6, 7, 48, 49, 50, 54, 57)
SEEDS = tuple(range(100, 105))
NAME = {1: "ZDT1", 3: "ZDT3", 4: "ZDT4", 6: "DTLZ1", 7: "DTLZ2",
        48: "MW3", 49: "MW5", 50: "MW7", 54: "RCM21", 57: "RCM27"}
SNAPSHOT = ("MSCR_BO_staged.m", "select_batch_greedy.m",
            "greedy_qlognehvi_bridge.py", "elite_walk_spread.m",
            "surrepair_gate_engineering.m", "run_holdout_case.m",
            "export_initials.m")


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def initial(test: int, seed: int) -> Path:
    return ROOT / "initial" / f"T{test:02d}_seed{seed:03d}.csv"


def egbo(test: int, seed: int) -> Path:
    return ROOT / "results" / "egbo" / f"seed{seed:03d}" / f"T{test:02d}"


def mscr(test: int, seed: int) -> Path:
    return ROOT / "results" / "mscr" / f"T{test:02d}" / f"seed{seed:03d}"


def prior_metadata(test: int) -> Path:
    if test == 54:
        return OLD / "工程验证_RCM21_10重复" / "EGBO_seed60" / "T54" / "metadata.json"
    if test == 57:
        return OLD / "工程验证_RCM27_10重复" / "EGBO_seed60" / "T57" / "metadata.json"
    return (LEGACY / "科研实验报告_新版" / "对比实验_预算114_八函数"
            / "EGBO_144_seed0" / f"T{test:02d}" / "metadata.json")


def write_status(**fields) -> None:
    (ROOT / "campaign_status.json").write_text(
        json.dumps(fields, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def prepare_and_audit() -> None:
    assert MATLAB.is_file() and PYTHON.is_file() and AUTHOR_RUNNER.is_file()
    protocol = json.loads((ROOT / "protocol.json").read_text(encoding="utf-8"))
    assert protocol["seeds"] == list(SEEDS)
    assert protocol["cases"] == {NAME[t]: t for t in TESTS}
    refs = json.loads((ROOT / "reference_points.json").read_text(encoding="utf-8"))
    lock = {"protocol_sha256": digest(ROOT / "protocol.json"),
            "reference_sha256": digest(ROOT / "reference_points.json"),
            "source_sha256": {name: digest(ROOT / name) for name in SNAPSHOT},
            "external_source_sha256": {str(path): digest(path) for path in (
                AUTHOR_RUNNER, AUTHOR_SOURCE, LEGACY / "egbo_author_eval_server.m",
                LEGACY / "initialize_variables.m", LEGACY / "GetFunInfo.m",
                LEGACY / "eval_batch.m", LEGACY / "diffusion_params.m")},
            "initial_sha256": {}, "reference_origin_sha256": {}}
    for test in TESTS:
        key = f"T{test:02d}"
        prior = prior_metadata(test)
        metadata = json.loads(prior.read_text(encoding="utf-8"))
        assert np.allclose(refs[key], metadata["acquisition_ref_minimization"],
                           rtol=0, atol=1e-12)
        assert metadata["candidate_pool_per_round"] == 144
        assert metadata["qnehvi_candidates"] == 16
        assert metadata["evo_candidates"] == 128
        assert metadata["qbo_chunk"] == 8
        lock["reference_origin_sha256"][key] = digest(prior)
        stub = ROOT / "reference" / key / "metadata.json"
        stub.parent.mkdir(parents=True, exist_ok=True)
        expected = {"acquisition_ref_minimization": refs[key]}
        if stub.exists():
            assert json.loads(stub.read_text(encoding="utf-8")) == expected
        else:
            stub.write_text(json.dumps(expected, indent=2) + "\n", encoding="utf-8")
        d, m, c = metadata["n_var"], metadata["n_obj"], metadata["n_constr"]
        for seed in SEEDS:
            path = initial(test, seed)
            x = np.loadtxt(path, delimiter=",")
            assert x.shape == (18, d + m + c) and np.isfinite(x).all(), path
            lock["initial_sha256"][f"{key}/seed{seed}"] = digest(path)
    path = ROOT / "input_lock.json"
    if path.exists():
        assert json.loads(path.read_text(encoding="utf-8")) == lock
    else:
        path.write_text(json.dumps(lock, ensure_ascii=False, indent=2) + "\n",
                        encoding="utf-8")
    print("PAIRED_NEW_SEED_INPUTS_LOCKED count=50", flush=True)


def verify_egbo(test: int, seed: int) -> bool:
    try:
        folder = egbo(test, seed)
        meta = json.loads((folder / "metadata.json").read_text(encoding="utf-8"))
        train = np.loadtxt(folder / "train_data.csv", delimiter=",")
        first = np.loadtxt(initial(test, seed), delimiter=",")
        d, m, c = meta["n_var"], meta["n_obj"], meta["n_constr"]
        assert meta["test_id"] == test and meta["seed"] == seed
        assert meta["budget"] == 114 and meta["physical_eval_count"] == 114
        assert meta["initial"] == 18 and meta["batches"] == 12
        assert meta["batch_size"] == 8 and meta["sampler_samples"] == 16
        assert meta["candidate_pool_per_round"] == 144
        assert (meta["qnehvi_candidates"], meta["evo_candidates"],
                meta["qbo_chunk"]) == (16, 128, 8)
        assert meta["device"].startswith("cuda")
        assert meta["source_sha256"] == digest(AUTHOR_SOURCE)
        assert np.allclose(meta["acquisition_ref_minimization"],
                           json.loads((ROOT / "reference_points.json").read_text(
                               encoding="utf-8"))[f"T{test:02d}"], rtol=0, atol=1e-12)
        assert train.shape == (114, d + m + c) and np.isfinite(train).all()
        paired = np.column_stack((train[:18, :d], -train[:18, d:d + m],
                                  train[:18, d + m:]))
        assert np.allclose(paired, first, rtol=0, atol=1e-8)
        return True
    except (OSError, ValueError, TypeError, KeyError, AssertionError):
        return False


def verify_mscr(test: int, seed: int) -> bool:
    try:
        folder = mscr(test, seed)
        info = json.loads((folder / "status.json").read_text(encoding="utf-8"))
        assert info["status"] == "ok" and info["test_id"] == test
        assert info["seed"] == seed and info["budget"] == 114
        assert info["source_quota"] == [5, 8, 5]
        first = np.loadtxt(initial(test, seed), delimiter=",")
        for it in range(13):
            data = np.loadtxt(folder / f"round_{it:02d}.csv", delimiter=",")
            assert data.shape == (18 + 8 * it, first.shape[1])
            assert np.isfinite(data).all()
            assert np.allclose(data[:18], first, rtol=0, atol=1e-8)
        log = (folder / "progress.log").read_text(encoding="utf-8")
        assert len(re.findall(r"iter=\d+/12", log)) == 12
        assert len(re.findall(r"greedy_round=\d+", log)) == 12
        if test == 57:
            assert info["objective_rows_after_initial"] == 96
        return True
    except (OSError, ValueError, TypeError, KeyError, AssertionError):
        return False


def run_egbo_seed(seed: int) -> None:
    if all(verify_egbo(t, seed) for t in TESTS):
        return
    out = ROOT / "results" / "egbo" / f"seed{seed:03d}"
    out.mkdir(parents=True, exist_ok=True)
    log = out / "runner.log"
    command = [str(PYTHON), str(AUTHOR_RUNNER), "--cases",
               ",".join(map(str, TESTS)), "--seed", str(seed),
               "--output-dir", str(out), "--initial-root", str(ROOT / "initial"),
               "--reference-root", str(ROOT / "reference"),
               "--qbo", "16", "--evo", "128", "--qbo-chunk", "8",
               "--port", str(48100 + seed - 100)]
    env = os.environ.copy()
    env["MATLAB_PREFDIR"] = str(ROOT / "matlab_prefs")
    for attempt in range(3):
        with log.open("ab") as stream:
            proc = subprocess.run(command, cwd=LEGACY, env=env, stdout=stream,
                                  stderr=subprocess.STDOUT,
                                  creationflags=subprocess.CREATE_NO_WINDOW)
        missing = [t for t in TESTS if not verify_egbo(t, seed)]
        if not missing:
            print(f"EGBO_SEED_COMPLETE seed={seed} exit={proc.returncode}", flush=True)
            return
        print(f"EGBO_RETRY seed={seed} attempt={attempt+1} missing={missing}", flush=True)
    raise RuntimeError(f"EGBO seed {seed}: incomplete cases {missing}; inspect {log}")


def run_mscr(test: int, seed: int) -> None:
    if verify_mscr(test, seed):
        return
    out = mscr(test, seed)
    for attempt in range(3):
        if out.exists() and any(out.iterdir()):
            if (out / "status.json").exists():
                raise RuntimeError(f"Invalid completed MSCR run: {out}")
            archived = out.with_name(f"{out.name}_failed_attempt{attempt+1:02d}")
            assert archived.resolve().is_relative_to((ROOT / "results").resolve())
            out.rename(archived)
        out.mkdir(parents=True, exist_ok=True)
        env = os.environ.copy()
        env["DPR_QLOGNEHVI_PYTHON"] = str(PYTHON)
        env["MATLAB_PREFDIR"] = str(ROOT / "matlab_prefs")
        command = [str(MATLAB), "-wait", "-nouserjavapath", "-batch",
                   f"run_holdout_case({test},{seed})"]
        with (out / "matlab.log").open("ab") as stream:
            proc = subprocess.Popen(command, cwd=ROOT, env=env,
                                    stdout=stream, stderr=subprocess.STDOUT,
                                    creationflags=subprocess.CREATE_NO_WINDOW)
            started = time.monotonic()
            try:
                while proc.poll() is None:
                    elapsed = time.monotonic() - started
                    if elapsed > 300 and not (out / "round_00.csv").exists():
                        raise TimeoutError(f"MATLAB startup timeout: {out}")
                    if elapsed > 2400:
                        raise TimeoutError(f"MATLAB case timeout: {out}")
                    time.sleep(2)
            except BaseException:
                if proc.poll() is None:
                    subprocess.run(["taskkill", "/PID", str(proc.pid), "/T", "/F"],
                                   stdout=subprocess.DEVNULL,
                                   stderr=subprocess.DEVNULL, check=False)
                raise
        if verify_mscr(test, seed):
            print(f"MSCR_COMPLETE T{test:02d} seed={seed} exit={proc.returncode}",
                  flush=True)
            return
        if (out / "status.json").exists():
            raise RuntimeError(f"MSCR result failed verification: {out}")
    raise RuntimeError(f"Three incomplete MSCR attempts: {out}")


def main() -> None:
    prepare_and_audit()
    completed = sum(verify_egbo(t, s) + verify_mscr(t, s)
                    for s in SEEDS for t in TESTS)
    for seed in SEEDS:
        write_status(status="running", current_method="EGBO", current_seed=seed,
                     completed_method_runs=completed, total_method_runs=100)
        run_egbo_seed(seed)
        completed = sum(verify_egbo(t, s) + verify_mscr(t, s)
                        for s in SEEDS for t in TESTS)
        for test in TESTS:
            write_status(status="running", current_method="MSCR-BO",
                         current_case=NAME[test], current_seed=seed,
                         completed_method_runs=completed, total_method_runs=100)
            run_mscr(test, seed)
            completed += 1
    assert all(verify_egbo(t, s) and verify_mscr(t, s)
               for s in SEEDS for t in TESTS)
    write_status(status="analysis_running", completed_method_runs=100,
                 total_method_runs=100)
    subprocess.run([str(PYTHON), str(ROOT / "analyze_campaign.py")],
                   cwd=ROOT, check=True)
    write_status(status="analysis_complete", completed_method_runs=100,
                 total_method_runs=100)


if __name__ == "__main__":
    try:
        main()
    except BaseException as exc:
        write_status(status="failed", error=f"{type(exc).__name__}: {exc}")
        raise
