function f = MSCR_BO_staged(params, MultiObj)
%MSCR_BO  多源候选生成 + qLogNEHVI 选批 + 可配置约束修复。
%   文件角色与结构对应蜣螂包 NSDBO.m；测试函数/真实前沿/指标沿用蜣螂包标准。
%   主实验在选批后、真实评估前使用安全代理修复；无约束问题只投影边界。
tic
D = MultiObj.nVar; M = MultiObj.numOfObj;
LB = MultiObj.var_min; UB = MultiObj.var_max;
params.diffusion_checkpoint=[tempname '.pt'];
diffusion_guard=onCleanup(@() diffusion_cleanup(params)); %#ok<NASGU>
if isfield(params,'frozen_initial_file') && ~isempty(params.frozen_initial_file)
    initial=readmatrix(params.frozen_initial_file);
    assert(size(initial,1)==params.n_init && ...
        size(initial,2)>=D+M,'Frozen initial design has invalid dimensions.');
    chrom=initial(:,1:D+M);
    G=initial(:,D+M+1:end);
    % Initial observations are audited once before the campaign. Reusing
    % them here avoids uncounted duplicate true evaluations.
    assert(all(isfinite(initial(:))),'Frozen initial data must be finite.');
else
    [chrom, G] = initialize_variables(params.n_init, MultiObj);
end
X = chrom(:, 1:D);
F = chrom(:, D+1:D+M);
if isfield(params,'frozen_trace_file') && ~isempty(params.frozen_trace_file)
    trace_X=cell(params.n_iter+1,1); trace_F=trace_X; trace_G=trace_X;
    trace_X{1}=X; trace_F{1}=F; trace_G{1}=G;
end
walk_stagnation_rounds = 0;
for it = 1:params.n_iter
    if isfield(MultiObj, 'truePF') && ~isempty(MultiObj.truePF)
        pfarg = MultiObj.truePF;                        % 严格盒（HV.m 归一化口径）
    else
        pfarg = 1.05*max([F; zeros(1, M)], [], 1)/1.1;  % 无真前沿：归档可达盒编码
    end
    params.acq_train_x=X; params.acq_train_f=F; params.acq_train_g=G;
    params.acq_lb=LB; params.acq_ub=UB;
    params.acq_seed=randi(2^31-1); params.acq_cache=[tempname '.pt'];
    cache_guard=onCleanup(@() qlognehvi_cleanup(params)); %#ok<NASGU>
    if strcmp(params.ablation_arm,'QLOG_BASE')
        Xf=LB+rand(18*params.q,D).*(UB-LB);
    else
    Xf=zeros(0,D);
    if params.n_cand>0
        Xf=diffusion_candidates(X,F,G,LB,UB,params);
    end
    if params.walk_batches>0
        params.walk_stagnation_rounds = walk_stagnation_rounds;
        if strcmp(params.ablation_arm,'NO_SPREAD_ANCHOR')
            Xw=elite_walk(X,F,G,params.q,LB,UB,params);
        else
            Xw=elite_walk_spread(X,F,G,params.q,LB,UB,params);
        end
        Xf=[Xf;Xw]; %#ok<AGROW>
    end
    if params.acqf_starts>0
        Xf = [Xf; qlognehvi_optimize(Xf, params, pfarg)]; %#ok<AGROW> 采集梯度优化候选
    end
    end
    assert(size(Xf,1)==18*params.q);
    params.selection_round=it;
    if strcmp(params.ablation_arm,'NO_GREEDY')
        [Xb,batch_index]=select_batch(@(Z) qlognehvi_score(Z,params,pfarg), ...
            Xf,params.q,params,LB,UB);
    else
        [Xb,batch_index] = select_batch_greedy(Xf,params,pfarg);
    end
    clear cache_guard;
    if strcmp(params.ablation_arm,'NO_REPAIR')
        Xb=min(max(Xb,LB),UB);
    else
        Xb=surrepair_gate_engineering(Xb,X,G,LB,UB,@(XX) eval_con(MultiObj,XX),params);
    end
    [Fn, Gn] = eval_batch(MultiObj, Xb);
    if archive_gain(F,G,Fn,Gn)
        walk_stagnation_rounds = 0;
    else
        walk_stagnation_rounds = walk_stagnation_rounds + 1;
    end
    X = [X; Xb]; F = [F; Fn]; G = [G; Gn];
    if isfield(params,'frozen_trace_file') && ~isempty(params.frozen_trace_file)
        trace_X{it+1}=X; trace_F{it+1}=F; trace_G{it+1}=G;
        save(params.frozen_trace_file,'trace_X','trace_F','trace_G', ...
            'it','batch_index','-v7.3');
        trace_dir=fileparts(params.frozen_trace_file);
        writematrix([X,F,G],fullfile(trace_dir, ...
            sprintf('round_%02d.csv',it)));
    end
    disp(['MSCR-BO Iteration ' num2str(it) ': Number of solutions in the archive = ' ...
        num2str(size(feasible_nd(F, G), 1))]);
    if isfield(params, 'logfile')
        fid = fopen(params.logfile, 'a');
        fprintf(fid, 'iter=%d/%d elapsed=%.1fs n=%d nFront=%d\n', ...
            it, params.n_iter, toc, size(X, 1), size(feasible_nd(F, G), 1));
        fclose(fid);
    end
end
f = build_repo(X, F, G, M, D, params.Nr);
clear diffusion_guard;
toc
end
