function [Xr,diag] = surrepair_gate_engineering(X,Xd,G,LB,UB,evalG,p)
%SURREPAIR_GATE_ENGINEERING Preserve already feasible selected points.
X0=min(max(X,LB),UB);
Xr=X0;
diag=struct('pre_feasible',size(X,1),'triggered',0,'moved',0, ...
    'mean_normalized_move',0);
if isempty(G) || size(G,2)==0
    return;
end
G0=evalG(X0); % One exact check of the selected q points, as in the baseline.
assert(size(G0,1)==size(X0,1) && size(G0,2)==size(G,2));
diag.pre_feasible=sum(all(G0<=0,2));
need=sum(max(G0,0),2)>p.repair_tol;
diag.triggered=sum(need);
if any(need)
    proposed=X0(need,:);
    if any(all(G<=0,2))
        proposed=surrepair(proposed,Xd,G,LB,UB,p);
    end
    proposed=conditional_prerepair(proposed,LB,UB,G,evalG, ...
        p.repair_steps,p.repair_lr,p.repair_tol);
    Xr(need,:)=proposed;
end
displacement=abs((Xr-X0)./(UB-LB));
diag.moved=sum(any(displacement>1e-12,2));
diag.mean_normalized_move=mean(max(displacement,[],2));
assert(all(all(Xr>=LB-1e-10)) && all(all(Xr<=UB+1e-10)));
assert(isequal(Xr(~need,:),X0(~need,:)), ...
    'Feasible selected points must remain unchanged.');
end
