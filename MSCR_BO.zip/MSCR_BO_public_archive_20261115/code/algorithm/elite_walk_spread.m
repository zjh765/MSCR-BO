function Xw = elite_walk_spread(X,F,G,q,LB,UB,p)
%ELITE_WALK_SPREAD Original multiscale walk with spread elite anchors.
% The only experimental change is the choice of q elite centers per batch.
LB=LB(:)'; UB=UB(:)';
d=size(X,2); n=size(X,1);
if isempty(G), feas=true(n,1); else, feas=all(G<=0,2); end
msk=false(n,1);
if any(feas)
    idx=find(feas);
    nd=non_dominated_front(F(feas,:));
    msk(idx(nd))=true;
end
Xe=X(msk,:);
Fe=F(msk,:);
if isempty(Xe)
    violation=sum(max(G,0),2);
    [~,order]=sort(violation,'ascend');
    use=order(1:min(numel(order),max(q,5)));
    Xe=X(use,:); Fe=F(use,:);
end
E=size(Xe,1); K=p.walk_batches; bw=UB-LB;
sig=p.walk_sigma*[1,0.5,0.25];
if isfield(p,'walk_adaptive') && p.walk_adaptive
    patience=p.walk_stall_patience;
    assert(patience>=1 && patience==floor(patience));
    stalled=0;
    if isfield(p,'walk_stagnation_rounds')
        stalled=p.walk_stagnation_rounds;
    end
    factor=min(p.walk_expand_max,p.walk_expand_factor^floor(stalled/patience));
    sig=min(sig*factor,0.5);
end
% Objective scales are based only on already evaluated feasible elites.
span=max(Fe,[],1)-min(Fe,[],1);
span(span<1e-12)=1;
Z=(Fe-min(Fe,[],1))./span;
Xw=zeros(K*q,d);
for i=1:K
    centers=zeros(1,q);
    centers(1)=randi(E);
    chosen=false(E,1); chosen(centers(1))=true;
    for t=2:min(q,E)
        delta=Z-reshape(Z(centers(1),:),1,[]);
        nearest=sum(delta.^2,2);
        for k=2:t-1
            delta=Z-reshape(Z(centers(k),:),1,[]);
            nearest=min(nearest,sum(delta.^2,2));
        end
        nearest(chosen)=-Inf;
        [~,centers(t)]=max(nearest);
        chosen(centers(t))=true;
    end
    if E<q
        centers(E+1:q)=randi(E,1,q-E);
    end
    s=sig(mod(i-1,3)+1);
    Xw((i-1)*q+(1:q),:)=min(max(Xe(centers,:)+s*bw.*randn(q,d), ...
        repmat(LB,q,1)),repmat(UB,q,1));
end
end
