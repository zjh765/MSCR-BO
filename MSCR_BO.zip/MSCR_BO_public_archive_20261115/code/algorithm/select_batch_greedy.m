function [Xb,selected] = select_batch_greedy(Xf,p,~)
%SELECT_BATCH_GREEDY Assemble q points using conditional raw joint qLogNEHVI.
% Every proposal in the unchanged 144-point pool is considered at each step.
assert(size(Xf,1)==p.q*(p.n_cand+p.walk_batches+p.acqf_starts), ...
    'The locked candidate pool must contain exactly 144 points.');
assert(p.n_cand+p.walk_batches+p.acqf_starts==18);
assert(p.q==8 && size(Xf,1)==144 && all(isfinite(Xf(:))));
assert(isfield(p,'fixed_ref_strict') && p.fixed_ref_strict && ...
    isfield(p,'acq_ref_override') && ~isempty(p.acq_ref_override));
ref=reshape(p.acq_ref_override,1,[]);
assert(numel(ref)==size(p.acq_train_f,2) && all(isfinite(ref)));
request=struct('mode','greedy','train_x',p.acq_train_x, ...
    'train_f',p.acq_train_f,'train_g',p.acq_train_g, ...
    'n_constraints',size(p.acq_train_g,2), ...
    'lb',p.acq_lb,'ub',p.acq_ub,'ref',ref,'candidate',Xf, ...
    'q',p.q,'seed',p.acq_seed,'model_cache',p.acq_cache, ...
    'mc_samples',p.mc_samples,'gp_kernel',p.gp_kernel, ...
    'require_gpu',p.require_gpu);
input=[tempname '.json']; output=[tempname '.json'];
cleanup=onCleanup(@() cleanup_files(input,output)); %#ok<NASGU>
fid=fopen(input,'w','n','UTF-8');
assert(fid>0,'Cannot write greedy selection request.');
fprintf(fid,'%s',jsonencode(request)); fclose(fid);
here=fileparts(mfilename('fullpath'));
python=getenv('DPR_QLOGNEHVI_PYTHON');
assert(exist(python,'file')==2,'BoTorch Python environment missing.');
script=fullfile(here,'greedy_qlognehvi_bridge.py');
timer=tic;
[status,message]=system(sprintf('"%s" "%s" "%s" "%s"', ...
    python,script,input,output));
assert(status==0 && exist(output,'file')==2, ...
    'Greedy joint qLogNEHVI failed: %s',message);
result=jsondecode(fileread(output));
selected=reshape(double(result.selected_indices),1,[])+1;
assert(numel(selected)==p.q && numel(unique(selected))==p.q && ...
    all(selected>=1 & selected<=size(Xf,1)));
Xb=Xf(selected,:);
assert(all(isfinite(Xb(:))));
if isfield(p,'logfile') && ~isempty(p.logfile)
    fid=fopen(p.logfile,'a'); assert(fid>0);
    fprintf(fid,'greedy_round=%d seconds=%.2f source_counts=%d,%d,%d joint_score=%.8g\n', ...
        p.selection_round,toc(timer),sum(selected<=p.n_cand*p.q), ...
        sum(selected>p.n_cand*p.q & ...
            selected<=(p.n_cand+p.walk_batches)*p.q), ...
        sum(selected>(p.n_cand+p.walk_batches)*p.q), ...
        result.final_joint_score);
    fclose(fid);
end
end

function cleanup_files(input,output)
if exist(input,'file'), delete(input); end
if exist(output,'file'), delete(output); end
end
