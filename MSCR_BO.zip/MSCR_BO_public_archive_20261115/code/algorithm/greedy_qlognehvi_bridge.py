"""Score MATLAB batches with the BoTorch qLogNEHVI used by the EGBO code.

The protocol is one JSON request and one JSON response. Objectives are
minimized in MATLAB and negated for BoTorch; constraints remain G <= 0.
"""

import json
import sys
import time
import warnings
from pathlib import Path

import numpy as np
import torch
from botorch.acquisition.multi_objective.logei import (
    qLogNoisyExpectedHypervolumeImprovement,
)
from botorch.acquisition.multi_objective.objective import IdentityMCMultiOutputObjective
from botorch.fit import fit_gpytorch_mll
from botorch.models.gp_regression import SingleTaskGP
from botorch.models.model_list_gp_regression import ModelListGP
from botorch.models.transforms.outcome import Standardize
from botorch.models.utils.gpytorch_modules import get_covar_module_with_dim_scaled_prior
from botorch.optim.optimize import optimize_acqf
from botorch.sampling.normal import SobolQMCNormalSampler
from gpytorch.mlls.sum_marginal_log_likelihood import SumMarginalLogLikelihood


def matrix(value, columns):
    array = np.asarray(value, dtype=float)
    if array.size == 0:
        return np.empty((0, columns), dtype=float)
    return array.reshape((-1, columns))


def run(request):
    lb = np.asarray(request["lb"], dtype=float).reshape(-1)
    ref = np.asarray(request["ref"], dtype=float).reshape(-1)
    d, m = len(lb), len(ref)
    x = np.asarray(request["train_x"], dtype=float).reshape((-1, d))
    y = np.asarray(request["train_f"], dtype=float).reshape((-1, m))
    if len(x) != len(y):
        raise ValueError("Training X and F must be aligned 2-D arrays")
    n = len(x)
    g = matrix(request.get("train_g", []), int(request.get("n_constraints", 0)))
    if g.size == 0:
        g = np.empty((n, 0), dtype=float)
    if g.shape[0] != n:
        raise ValueError("Training constraints must align with X")
    ub = np.asarray(request["ub"], dtype=float).reshape(d)
    if np.any(ub <= lb) or not all(np.isfinite(a).all() for a in (x, y, g, ref)):
        raise ValueError("Non-finite data or invalid bounds")
    q = int(request["q"])
    candidate = np.asarray(request["candidate"], dtype=float).reshape((-1, q, d))
    if len(candidate) == 0:
        raise ValueError("Candidate pool is empty")

    torch.manual_seed(int(request["seed"]))
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    if request.get("require_gpu", False) and device.type != "cuda":
        raise RuntimeError("CUDA is required for BoTorch qLogNEHVI")
    torch.set_default_dtype(torch.double)
    to_t = lambda a: torch.as_tensor(a, dtype=torch.double, device=device)
    x_gp = to_t(np.clip((x - lb) / (ub - lb), 0, 1))
    yc = np.concatenate((-y, g), axis=1)
    train_y = to_t(yc)
    kernel = request.get("gp_kernel", "rbf")
    if kernel not in ("rbf", "matern52"):
        raise ValueError(f"Unknown GP kernel: {kernel}")
    models = [
        SingleTaskGP(
            x_gp, train_y[:, i:i + 1],
            outcome_transform=Standardize(m=1),
            **({"covar_module": get_covar_module_with_dim_scaled_prior(
                ard_num_dims=d, use_rbf_kernel=False)} if kernel == "matern52" else {}),
        )
        for i in range(train_y.shape[1])
    ]
    model = ModelListGP(*models)
    cache = Path(request["model_cache"])
    reused = cache.is_file()
    if reused:
        model.load_state_dict(torch.load(cache, map_location=device, weights_only=True))
        model.eval()
    else:
        mll = SumMarginalLogLikelihood(model.likelihood, model)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            fit_gpytorch_mll(mll, max_retries=1, options={"maxiter": 50})
        torch.save(model.state_dict(), cache)
    candidate_gp = to_t(np.clip((candidate - lb) / (ub - lb), 0, 1))
    mode = request["mode"]
    if mode == "surrogate_de":
        result = surrogate_de_candidates(model, x_gp, train_y, q, m, g.shape[1],
                                         int(request["seed"]), device)
        result = result * (ub - lb) + lb
        return {"candidates": result.tolist(), "model_reused": reused,
                "source": "pad_inspired_surrogate_de_v1", "device": str(device)}
    constraints = [
        (lambda z, i=i: z[..., i]) for i in range(m, m + g.shape[1])
    ] or None
    acq = qLogNoisyExpectedHypervolumeImprovement(
        model=model,
        ref_point=(-ref).tolist(),
        X_baseline=x_gp,
        sampler=SobolQMCNormalSampler(sample_shape=torch.Size([int(request["mc_samples"])])),
        objective=IdentityMCMultiOutputObjective(outcomes=list(range(m))),
        constraints=constraints,
        prune_baseline=True,
        cache_pending=True,
    )
    if mode == "greedy":
        if q != 8 or candidate_gp.shape[0] != 18:
            raise ValueError("Locked greedy experiment requires 18 batches of 8")
        pool = candidate_gp.reshape((-1, d))
        selected = []
        scores_at_choice = []
        started = time.perf_counter()
        with torch.no_grad():
            for _ in range(q):
                remaining = [i for i in range(len(pool)) if i not in selected]
                values = []
                for offset in range(0, len(remaining), 16):
                    ids = remaining[offset:offset + 16]
                    proposed = pool[ids].unsqueeze(1)
                    if selected:
                        prefix = pool[selected].unsqueeze(0).expand(len(ids), -1, -1)
                        proposed = torch.cat((prefix, proposed), dim=1)
                    values.extend(acq(proposed).detach().cpu().tolist())
                if not np.isfinite(values).all():
                    raise ValueError("Conditional joint qLogNEHVI returned non-finite scores")
                best = int(np.argmax(values))  # Stable lower-index tie break.
                selected.append(remaining[best])
                scores_at_choice.append(float(values[best]))
        return {"selected_indices": selected,
                "conditional_scores": scores_at_choice,
                "final_joint_score": scores_at_choice[-1],
                "candidate_count": len(pool), "model_reused": reused,
                "selection_seconds": time.perf_counter() - started,
                "device": str(device)}
    if request["mode"] == "score":
        scores = []
        with torch.no_grad():
            for chunk in candidate_gp.split(16):
                scores.extend(acq(chunk).detach().cpu().tolist())
        if not np.isfinite(scores).all():
            raise ValueError("qLogNEHVI returned non-finite scores")
        response = {"values": scores, "model_reused": reused, "device": str(device)}
        if request.get("predict_means", False):
            with torch.no_grad():
                flat = candidate_gp.reshape((-1, d))
                means = -model.posterior(flat).mean[..., :m]
                response["predicted_means_minimization"] = means.cpu().tolist()
        return response
    if request["mode"] == "optimize":
        starts = min(int(request["acqf_starts"]), len(candidate_gp))
        global_starts = int(request.get("acq_global_starts", 0))
        if global_starts < 0 or global_starts > starts:
            raise ValueError("Global Sobol starts must be between zero and total starts")
        local_starts = starts - global_starts
        with torch.no_grad():
            initial_parts = []
            if local_starts:
                pre = torch.cat([acq(chunk) for chunk in candidate_gp.split(16)])
                initial_parts.append(candidate_gp[torch.topk(pre, local_starts).indices])
            if global_starts:
                sobol = torch.quasirandom.SobolEngine(
                    dimension=d, scramble=True, seed=int(request["seed"]))
                initial_parts.append(sobol.draw(global_starts * q).to(device).reshape(
                    global_starts, q, d).to(dtype=torch.double))
            initial = torch.cat(initial_parts)
        bounds = to_t(np.stack((np.zeros(d), np.ones(d))))
        optimized, _ = optimize_acqf(
            acq,
            bounds=bounds,
            q=q,
            num_restarts=starts,
            batch_initial_conditions=initial,
            return_best_only=False,
            options={"batch_limit": min(starts, 4), "maxiter": int(request["acqf_maxiter"])},
        )
        result = optimized.detach().cpu().numpy().reshape((-1, d)) * (ub - lb) + lb
        if not np.isfinite(result).all():
            raise ValueError("qLogNEHVI optimization returned non-finite candidates")
        return {"candidates": result.tolist(), "model_reused": reused}
    raise ValueError("Unknown bridge mode")


def surrogate_de_candidates(model, observed_x, train_y, q, m, n_constraints,
                            seed, device):
    """PAD-DE inspired operators on GP predictions; no true evaluations here.

    Eight reference directions each evolve a small DE subpopulation. The
    original PAD-DE is single-objective; this is a documented adaptation.
    """
    rng = np.random.default_rng(seed)
    d = observed_x.shape[-1]
    group = 12
    generations = 12
    pop_n = q * group
    sobol = torch.quasirandom.SobolEngine(d, scramble=True, seed=seed)
    pop = sobol.draw(pop_n).numpy().astype(float)
    observed = observed_x.detach().cpu().numpy()
    if len(observed):
        chosen = observed[rng.integers(len(observed), size=pop_n // 3)]
        pop[:len(chosen)] = np.clip(chosen + rng.normal(0, .12, chosen.shape), 0, 1)
    weights = np.empty((q, m), dtype=float)
    for k in range(q):
        weights[k] = rng.dirichlet(np.ones(m))
    if m == 2:
        weights[:, 0] = np.linspace(.08, .92, q)
        weights[:, 1] = 1 - weights[:, 0]
    weights = np.repeat(weights, group, axis=0)
    known = -train_y[:, :m].detach().cpu().numpy()
    ideal = known.min(axis=0)
    scale = np.maximum(np.ptp(known, axis=0), 1e-5)

    def fitness(z):
        with torch.no_grad():
            posterior = model.posterior(torch.as_tensor(z, dtype=torch.double, device=device))
            means = posterior.mean.detach().cpu().numpy()
            std = posterior.variance.clamp_min(1e-12).sqrt().detach().cpu().numpy()
        optimistic = -means[:, :m] - .15 * std[:, :m]
        normalized = (optimistic - ideal) / scale
        value = np.max(weights * normalized, axis=1) + .05 * np.sum(weights * normalized, axis=1)
        if n_constraints:
            # Predicted constraint violations are penalized without querying truth.
            violation = np.maximum(means[:, m:] + .5 * std[:, m:], 0).sum(axis=1)
            value += 10 * violation
        return value

    values = fitness(pop)
    stagnant = np.zeros(pop_n, dtype=int)
    for gen in range(generations):
        phase = gen / max(generations - 1, 1)
        # Morlet-like oscillation damps as the search proceeds.
        wave = np.cos(5 * phase) * np.exp(-2 * phase * phase)
        factor = np.clip(.75 - .28 * phase + .13 * wave, .32, .95)
        crossover = np.clip(.65 + .20 * phase - .08 * wave, .35, .95)
        trial = np.empty_like(pop)
        for k in range(q):
            block = np.arange(k * group, (k + 1) * group)
            for i in block:
                a, b, c = rng.choice(block[block != i], size=3, replace=False)
                mutant = np.clip(pop[a] + factor * (pop[b] - pop[c]), 0, 1)
                mask = rng.random(d) < crossover
                mask[rng.integers(d)] = True
                trial[i] = np.where(mask, mutant, pop[i])
        # Stochastic reflective perturbation from PAD-DE, applied sparingly.
        reflect = rng.random(pop_n) < .08
        trial[reflect] = np.clip(1 - trial[reflect], 0, 1)
        trial_values = fitness(trial)
        improved = trial_values < values
        pop[improved], values[improved] = trial[improved], trial_values[improved]
        stagnant[improved] = 0
        stagnant[~improved] += 1
        for k in range(q):
            block = slice(k * group, (k + 1) * group)
            if np.mean(np.std(pop[block], axis=0)) < .035:
                tired = np.where(stagnant[block] >= 4)[0]
                if len(tired):
                    indices = k * group + tired[:max(1, group // 4)]
                    pop[indices] = sobol.draw(len(indices)).numpy()
                    values[indices] = fitness(pop)[indices]
                    stagnant[indices] = 0
    chosen = [k * group + np.argmin(values[k * group:(k + 1) * group]) for k in range(q)]
    return pop[chosen]


def main():
    request_path, response_path = map(Path, sys.argv[1:3])
    request = json.loads(request_path.read_text(encoding="utf-8"))
    result = run(request)
    response_path.write_text(json.dumps(result), encoding="utf-8")


if __name__ == "__main__":
    main()
