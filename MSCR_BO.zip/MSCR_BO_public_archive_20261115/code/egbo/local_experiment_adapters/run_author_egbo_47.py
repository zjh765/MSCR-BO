"""Run the author's EGBO optimizer on the selected eight MATLAB benchmarks.

The imported optimizer is unchanged. A persistent MATLAB evaluator supplies the
exact objective definitions and seed-0 initial design used by the comparison methods.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
import traceback

import numpy as np
import torch

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "科研实验报告_新版" / "对比实验_预算114_八函数" / "EGBO_144_seed0"
AUTHOR = ROOT / "科研实验报告_新版" / "临时_原作者EGBO_ZDT1_预算56" / "author_original"
MATLAB = Path(r"E:\Program Files\Polyspace\R2020a\bin\matlab.exe")
SOURCE = AUTHOR / "run_synthetic_pairwise_egbo_novelty_nehvi.py"
sys.path.insert(0, str(AUTHOR))
from run_synthetic_pairwise_egbo_novelty_nehvi import (  # noqa: E402
    optimize_egbo_matched_unconstrained,
    optimize_egbo_matched_constrained,
)


def request(port: int, data: dict) -> dict:
    with socket.create_connection(("127.0.0.1", port), timeout=120) as connection:
        connection.settimeout(120)
        connection.sendall((json.dumps(data, separators=(",", ":")) + "\n").encode())
        chunks = []
        while True:
            chunk = connection.recv(65536)
            if not chunk:
                break
            chunks.append(chunk)
            if b"\n" in chunk:
                break
    if not chunks:
        raise RuntimeError("MATLAB evaluator returned no data")
    response = json.loads(b"".join(chunks).split(b"\n", 1)[0])
    if response.get("status") != "ok":
        raise RuntimeError(response.get("message", "MATLAB evaluator failed"))
    return response


class LocalProblem:
    def __init__(self, meta: dict, port: int):
        self.test_id = int(meta["test_id"])
        self.n_var = int(meta["n_var"])
        self.n_obj = int(meta["n_obj"])
        self.n_constr = int(meta["n_constr"])
        self.port = port
        self.device = torch.device("cuda:0")
        self.bounds = torch.tensor([meta["lb"], meta["ub"]], dtype=torch.double, device=self.device)
        self.initial_x = np.asarray(meta["initial_x"], dtype=float).reshape(18, self.n_var)
        initial = np.asarray(meta["initial_f"], dtype=float).reshape(-1, self.n_obj)
        self.initial_f = initial
        self.initial_g = np.asarray(meta["initial_g"], dtype=float).reshape(18, self.n_constr)
        self.physical_eval_count = 18  # MATLAB metadata generated the initial 18 objectives.
        self.initial_cache_hits = 0
        pf_max = np.asarray(meta["pf_max"], dtype=float)
        scale = np.maximum(np.ptp(initial, axis=0), np.abs(pf_max))
        ref = np.maximum(pf_max, initial.max(axis=0)) + np.maximum(0.1 * scale, 1e-3)
        self.ref_point = torch.tensor(ref, dtype=torch.double, device=self.device)

    def evaluate(self, X: torch.Tensor):
        x = np.asarray(X.detach().cpu(), dtype=float).reshape(-1, self.n_var)
        if x.shape == self.initial_x.shape and np.array_equal(x, self.initial_x):
            self.initial_cache_hits += 1
            objective = torch.tensor(-self.initial_f, dtype=torch.double, device=self.device)
            if self.n_constr:
                constraint = torch.tensor(self.initial_g, dtype=torch.double, device=self.device)
                return objective, constraint
            return objective
        result = request(self.port, {"command": "evaluate", "test_id": self.test_id, "X": x.tolist()})
        f = np.asarray(result["F"], dtype=float).reshape(-1, self.n_obj)
        self.physical_eval_count += len(x)
        objective = torch.tensor(-f, dtype=torch.double, device=self.device)
        if self.n_constr:
            g = np.asarray(result["G"], dtype=float).reshape(-1, self.n_constr)
            return objective, torch.tensor(g, dtype=torch.double, device=self.device)
        return objective


def completed(case: Path, case_id: int, source_hash: str,
              qbo: int = 8, evo: int = 72, chunk_q: int = 0,
              seed: int = 0) -> bool:
    meta_file = case / "metadata.json"
    train_file = case / "train_data.csv"
    if not (meta_file.exists() and train_file.exists()):
        return False
    try:
        info = json.loads(meta_file.read_text(encoding="utf-8"))
        arr = np.loadtxt(train_file, delimiter=",")
        return (info["test_id"] == case_id and info.get("seed") == seed and info["budget"] == 114
                and info["initial"] == 18 and info["batches"] == 12
                and info["batch_size"] == 8
                and info["source_sha256"] == source_hash
                and info["qnehvi_candidates"] == qbo
                and info["evo_candidates"] == evo
                and info.get("qbo_chunk", 0) == chunk_q
                and info.get("physical_eval_count") == 114
                and info["device"].startswith("cuda")
                and arr.shape == (114, info["n_var"] + info["n_obj"] + info["n_constr"])
                and np.isfinite(arr).all())
    except Exception:
        return False


def run_case(case_id: int, port: int, source_hash: str,
             qbo: int = 8, evo: int = 72, chunk_q: int = 0,
             seed: int = 0, initial_root: Path | None = None,
             reference_root: Path | None = None, force: bool = False) -> None:
    case = OUT / f"T{case_id:02d}"
    case.mkdir(parents=True, exist_ok=True)
    if not force and completed(case, case_id, source_hash, qbo, evo, chunk_q, seed):
        print(f"SKIP T{case_id}: validated author result", flush=True)
        return
    meta = request(port, {"command": "metadata", "test_id": case_id, "seed": seed})
    if initial_root is not None:
        initial_file = initial_root / f"T{case_id:02d}_seed{seed:02d}.csv"
        initial = np.loadtxt(initial_file, delimiter=",").reshape(18, -1)
        d, m, c = int(meta["n_var"]), int(meta["n_obj"]), int(meta["n_constr"])
        assert initial.shape == (18, d + m + c)
        assert np.allclose(initial[:, :d], np.asarray(meta["initial_x"]), rtol=0, atol=1e-12)
        assert np.allclose(initial[:, d:d+m], np.asarray(meta["initial_f"]), rtol=0, atol=1e-8)
        meta["initial_x"] = initial[:, :d].tolist()
        meta["initial_f"] = initial[:, d:d+m].tolist()
        meta["initial_g"] = initial[:, d+m:].tolist()
    problem = LocalProblem(meta, port)
    if reference_root is not None:
        saved = json.loads((reference_root / f"T{case_id:02d}" / "metadata.json").read_text(encoding="utf-8"))
        problem.ref_point = torch.tensor(saved["acquisition_ref_minimization"],
                                         dtype=torch.double, device=problem.device)
    x0 = np.asarray(meta["initial_x"], dtype=float).reshape(18, problem.n_var)
    f0 = np.asarray(meta["initial_f"], dtype=float).reshape(18, problem.n_obj)
    # Verify that the local evaluator and initial design agree before optimization.
    observed = problem.evaluate(torch.tensor(x0, dtype=torch.double, device=problem.device))
    if problem.n_constr:
        obj_check, con_check = observed
        g0 = np.asarray(meta["initial_g"], dtype=float).reshape(18, problem.n_constr)
        assert np.allclose(con_check.cpu().numpy(), g0, rtol=1e-9, atol=1e-8)
    else:
        obj_check = observed
    check = -obj_check.cpu().numpy()
    assert np.allclose(check, f0, rtol=1e-9, atol=1e-8), f"T{case_id} initial objectives mismatch"
    torch.manual_seed(seed)
    np.random.seed(seed)
    print(f"START T{case_id} {meta['name']} GPU={torch.cuda.get_device_name(0)}", flush=True)
    start = time.monotonic()
    optimizer = (optimize_egbo_matched_constrained if problem.n_constr
                 else optimize_egbo_matched_unconstrained)
    hv, train, elapsed, selected, clean_obj, _, source_labels, acq_values = (
        optimizer(
            problem=problem, ref_point=problem.ref_point,
            initial_x=torch.tensor(x0, dtype=torch.double, device=problem.device),
            N_BATCH=12, BATCH_SIZE=8, random_state=seed, noise=0.0,
            qnehvi_candidates=qbo, evo_candidates=evo,
        )
    )
    arr = np.asarray(train, dtype=float)
    assert arr.shape == (114, problem.n_var + problem.n_obj + problem.n_constr)
    assert np.isfinite(arr).all()
    assert np.allclose(arr[:18, :problem.n_var], x0, rtol=0, atol=1e-12)
    assert len(source_labels) == 12
    assert all(len(labels) == qbo + evo for labels in source_labels)
    assert problem.physical_eval_count == 114, problem.physical_eval_count
    assert problem.initial_cache_hits >= 2, problem.initial_cache_hits
    np.savetxt(case / "train_data.csv.tmp", arr, delimiter=",", fmt="%.17g")
    os.replace(case / "train_data.csv.tmp", case / "train_data.csv")
    record = {
        "test_id": case_id, "name": meta["name"], "n_var": problem.n_var,
        "n_obj": problem.n_obj, "n_constr": problem.n_constr,
        "seed": seed, "initial": 18,
        "batches": 12, "batch_size": 8, "budget": 114,
        "qnehvi_candidates": qbo, "evo_candidates": evo,
        "qbo_chunk": chunk_q,
        "candidate_pool_per_round": qbo + evo,
        "sampler_samples": 16, "device": str(problem.device),
        "physical_eval_count": problem.physical_eval_count,
        "initial_cache_hits": problem.initial_cache_hits,
        "gpu_name": torch.cuda.get_device_name(0),
        "acquisition_ref_minimization": problem.ref_point.cpu().tolist(),
        "source_sha256": source_hash, "source_file": str(SOURCE),
        "elapsed_seconds": float(elapsed), "wall_seconds": time.monotonic() - start,
        "final_author_hv": float(hv[-1]),
        "selected_sources": source_labels,
        "selected_indices": [np.asarray(x).tolist() for x in selected],
    }
    (case / "metadata.json.tmp").write_text(json.dumps(record, indent=2), encoding="utf-8")
    os.replace(case / "metadata.json.tmp", case / "metadata.json")
    np.savetxt(case / "author_hv.csv", np.asarray(hv), delimiter=",")
    print(f"DONE T{case_id} time={elapsed:.1f}s wall={record['wall_seconds']:.1f}s", flush=True)
    del clean_obj, acq_values
    torch.cuda.empty_cache()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--cases", default="1,3,4,6,7,48,49,50")
    parser.add_argument("--port", type=int, default=47947)
    parser.add_argument("--output-dir", default=None)
    parser.add_argument("--qbo", type=int, default=8)
    parser.add_argument("--evo", type=int, default=72)
    parser.add_argument("--qbo-chunk", type=int, default=0)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--initial-root", default=None)
    parser.add_argument("--reference-root", default=None)
    parser.add_argument("--force", action="store_true",
                        help="recompute cases even when a validated result exists")
    args = parser.parse_args()
    global OUT
    if args.output_dir:
        OUT = Path(args.output_dir).resolve()
    assert args.qbo > 0 and args.evo > 0
    if args.qbo_chunk:
        assert args.qbo % args.qbo_chunk == 0
        import run_synthetic_pairwise_egbo_novelty_nehvi as author
        original_optimize_acqf = author.optimize_acqf
        recovery_counter = {"value": 0}

        def _safe_optimize(acq, bounds, q, num_restarts, raw_samples, options):
            """Predeclared numerical recovery for non-finite qLogNEHVI gradients.

            The recovery keeps the requested q and consumes no extra objective
            evaluations: a deterministic Sobol batch is returned in the same
            normalized bounds. It is activated only when BoTorch raises during
            acquisition optimization.
            """
            try:
                return original_optimize_acqf(
                    acq, bounds=bounds, q=q, num_restarts=num_restarts,
                    raw_samples=raw_samples, options=options)
            except Exception as exc:
                recovery_counter["value"] += 1
                seed = int(torch.initial_seed() % (2**31 - 1)) + recovery_counter["value"]
                engine = torch.quasirandom.SobolEngine(
                    dimension=bounds.shape[-1], scramble=True, seed=seed)
                unit = engine.draw(q).to(device=bounds.device, dtype=bounds.dtype)
                x = bounds[0] + unit * (bounds[1] - bounds[0])
                print(f"  qLogNEHVI numerical recovery {recovery_counter['value']}: "
                      f"Sobol q={q} after {type(exc).__name__}", flush=True)
                return x, torch.zeros((), device=bounds.device, dtype=bounds.dtype)

        def chunked_optimize_acqf(acq, bounds, q, num_restarts, raw_samples, options):
            if q <= args.qbo_chunk:
                return _safe_optimize(
                    acq, bounds=bounds, q=q, num_restarts=num_restarts,
                    raw_samples=raw_samples, options=options)
            blocks = []
            values = []
            for _ in range(q // args.qbo_chunk):
                x, v = _safe_optimize(
                    acq, bounds=bounds, q=args.qbo_chunk,
                    num_restarts=num_restarts, raw_samples=raw_samples,
                    options={**options, "batch_limit": args.qbo_chunk})
                blocks.append(x)
                values.append(v)
            return torch.cat(blocks, dim=0), torch.stack(values)

        author.optimize_acqf = chunked_optimize_acqf
    assert torch.cuda.is_available(), "CUDA GPU is required for this run"
    OUT.mkdir(parents=True, exist_ok=True)
    source_hash = hashlib.sha256(SOURCE.read_bytes()).hexdigest()
    if "-" in args.cases:
        a, b = map(int, args.cases.split("-", 1))
        ids = list(range(a, b + 1))
    else:
        ids = [int(x) for x in args.cases.split(",")]
    with (OUT / "evaluator.log").open("ab") as log:
        server = subprocess.Popen(
            [str(MATLAB), "-batch", f"egbo_author_eval_server({args.port})"],
            cwd=ROOT, stdout=log, stderr=subprocess.STDOUT,
            creationflags=subprocess.CREATE_NO_WINDOW,
        )
    try:
        for attempt in range(120):
            try:
                request(args.port, {"command": "metadata", "test_id": 1})
                break
            except (OSError, TimeoutError):
                if server.poll() is not None:
                    raise RuntimeError("MATLAB evaluator exited during startup")
                time.sleep(1)
        else:
            raise RuntimeError("MATLAB evaluator did not start")
        failures = []
        for case_id in ids:
            try:
                run_case(case_id, args.port, source_hash,
                         args.qbo, args.evo, args.qbo_chunk, args.seed,
                         Path(args.initial_root) if args.initial_root else None,
                         Path(args.reference_root) if args.reference_root else None,
                         args.force)
            except Exception:
                failures.append(case_id)
                err = traceback.format_exc()
                print(f"FAILED T{case_id}\n{err}", flush=True)
                (OUT / f"T{case_id:02d}" / "error.txt").write_text(err, encoding="utf-8")
                torch.cuda.empty_cache()
        return 1 if failures else 0
    finally:
        try:
            request(args.port, {"command": "shutdown"})
        except Exception:
            server.terminate()
        try:
            server.wait(timeout=20)
        except subprocess.TimeoutExpired:
            server.terminate()


if __name__ == "__main__":
    raise SystemExit(main())
