function egbo_author_eval_server(port)
% Serve GetFunInfo/testmop objectives and explicit constraints to Python EGBO.
% One JSON request per line; this process never optimizes or changes the benchmark.
root = fileparts(mfilename('fullpath'));
cd(root);
server = java.net.ServerSocket(port);
cleanup = onCleanup(@()server.close()); %#ok<NASGU>
fprintf('EGBO_EVAL_SERVER_READY %d\n',port);
while true
    socket = server.accept();
    reader = java.io.BufferedReader(java.io.InputStreamReader(socket.getInputStream(),'UTF-8'));
    writer = java.io.PrintWriter(java.io.OutputStreamWriter(socket.getOutputStream(),'UTF-8'),true);
    line = reader.readLine();
    if isempty(line)
        socket.close();
        continue;
    end
    try
        req = jsondecode(char(line));
        if strcmp(req.command,'shutdown')
            writer.println(jsonencode(struct('status','ok')));
            socket.close();
            break;
        end
        obj = GetFunInfo(req.test_id);
        if strcmp(req.command,'metadata')
            if isfield(req,'seed'), init_seed=req.seed; else, init_seed=0; end
            assert(init_seed>=0 && init_seed==floor(init_seed));
            rng(init_seed,'twister');
            [chrom,G0] = initialize_variables(18,obj);
            response = struct('status','ok','test_id',req.test_id, ...
                'name',obj.name,'n_var',obj.nVar,'n_obj',obj.numOfObj, ...
                'n_constr',size(G0,2), ...
                'lb',obj.var_min,'ub',obj.var_max, ...
                'initial_x',chrom(:,1:obj.nVar), ...
                'initial_f',chrom(:,obj.nVar+1:end), ...
                'initial_g',G0, ...
                'pf_max',max(obj.truePF,[],1));
        elseif strcmp(req.command,'evaluate')
            X = req.X;
            if isvector(X), X=reshape(X,1,[]); end
            assert(size(X,2)==obj.nVar,'Decision dimension mismatch');
            [F,G] = eval_batch(obj,X);
            assert(all(isfinite(F(:))),'Nonfinite objective');
            response = struct('status','ok','F',F,'G',G);
        else
            error('Unknown command: %s',req.command);
        end
    catch ME
        response = struct('status','error','message',getReport(ME,'basic','hyperlinks','off'));
    end
    writer.println(jsonencode(response));
    socket.close();
end
end
